import React, {useEffect, useState} from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StatusBar,
  Image,
  Modal,
  Pressable,
  Alert,
} from 'react-native';
import {Avatar, Provider as PaperProvider} from 'react-native-paper';
import {SafeAreaView} from 'react-native-safe-area-context';
import {ScrollView, TextInput} from 'react-native-gesture-handler';
import DocumentPicker from 'react-native-document-picker';
import Header from '../../Components/HeaderComp';
import {getFontSize, getResHeight, getResWidth} from '../../utility/responsive';
import {useDispatch, useSelector} from 'react-redux';
import {
  ProfileUpdateAPI,
  getBasicDetailsAPI,
} from '../../features/basicdetails/basicdetail';
import {store} from '../../store';
import theme from '../../theme';
import {ActivityIndicator} from 'react-native';
function MyProfile({navigation}, props) {
  const dispatch = useDispatch();
  // const basicDetail = useSelector(state => state.basicDetail.basicDetail);
  const basicDetail = useSelector(state => state.basicDetail.basicDetail);
  const [FirstName, setFirstName] = React.useState(basicDetail?.first_name);
  const [email, setEmail] = React.useState(basicDetail?.email);
  const rider_id = useSelector(state => state.auth.user?._id);
  const {loggedIn} = useSelector(state => state.auth);
  const userdata = store.getState().auth.userLog?.phone_number;
  const [LastName, setLastName] = React.useState(basicDetail?.last_name);
  const [Contact, setContact] = React.useState(
    basicDetail?.phone_number || userdata,
  );
  const [isVerifyLoading, setIsVerifyLoading] = useState(null);
  const [isLoading, setLoading] = useState(null);

  const [ContactCode, setContactCode] = React.useState('');
  const [profilePhoto, setProfilePhoto] = React.useState('');
  const [modalVisible, setModalVisible] = React.useState('');
  const navigateToHomeScreen = () => {
    navigation.reset({
      index: 0,
      routes: [{name: 'MainDrawer'}],
    });
  };
  useEffect(() => {
    dispatch(
      getBasicDetailsAPI({
        rider_id: basicDetail && basicDetail?.rider_id,
      }),
    );
  }, []);
  const updateProfile = async () => {
    const formData = new FormData();

    formData.append('first_name', FirstName);
    formData.append('last_name', LastName);
    formData.append('phone_number', Contact);
    formData.append('email', email);
    formData.append('rider_id', basicDetail?.rider_id || rider_id);
    formData.append('_id', basicDetail?.rider_id || rider_id);
    formData.append('photo', profilePhoto[0]);

    dispatch(ProfileUpdateAPI(formData));
  };
  const selectProfilePhoto = async () => {
    try {
      const res = await DocumentPicker.pick({
        type: [DocumentPicker.types.allFiles],
        copyTo: 'cachesDirectory',
      });
      setProfilePhoto(res);
    } catch (err) {
      setProfilePhoto(null);
      if (DocumentPicker.isCancel(err)) {
        Alert('Canceled');
      } else {
        Alert('Unknown Error: ' + JSON.stringify(err));
        throw err;
      }
    }
  };

  return (
    <SafeAreaView style={{flex: 1, backgroundColor: 'white'}}>
      <StatusBar backgroundColor="transparent" translucent />
      <Header
        containerStyle={{
          width: '90%',
          alignSelf: 'center',
          marginRight: '5%',
          marginTop: '-0.4%',
        }}
        title={'My Profile'}
        backPress={() => {
          navigation.navigate('HomeScreen');
        }}
        {...props}
      />

      <ScrollView
        style={{
          width: '90%',
          alignSelf: 'center',
        }}>
        <Modal
          animationType="slide"
          transparent={true}
          visible={modalVisible}
          onRequestClose={() => {
            // Alert.alert('Modal has been closed.');
            setModalVisible(!modalVisible);
          }}>
          <View
            style={{
              flex: 1,
              backgroundColor: theme.color.BACKGROUND,
              justifyContent: 'center',
              alignItems: 'center',
            }}>
            <View
              style={{
                width: '85%',
                // backgroundColor: '#fff',
                borderRadius: 10,
                flex: 1,
                maxHeight: 200,
              }}>
              <View
                style={{
                  margin: 10,
                  backgroundColor: 'white',
                  borderRadius: getResWidth(20),
                  padding: 35,
                  alignItems: 'center',
                  shadowColor: '#000',
                  shadowOffset: {
                    width: 0,
                    height: 2,
                  },
                  shadowOpacity: 0.25,
                  shadowRadius: 4,
                  elevation: 5,
                }}>
                <Text
                  style={{
                    marginVertical: 15,
                    textAlign: 'justify',
                    lineHeight: 22,
                    fontSize: getFontSize(15),
                    fontWeight: 'bold',
                    color: '#000',
                  }}>
                  Profile is Upload successfully
                </Text>
                {isVerifyLoading == true ? (
                  <ActivityIndicator color={theme.color.primary} size={35} />
                ) : (
                  <Pressable
                    style={{
                      backgroundColor: '#000055',
                      justifyContent: 'center',
                      alignItems: 'center',
                      borderRadius: getResWidth(20),
                      height: 35,
                      width: 270,
                      marginTop: '10%',
                    }}
                    onPress={async () => {
                      setIsVerifyLoading(true);
                      setLoading(false);

                      try {
                        setIsVerifyLoading(false);
                        const response = dispatch(
                          getBasicDetailsAPI({rider_id: basicDetail?.rider_id}),
                        );

                        if (response) {
                          setModalVisible(false);
                          navigation.navigate('HomeScreen');
                          navigateToHomeScreen();
                        }
                      } catch (error) {
                        Alert.alert('please Try again');
                      }
                    }}>
                    <Text
                      style={{
                        color: 'white',
                        fontWeight: 'bold',
                        textAlign: 'center',
                      }}>
                      OK
                    </Text>
                  </Pressable>
                )}
              </View>
            </View>
          </View>
        </Modal>

        <View
          style={{
            alignItems: 'center',
          }}>
          <View
            style={{
              flexDirection: 'column',
              alignItems: 'center',
              justifyContent: 'center',
              flexWrap: 'wrap',

              borderRadius: 200,
            }}>
            {basicDetail &&
            profilePhoto &&
            basicDetail?.photo !== null &&
            profilePhoto !== null ? (
              <Avatar.Image
                resizeMode="contain"
                size={120}
                source={{
                  uri: profilePhoto[0]?.fileCopyUri,
                }}
                style={{
                  backgroundColor: 'transparent',
                  alignSelf: 'center',
                  justifyContent: 'center',
                  alignContent: 'center',
                  alignItems: 'center',
                  backgroundColor: 'red',
                  padding: 1,
                }}
              />
            ) : basicDetail && basicDetail?.photo !== 'null' ? (
              <Avatar.Image
                resizeMode="contain"
                size={120}
                source={{uri: basicDetail?.profile_image}}
                style={{
                  backgroundColor: 'transparent',
                  alignSelf: 'center',
                  justifyContent: 'center',
                  alignContent: 'center',
                  alignItems: 'center',
                  padding: 10,

                  backgroundColor: 'gray',
                }}
              />
            ) : (
              <Avatar.Image
                resizeMode="contain"
                size={120}
                source={require('../../assets/img/avatar.png')}
                style={{
                  backgroundColor: 'transparent',
                  alignSelf: 'center',
                  justifyContent: 'center',
                  alignContent: 'center',
                  alignItems: 'center',
                  backgroundColor: 'blue',

                  padding: 1,
                }}
              />
            )}
          </View>

          <TouchableOpacity
            style={{
              flexDirection: 'column',
              alignItems: 'center',
              textAlign: 'center',
              justifyContent: 'center',
              flexWrap: 'wrap',
            }}
            activeOpacity={0.5}
            onPress={selectProfilePhoto}>
            <Text
              style={{
                fontWeight: 'bold',
                fontSize: 20,
                marginTop: '5%',
              }}>
              Tap to Upload Photo
            </Text>
          </TouchableOpacity>
        </View>
        <Text
          style={{
            fontSize: 18,
            marginTop: 7,
            fontWeight: 'bold',
            marginTop: '5%',
          }}>
          First Name
        </Text>

        <TextInput
          placeholder={
            basicDetail?.first_name
              ? basicDetail.first_name.toString()
              : 'First name'
          }
          onChangeText={value => {
            setFirstName(value);
            // handleValidFirstName(value);
          }}
          maxLength={20}
          value={FirstName}
          style={{
            width: '100%',
            fontSize: getFontSize(15),
            fontWeight: '300',
            backgroundColor: '#f6f6f6',
            borderRadius: 12,
            marginTop: '3%',
            textAlign: 'auto',
            padding: 10,
            borderWidth: 1,
            borderColor: '#ececec',
            fontWeight: 'bold',
          }}
        />

        <Text
          style={{
            fontSize: 18,
            fontWeight: 'bold',
            marginTop: 7,
          }}>
          Last Name
        </Text>
        <TextInput
          placeholder={
            basicDetail?.last_name
              ? basicDetail?.last_name.toString()
              : 'Last name'
          }
          onChangeText={value => {
            setLastName(value);
            // handleValidLastName(value);
          }}
          value={LastName}
          maxLength={20}
          style={{
            width: '100%',
            fontSize: getFontSize(15),
            fontWeight: '300',
            backgroundColor: '#f6f6f6',
            borderRadius: 12,
            marginTop: '3%',
            textAlign: 'auto',
            padding: 10,
            borderWidth: 1,
            borderColor: '#ececec',
            fontWeight: 'bold',
          }}
        />
        <Text
          style={{
            fontSize: 18,
            marginTop: 7,
            fontWeight: 'bold',
          }}>
          Contact
        </Text>
        <View
          style={{
            flexDirection: 'row',

            flex: 1,
            justifyContent: 'space-between',
          }}>
          <TextInput
            placeholder="+91"
            onChangeText={value => {
              setContactCode(value);
              // handleValidContactCode(value);
            }}
            value={ContactCode}
            style={{
              width: '20%',
              fontSize: getFontSize(15),
              fontWeight: '300',
              backgroundColor: '#f6f6f6',
              borderRadius: 12,
              marginTop: '3%',
              textAlign: 'auto',
              padding: 10,
              borderWidth: 1,
              borderColor: '#ececec',
              fontWeight: 'bold',
            }}
          />
          <TextInput
            placeholder={
              basicDetail?.phone_number
                ? basicDetail.phone_number.toString()
                : 'Mobile number'
            }
            onChangeText={value => {
              setContact(value);
              // handleValidContact(value);
            }}
            editable={false}
            value={Contact}
            style={{
              width: '75%',
              fontSize: getFontSize(15),
              fontWeight: '300',
              backgroundColor: '#f6f6f6',
              borderRadius: 12,
              marginTop: '3%',
              textAlign: 'auto',
              padding: 10,
              borderWidth: 1,
              borderColor: '#ececec',
              fontWeight: 'bold',
            }}
          />
        </View>

        <Text
          style={{
            fontSize: 18,
            marginTop: 6,
            fontWeight: 'bold',
          }}>
          Email
        </Text>

        <TextInput
          autoCorrect={false}
          keyboardAppearance="default"
          onChangeText={value => {
            setEmail(value);
            // handleValidEmail(value);
          }}
          value={email}
          // editable={false}
          // placeholder={basicDetail?.email.toString()}
          placeholder={
            basicDetail?.email ? basicDetail.email.toString() : 'Email'
          }
          style={{
            width: '100%',
            fontSize: getFontSize(15),
            fontWeight: '300',
            backgroundColor: '#f6f6f6',
            borderRadius: 12,
            marginTop: '3%',
            textAlign: 'auto',
            padding: 10,
            borderWidth: 1,
            borderColor: '#ececec',
            fontWeight: 'bold',
            marginBottom: '15%',
          }}
        />
      </ScrollView>
      <TouchableOpacity
        style={{
          width: '90%',
          fontSize: getFontSize(15),
          fontWeight: '300',

          borderRadius: 12,

          padding: 10,
          borderWidth: 1,
          borderColor: '#ececec',
          fontWeight: 'bold',
          backgroundColor: '#000055',
          alignSelf: 'center',
        }}
        onPress={async () => {
          setLoading(true);

          try {
            const response = await updateProfile();

            if (response) {
              navigation.navigate('HomeScreen');
              navigateToHomeScreen();
            }
          } catch (error) {
            Alert.alert('please Try again');
          }
          setTimeout(function () {
            setLoading(false);
            setModalVisible(!modalVisible);
          }, 1000);
        }}>
        {isLoading == true ? (
          <View style={{flexDirection: 'row', alignSelf: 'center'}}>
            <ActivityIndicator
              color={theme.color.extraLight}
              size={25}
              // padding={3}
            />
            <Text
              style={{
                color: theme.color.extraLight,
                fontSize: getFontSize(14),
                textTransform: 'uppercase',
                fontWeight: 800,

                alignSelf: 'center',
              }}>
              {'   '} Loading
            </Text>
          </View>
        ) : (
          <Text
            style={{
              width: '95%',
              textAlign: 'center',
              fontSize: 18,
              color: '#fff',
            }}>
            Done
          </Text>
        )}
      </TouchableOpacity>
    </SafeAreaView>
  );
}

export default MyProfile;
