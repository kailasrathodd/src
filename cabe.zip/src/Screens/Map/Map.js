import React, {Component} from 'react';
import {DEFAULT_CENTER_COORDINATE} from '../../utils';
import {Platform, Text, View, PermissionsAndroid} from 'react-native';
import MapplsGL from 'mappls-map-react-native';
import exampleIcon from '../../assets/img/cab-e-car.png';
import RNAndroidLocationEnabler from 'react-native-android-location-enabler';
import {Button, Icon} from 'react-native-elements';

import * as Permissions from 'react-native-permissions';

import {updateLocation} from '../../features/location/location';
import {connect} from 'react-redux';

class Map extends Component {
  constructor(props) {
    super(props);
    this.state = {
      gpsState: false,
      location: [72.8484724, 19.20425071],
      latitude: null,
      longitude: null,
      clusterData: {
        type: 'FeatureCollection',
        features: [
          {
            type: 'Feature',
            properties: {
              id: 1,
              title: 'M 2.3 - 1 km SSE of Magas Arriba, Puerto Rico',
            },
            geometry: {
              type: 'Point',
              coordinates: [72.84683679, 19.20037098],
            },
          },
          {
            type: 'Feature',
            properties: {
              id: 2,
              title: 'M 2.3 - 1 km SSE of Magas Arriba, Puerto Rico',
            },
            geometry: {
              type: 'Point',
              coordinates: [72.846158319, 19.209555037098],
            },
          },
          {
            type: 'Feature',
            properties: {
              id: 3,
              title: 'M 2.3 - 1 km SSE of Magas Arriba, Puerto Rico',
            },
            geometry: {
              type: 'Point',
              coordinates: [72.843158319, 19.20555037098],
            },
          },
        ],
      },
    };
  }

  componentDidMount() {
    MapplsGL.locationManager.start();
    // Toast.show('To get current location press my location button ', // Toast.LONG);
  }

  componentWillUnmount() {
    MapplsGL.locationManager.stop();
  }

  onUpdate(location) {
    const {latitude, longitude, accuracy} = location.coords;

    this.setState({
      latitude,
      longitude,
    });
    this.props.updateLocation({latitude, longitude});
    this.camera.zoomTo(12, 1000);
    this.camera.flyTo([longitude, latitude]);
  }
  onLongPress(event) {
    const {geometry, properties} = event;
    const longitude = geometry.coordinates[0];
    const latitude = geometry.coordinates[1];
  }
  async requestLocationPermission() {
    if (Platform.OS === 'ios') {
      const {status} = await Permissions.request(
        Permissions.PERMISSIONS.IOS.LOCATION_WHEN_IN_USE,
      );
      return status;
    } else {
      const granted = await PermissionsAndroid.request(
        PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
        {
          title: 'Location Permission',
          message: 'CabeApp needs access to your location.',
          buttonNeutral: 'Ask Me Later',
          buttonNegative: 'Cancel',
          buttonPositive: 'OK',
        },
      );
      if (granted === PermissionsAndroid.RESULTS.GRANTED) {
        return 'granted';
      } else {
        return 'denied';
      }
    }
  }
  async onMarkerClick(e) {
    const f = e.features;
    console.log(JSON.stringify(f));
    this.camera.setCamera();

    if (!f.properties.cluster) {
      console.log('marker click ' + JSON.stringify(f));
      console.log('markerID: ' + f.properties.id);
    } else {
      console.log(f);
      this.camera.setCamera({
        zoomLevel: 10,
        animationDuration: 1000,
        centerCoordinate: [
          f.geometry.coordinates[0],
          f.geometry.coordinates[1],
        ],
      });
    }
  }

  onPressLocationButton() {
    this.requestLocationPermission().then(status => {
      if (status === 'granted') {
        this.camera.zoomTo(15);
      } else {
        this.camera.zoomTo(18);
      }
    });
  }

  async onPress(event) {
    const {geometry, properties} = event;
    let longitude = geometry.coordinates[0];
    let latitude = geometry.coordinates[1];
    this.setState({
      location: [longitude, latitude],
    });
    try {
      const detail = await MapplsGL.RestApi.placeDetail({mapplsPin: '2sev87'});
      console.log(detail);
    } catch (e) {}
    // // Toast.show(this.state.label,// Toast.SHORT);
  }
  onfloatingButtonClick() {
    if (Platform.OS == 'android') {
      RNAndroidLocationEnabler.promptForEnableLocationIfNeeded({
        interval: 1000,
        fastInterval: 5000,
      })
        .then(data => {
          this.setState({
            gpsState: true,
          });
        })
        .catch(err => {
          // Toast.show('Please enable gps.');
        });
    } else {
      this.setState({
        gpsState: true,
      });
    }
  }

  render() {
    const {latitude, longitude} = this.state;
    const locationComponent = this.state.gpsState ? (
      <MapplsGL.UserLocation
        animated={true}
        visible={true}
        onUpdate={location => this.onUpdate(location)}
      />
    ) : null;
    const pick_up_latitude = latitude;
    const pick_up_longitude = longitude;
    // console.log('pick_up_latitude', pick_up_latitude);
    // console.log('pick_up_longitude', pick_up_longitude);
    const rider_id = '64144639e23c000031001e47';

    const handleVerifyOTP = () => {
      fetch('http://192.168.0.21s:8000/api/riderNearbyFindDriverLocation', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({pick_up_latitude, pick_up_longitude, rider_id}),
      })
        .then(response => response.json())

        .then(data => console.log(data))
        .catch(error => setError(error));
    };
    return (
      <View style={{flex: 1}}>
        <MapplsGL.MapView
          ref={r => (this.map = r)}
          style={{flex: 1}}
          onPress={event => {
            this.onPress(event);
            this.onLongPress(event);
          }}>
          <MapplsGL.Camera
            ref={c => (this.camera = c)}
            zoomLevel={13}
            animationMode="flyTo"
            centerCoordinate={DEFAULT_CENTER_COORDINATE}
          />
          {locationComponent}
          {/* <MapplsGL.ShapeSource
            id="earthquakes"
            // cluster={true}
            // clusterRadius={1}
            shape={this.state.clusterData}
            onPress={e => this.onMarkerClick(e)}>
            <MapplsGL.SymbolLayer
              id="pointCount"
              style={layerStyles.clusterCount}
            />

            <MapplsGL.CircleLayer
              id="clusteredPoints"
              belowLayerID="pointCount"
              filter={['has', 'point_count']}
              style={layerStyles.clusteredPoints}
            />
            <MapplsGL.SymbolLayer
              id="singlePoint"
              filter={['!', ['has', 'point_count']]}
              style={layerStyles.singlePoint}
            />
          </MapplsGL.ShapeSource> */}
          <MapplsGL.PointAnnotation
            id="markerId"
            title="Marker"
            onSelected={() => {}}
            onDeselected={() => {}}
            // mapplsPin='C7JXWD'
            coordinate={this.state.location}>
            <MapplsGL.Callout title="xyz" />
          </MapplsGL.PointAnnotation>
        </MapplsGL.MapView>
        <View
          style={{
            width: 50,
            height: 50,
            backgroundColor: 'transparent',
            position: 'absolute',
            top: '80%',
            left: '80%',
            zIndex: 10,
          }}>
          <Button
            icon={<Icon name="my-location" size={35} color="white" />}
            onPress={() => {
              this.onfloatingButtonClick();
              this.onPressLocationButton();
              // handleVerifyOTP();
            }}
          />
        </View>
      </View>
    );
  }
}
const mapDispatchToProps = {
  updateLocation,
};

// export default connect(mapStateToProps)(liveLoacation);
// export default liveLoacation;
export default connect(null, mapDispatchToProps)(Map);
const layerStyles = {
  singlePoint: {
    iconImage: exampleIcon,
    iconAllowOverlap: true,
    iconSize: 0.05,
    iconAnchor: 'bottom',
    iconPitchAlignment: 'map',
  },

  clusteredPoints: {
    circlePitchAlignment: 'map',

    circleColor: [
      'step',
      ['get', 'point_count'],
      '#51bbd6',
      100,
      '#f1f075',
      750,
      '#f28cb1',
    ],

    circleRadius: ['step', ['get', 'point_count'], 20, 100, 30, 750, 40],

    circleOpacity: 0.84,
    circleStrokeWidth: 2,
    circleStrokeColor: 'white',
  },

  clusterCount: {
    textField: '{point_count}',
    textSize: 12,
    textPitchAlignment: 'map',
  },
};
