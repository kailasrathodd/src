import React, {useEffect, useState} from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  TextInput,
  SafeAreaView,
  ImageBackground,
} from 'react-native';
import {CheckBox} from 'react-native-elements';
import {useDispatch} from 'react-redux';
import {ActivityIndicator} from 'react-native';
import theme from '../../theme';
import {getFontSize} from '../../utility/responsive';
import {loginAPI} from '../../features/basicdetails/basicdetail';
import VerifyOtp from './VerifyOtp';

function Login({navigation}) {
  const dispatch = useDispatch();
  const [phoneNumber, setPhoneNumber] = useState('');
  const [contactCode, setContactCode] = useState('');
  const [mobileValidError, setMobileValidError] = useState('');
  const [showSendOtp, setShowSendOtp] = useState(false);
  const [loading, setLoading] = useState(false);
  const [isSelected, setSelection] = useState(false);
  const [isButton, setButton] = useState(false);
  const [isVerifyLoading, setIsVerifyLoading] = useState(false);

  const handleSendOtp = () => {
    setIsVerifyLoading(true);

    dispatch(loginAPI({phone_number: phoneNumber}))
      .then(data => {
        setIsVerifyLoading(false);
        if (data.payload.status === 200) {
          navigation.navigate(VerifyOtp);
        }
      })
      .catch(error => {
        setIsVerifyLoading(false);
        console.error(error);
      });
  };

  const handleValidMobile = async val => {
    let reg = /^[0]?[56789]\d{9}$/;
    setButton(false);

    if (val.length === 0) {
      setMobileValidError('Mobile Number Must Be Entered!');
    } else if (val.length < 10) {
      setMobileValidError('Mobile Number Must Be 10 Digits!');
    } else if (val.length === 10 && !reg.test(val)) {
      setMobileValidError('Invalid Mobile Number!');
    } else if (reg.test(val)) {
      setMobileValidError('');
      setShowSendOtp(true);
    }
  };

  useEffect(() => {
    setButton(isSelected && showSendOtp && mobileValidError === '');
  }, [isSelected, showSendOtp, mobileValidError]);

  return (
    <SafeAreaView style={{flex: 1, backgroundColor: '#fff'}}>
      <ImageBackground
        source={require('../../assets/img/first_bg.png')}
        resizeMode="cover"
        style={{flex: 1, width: '100%', height: '100%'}}>
        <Text
          style={{
            fontSize: getFontSize(25),
            color: 'grey',
            fontWeight: '500',
            marginTop: '17%',
            marginLeft: '8%',
            lineHeight: 30,
          }}>
          Enter Your Mobile Number
        </Text>
        <View
          style={{
            flexDirection: 'row',
            marginTop: '30%',
            justifyContent: 'space-between',
            width: '85%',
            alignSelf: 'center',
          }}>
          <TextInput
            placeholder="+91"
            style={{
              width: '20%',
              fontSize: getFontSize(15),
              fontWeight: '300',
              backgroundColor: '#f6f6f6',
              borderRadius: 12,
              marginTop: '3%',
              textAlign: 'auto',
              padding: 10,
              borderWidth: 1,
              borderColor: '#ececec',
              fontWeight: 'bold',
              shadowColor: '#000',
              shadowOffset: {
                width: 0,
                height: 2,
              },
              shadowOpacity: 0.23,
              shadowRadius: 2.62,
              elevation: 4,
            }}
            disabled={true}
            editable={false}
          />
          <TextInput
            value={phoneNumber}
            placeholder="Eg. 9876543210"
            onChangeText={value => {
              setPhoneNumber(value);
              handleValidMobile(value);
            }}
            keyboardType="numeric"
            maxLength={10}
            style={{
              width: '75%',
              fontSize: getFontSize(15),
              fontWeight: '300',
              backgroundColor: '#f6f6f6',
              borderRadius: 12,
              marginTop: '3%',
              textAlign: 'auto',
              padding: 10,
              borderWidth: 1,
              borderColor: '#ececec',
              fontWeight: 'bold',
              shadowColor: '#000',
              shadowOffset: {
                width: 0,
                height: 2,
              },
              shadowOpacity: 0.23,
              shadowRadius: 2.62,
              elevation: 4,
            }}
          />
        </View>
        <View style={{fontSize: 20, paddingBottom: 10}}>
          {mobileValidError ? (
            <Text
              style={{
                color: '#f00',
                justifyContent: 'flex-start',
                paddingLeft: 10,
                marginTop: '5%',
              }}>
              {mobileValidError}
            </Text>
          ) : null}
        </View>

        {mobileValidError === '' && !isSelected ? (
          <>
            <View
              style={{
                width: '100%',
                flexDirection: 'row',
                marginTop: '10%',
                marginLeft: '4%',
              }}>
              <CheckBox
                center
                checked={isSelected}
                disabled={false}
                onPress={() => setSelection(!isSelected)}
              />
              <Text style={{marginTop: '4%'}}>
                By continuing, I confirm I have read the {'  '}
              </Text>
            </View>
            <TouchableOpacity
              style={{
                width: '100%',
                alignItems: 'center',
                justifyContent: 'center',
                bottom: '3%',
                marginTop: '5%',
              }}
              onPress={() => navigation.navigate('PrivacyPolicy')}
              disabled={false}>
              <Text
                style={{
                  width: '60%',
                  fontSize: 15,
                  color: theme.color.primary,
                  fontWeight: 900,
                  marginTop: '3%',
                }}>
                Privacy policy
              </Text>
            </TouchableOpacity>
          </>
        ) : (
          <>
            <View
              style={{
                width: '100%',
                flexDirection: 'row',
                marginTop: '10%',
                marginLeft: '4%',
              }}>
              <CheckBox
                center
                checked={isSelected}
                disabled={true}
                onPress={() => setSelection(!isSelected)}
              />
              <Text style={{marginTop: '4%'}}>
                By continuing, I confirm I have read the {'  '}
              </Text>
            </View>
            <TouchableOpacity
              style={{
                width: '100%',
                alignItems: 'center',
                justifyContent: 'center',
                bottom: '3%',
              }}
              disabled={true}>
              <Text
                style={{
                  width: '60%',
                  fontSize: 15,
                  color: theme.color.primary,
                  fontWeight: 900,
                  marginTop: '3%',
                }}>
                Privacy policy
              </Text>
            </TouchableOpacity>
          </>
        )}
        {isVerifyLoading ? (
          <ActivityIndicator color={theme.color.primary} size={28} />
        ) : (
          <TouchableOpacity
            style={{
              width: '90%',
              alignItems: 'center',
              position: 'absolute',
              alignSelf: 'center',
              justifyContent: 'center',
              bottom: 15,
              borderRadius: 12,
              padding: 11,
              backgroundColor: isButton ? '#000055' : '#ddd',
            }}
            onPress={handleSendOtp}
            disabled={!isButton}>
            <Text
              style={{
                width: '90%',
                textAlign: 'center',
                fontSize: 18,
                borderRadius: 12,
                color: '#fff',
              }}>
              Continue
            </Text>
          </TouchableOpacity>
        )}
      </ImageBackground>
    </SafeAreaView>
  );
}

export default Login;
