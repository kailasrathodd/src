import React from 'react';
import {StyleSheet, Text, View, ActivityIndicator} from 'react-native';
import WebView from 'react-native-webview';
// import Header from '../../components/HeaderComponent';
import {BASE_URL} from '../../config/constants';
import styles from './styles';
import Header from '../../Components/HeaderComp';

const TermCondition = ({navigation}, props) => {
  const [isLoading, setIsLoading] = React.useState(true);
  return (
    <View style={{flex: 1}}>
      <Header
        containerStyle={{
          alignSelf: 'center',
        }}
        title={'Term & Condition'}
        backPress={() => {
          navigation.pop();
        }}
        {...props}
      />

      <View style={styles.contentContainer}>
        <WebView
          source={{uri: BASE_URL + '/api/term_condition'}}
          onLoadStart={() => setIsLoading(true)}
          onLoadEnd={() => setIsLoading(false)}
        />
        {isLoading && (
          <View style={styles.activityIndicatorContainer}>
            <ActivityIndicator size="large" color="#000055" />
          </View>
        )}
      </View>
      {/* <View style={{flex: 1}}>
        {isLoading && <ActivityIndicator size="large" color="#0000ff" />}

        <WebView
          source={{uri: API_URL + '/api/term_condition'}}
          onLoad={() => setIsLoading(true)}
          onLoadEnd={() => setIsLoading(false)}
        />
      </View> */}
    </View>
  );
};

export default TermCondition;
