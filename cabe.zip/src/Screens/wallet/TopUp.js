import {
  View,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  SafeAreaView,
  Image,
} from 'react-native';
import React, {useState} from 'react';
import {getFontSize} from '../../utility/responsive';
import setVectorIcon from '../../Components/VectorComponents';
import Header from '../../Components/HeaderComp';

export default function TopUp({navigation}, props) {
  const onPress = props;
  const [TextInput1, setTextInput1] = useState();
  const [showButton, setShowButton] = useState(true);

  const handleSubmit = val => {
    if (val.length === 0) {
      setShowButton(true);
    } else {
      setShowButton(false);
    }
  };

  return (
    <View
      style={{
        // height: '100%',
        flex: 1,
        backgroundColor: '#fff',
      }}>
      <>
        <Header
          containerStyle={{
            width: '100%',
            alignSelf: 'center',
          }}
          title={'Top up Wallet'}
          backPress={() => {
            // navigation.navigate(PromoCode);
            navigation.pop();
          }}
        />

        <View
          style={{
            // backgroundColor: '#000',
            borderRadius: 35,
            width: '90%',
            alignSelf: 'center',
            borderWidth: 1,
            flexDirection: 'row',
            marginTop: '10%',
            height: 220,
            justifyContent: 'center',
            borderColor: 'grey',
          }}>
          <View
            style={{
              backgroundColor: '#fff',
              borderRadius: 20,
              alignSelf: 'center',
              flexDirection: 'row',
              marginTop: '2%',
            }}>
            {setVectorIcon({
              type: 'FontAwesome',
              name: 'rupee',
              size: getFontSize(50),
              color: '#000',
            })}
          </View>

          <TextInput
            style={{
              color: '#000',
              fontSize: 50,
              marginLeft: '2%',
              fontWeight: '500',
              fontStyle: 'italic',
            }}
            placeholder="550"
            keyboardType="numeric"
            value={TextInput1}
            maxLength={10}
            onChangeText={value => {
              setTextInput1(value);
              handleSubmit(value);
            }}
          />
        </View>

        <View style={{position: 'absolute', bottom: 0, width: '100%'}}>
          <TouchableOpacity
            style={{
              width: '100%',
              alignItems: 'center',

              justifyContent: 'center',
              bottom: '15%',
            }}
            onPress={() => navigation.navigate('PaymentMethod')}
            disabled={showButton == true ? true : false}>
            <Text
              style={{
                backgroundColor: '#000055',
                width: '95%',
                textAlign: 'center',
                fontSize: 18,
                // paddingVertical: 20,
                borderRadius: 12,
                padding: 15,
                color: '#fff',
              }}>
              Continue
            </Text>
          </TouchableOpacity>
        </View>
        {/* ) : null} */}
      </>
    </View>
  );
}
