import {createSlice} from '@reduxjs/toolkit';

const rider = createSlice({
  name: 'rider',
  initialState: {
    rider: null,
    categoryVehical: null,
    onClickModel: null,
    Model: null,
    fareCalulate: null,
    isLoading: false,
    error: null,
    FareCal: '',
    CreateRide: '',
    getDriver: null,
    paymentAttributes: null,
    GetRideDetail: null,
    payment: null,
    selectedCar: '',
    rideTimeOut: '',
    riderJourneyHistory: '',
    ride_id: '',
    getDriverLoc: '',
    getArrived_time: '',
  },
  reducers: {
    setModel: (state, action) => {
      state.Model = action.payload;
      state.isLoading = false;
      state.error = null;
    },

    setselectModel: (state, action) => {
      state.categoryVehical = action.payload;
      state.isLoading = false;
      state.error = null;
    },
    selectedCar: (state, action) => {
      state.selectedCar = action.payload;
    },
    rideTimeOut: (state, action) => {
      state.rideTimeOut = action.payload;
    },
    payment: (state, action) => {
      state.payment = action.payload;
    },
    getArrived_time: (state, action) => {
      state.getArrived_time = action.payload;
    },
    onClickModel: (state, action) => {
      state.onClickModel = action.payload;
      state.isLoading = false;
      state.error = null;
    },
    FareCal: (state, action) => {
      state.FareCal = action.payload;
      state.isLoading = false;
      state.error = null;
    },
    CreateRide: (state, action) => {
      state.CreateRide = action.payload;
      state.isLoading = false;
      state.error = null;
    },
    getDriver: (state, action) => {
      state.getDriver = action.payload;
    },
    GetRideDetail: (state, action) => {
      state.GetRideDetail = action.payload;
    },
    paymentAttributes: (state, action) => {
      state.paymentAttributes = action.payload;
    },
    riderJourneyHistory: (state, action) => {
      state.riderJourneyHistory = action.payload;
    },
    ride_id: (state, action) => {
      state.ride_id = action.payload;
    },
    getDriverLoc: (state, action) => {
      state.getDriverLoc = action.payload;
    },
  },
});

export const {
  setselectModel,
  CreateRide,
  FareCal,
  categoryVehical,
  paymentAttributes,
  setModel,
  getDriver,
  GetRideDetail,
  getDriverLoc,
  onClickModel,
  selectedCar,
  rideTimeOut,
  ride_id,
  payment,
  getArrived_time,
  riderJourneyHistory,
} = rider.actions;

export default rider.reducer;