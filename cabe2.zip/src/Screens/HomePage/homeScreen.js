/* eslint-disable no-undef */
/* eslint-disable react-native/no-inline-styles */
/* eslint-disable no-lone-blocks */
/* eslint-disable react-hooks/exhaustive-deps */
/* eslint-disable no-self-compare */
import {
  View,
  Text,
  StyleSheet,
  Dimensions,
  TouchableOpacity,
  FlatList,
  Image,
  Linking,
  StatusBar,
  ActivityIndicator,
  PermissionsAndroid,
} from 'react-native';
import Swiper from 'react-native-swiper';
import {useDispatch, useSelector} from 'react-redux';
import React, {useEffect, useState} from 'react';
import setVectorIcon from '../../Components/VectorComponents';
import {getFontSize, getResHeight, getResWidth} from '../../utility/responsive';
import {
  authAPI,
  getBasicDetailsAPI,
  riderLogoutAPI,
  RideUpdateAPI,
} from '../../features/basicdetails/basicdetail';
import {store} from '../../store';
import {SafeAreaView} from 'react-native-safe-area-context';
import {mappleTokenAPI} from '../../features/auth/authAPI';
import * as Permissions from 'react-native-permissions';

import {
  getRideDetailAPI,
  selectModelAPI,
} from '../../features/CreateToRide/riderAPI';
import {CreateRide, GetRideDetail} from '../../features/CreateToRide';
import {typeLocation, updateLocation} from '../../features/location/location';
// import {reviewQuestionsAPI} from '../../features/Review/reviewAPI';
// import Geolocation from 'react-native-geolocation-service';
const WIDTH = Dimensions.get('window').width;

export default function HomeScreen({navigation}) {
  const dispatch = useDispatch();
  const [isLoading, setLoading] = useState(null);
  const basicDetail = useSelector(state => state?.basicDetail?.basicDetail);
  const mappleToken = useSelector(state => state?.auth?.mappleToken);
  const rider_id = useSelector(state => state.auth.user?._id);
  const rider = useSelector(state => state?.rider?.GetRideDetail);
  const authApi = useSelector(state => state.auth.authApi?._id);
  const Createride = useSelector(state => state.rider?.CreateRide?._id);
  const Create = useSelector(state => state.rider?.CreateRide);

  const activeUser = store.getState().basicDetail?.basicDetail?.data;

  async function requestLocationPermission() {
    if (Platform.OS === 'ios') {
      const {status} = await Permissions.request(
        Permissions.PERMISSIONS.IOS.LOCATION_WHEN_IN_USE,
      );
      return status;
    } else {
      const granted = await PermissionsAndroid.request(
        PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
        {
          title: 'Location Permission',
          message: 'App needs access to your location.',
          buttonNeutral: 'Ask Me Later',
          buttonNegative: 'Cancel',
          buttonPositive: 'OK',
        },
      );
      if (granted === PermissionsAndroid.RESULTS.GRANTED) {
        return 'granted';
      } else {
        return 'denied';
      }
    }
  }

  function onPressLocationButton() {
    requestLocationPermission().then(status => {
      if (status === 'granted') {
      } else {
        // Permission denied, show an error message
      }
    });
  }

  const handleLocationEnabling = () => {
    Permissions.request(Permissions.PERMISSIONS.ANDROID.ACCESS_FINE_LOCATION)
      .then(result => {
        if (result === Permissions.RESULTS.GRANTED) {
          console.log('Location services enabled');
        }
      })
      .catch(error => {
        console.warn('Error requesting location permission:', error);
      });
  };
  useEffect(() => {
    onPressLocationButton();

    handleLocationEnabling();
    // dispatch(reviewQuestionsAPI({rider_id: rider_id}));
    dispatch(getBasicDetailsAPI({rider_id: rider_id}));
    // if (basicDetail) {
    //   if (basicDetail?.email == 'null') {
    //     if (basicDetail?.email == 'null') {
    //       return navigation.navigate('RegisterEmail');
    //     }
    //   }
    //   if (basicDetail?.first_name == 'null') {
    //     if (basicDetail?.first_name == 'null') {
    //       return navigation.navigate('EnterName');
    //     }
    //   }
    // }
  }, []);
  useEffect(() => {
    if (mappleToken?.accessToken !== mappleToken?.accessToken) {
      dispatch(mappleTokenAPI());
    }
    if (authApi && authApi?.access_token !== authApi && authApi?.access_token) {
      dispatch(authAPI({client_id: rider_id}));
    }
  }, [authApi, dispatch, mappleToken?.accessToken, rider_id]);
  useEffect(() => {
    const interval = setInterval(() => {
      if (activeUser?.rider_message === 'user not found') {
        dispatch(resetStore());
        dispatch(riderLogoutAPI({rider_id: rider_id}));
        navigation.navigate('SplashScreen');
      }
      if (store.getState().auth.onBoarding === true) {
        if (Create !== null) {
          dispatch(getRideDetailAPI(Createride));
          dispatch(getRideDetailAPI({ride_id: Createride}));
        }
      }
    }, 1500);

    return () => clearInterval(interval);
  }, [dispatch, Createride, rider, rider_id, activeUser, navigation, Create]);
  useEffect(() => {
    const interval = setInterval(() => {
      // if (rider) {
      switch (rider?.status) {
        // switch ('ended') {
        case 'requested':
          navigation.navigate('SearchingDriver');
          break;

        case 'accepted':
          navigation.navigate('ShowDriver');
          break;
        case 'arrived':
          navigation.navigate('ShowDriver');

          break;
        case 'started':
          navigation.navigate('TripDestination');
          break;
        case 'ended':
          navigation.navigate('EndtoRider');
          break;
        case 'completed':
          navigation.navigate('RateDriver');
          break;
      }
      // }
    }, 1000);

    return () => clearInterval(interval);
  }, [rider, dispatch, navigation]);

  const Data = [
    {
      id: '1',
      value: 'no',
      onPress: () => {
        {
          setLoading(true);
          dispatch(GetRideDetail(null));
          dispatch(CreateRide(null));
          const latitude = 19.2108394823049;
          const longitude = 72.84576715169;

          dispatch(updateLocation({latitude, longitude}));
          dispatch(typeLocation('PickUp'));
          dispatch(
            RideUpdateAPI({
              drop_latitude: 19.2108394823049,
              drop_longitude: 72.84576715169,
              pickup_longitude: 72.84576715169,
              pickup_latitude: 19.2108394823049,
              drop_address: '',
              rider_id: rider_id,
              // pickup_address: '',
            }),
          )
            .then(data => {
              if (data.payload.status === 200) {
                setLoading(false);
                dispatch(
                  selectModelAPI({
                    rider_id: basicDetail?.rider_id || rider_id,
                  }),
                  // getBasicDetailsAPI({
                  //   rider_id: basicDetail?.rider_id || rider_id,
                  // }),
                );

                if (mappleToken?.accessToken !== mappleToken?.accessToken) {
                  dispatch(mappleTokenAPI());
                }

                navigation.navigate('SearchDashboard');
              }
            })
            .catch(error => {
              setLoading(false);
              console.error(error);
            });
          // setTimeout(function () {
          //   setLoading(false);
          //   Alert.alert('something went wrong please try again');
          // }, 20000);
        }
      },
      img: require('../../assets/img/homepage/1.png'),
      title: 'Book Now',
    },
    {
      id: '2',
      value: 'no',
      onPress: () => navigation.navigate('Schedule'),
      img: require('../../assets/img/homepage/2.png'),
      title: 'Schedule',
    },
    {
      id: '3',
      value: 'no',
      onPress: () => navigation.navigate('Comingsoon'),
      img: require('../../assets/img/homepage/3.png'),
      title: 'Intercity',
    },
    {
      id: '4',
      value: 'no',
      onPress: () => navigation.navigate('Comingsoon'),
      img: require('../../assets/img/homepage/4.png'),
      title: 'Corporate',
    },
    {
      id: '5',
      value: 'no',
      onPress: () => navigation.navigate('Comingsoon'),
      img: require('../../assets/img/homepage/5.png'),
      title: 'RENTAL',
    },
    {
      id: '6',
      value: 'no',
      onPress: () => navigation.navigate('Nodata'),
      img: require('../../assets/img/homepage/6.png'),
      title: 'CONCIERGE',
    },
  ];

  const aboveSliderImage = [
    {
      id: '1',
      value: 'no',
      img: require('../../assets/img/homepage/slider.png'),
    },
    {
      id: '2',
      value: 'no',
      img: require('../../assets/img/homepage/slider.png'),
    },
    {
      id: '3',
      value: 'no',
      img: require('../../assets/img/homepage/slider.png'),
    },
  ];

  const belowSliderImage = [
    {
      id: '1',
      value: 'no',

      img: require('../../assets/img/homepage/slider.png'),
    },
    {
      id: '2',
      value: 'no',

      img: require('../../assets/img/homepage/slider.png'),
    },
    {
      id: '3',
      value: 'no',

      img: require('../../assets/img/homepage/slider.png'),
    },
  ];

  return (
    <SafeAreaView style={{flex: 1}}>
      <>
        {isLoading === true ? (
          <View style={{flex: 1}}>
            <View
              style={{
                justifyContent: 'center',
                flex: 1,
                alignSelf: 'center',
                alignContent: 'center',
                alignItems: 'center',
                opacity: 0.5,
                position: 'absolute',
                backgroundColor: '#000',
                padding: 20,
                width: '100%',
                // top: Dimensions.get('window').height / 2 - 50,
                height: '100%',
                zIndex: 11,
              }}>
              <StatusBar
                backgroundColor="	#A9A9A9"
                opacity="0.5"
                barStyle="dark-content"
                hidden={true}
                // translucent
              />
              <ActivityIndicator
                color={'#fff'}
                size={35}
                style={{
                  justifyContent: 'center',
                  flex: 1,
                  alignSelf: 'center',
                  alignContent: 'center',
                  alignItems: 'center',

                  position: 'absolute',

                  zIndex: 12,
                }}
              />
            </View>
            <View style={styles.container}>
              <View
                style={{
                  flexDirection: 'row',
                  justifyContent: 'space-between',

                  alignItems: 'center',
                }}>
                <TouchableOpacity
                  onPress={() => {
                    navigation.toggleDrawer();
                    dispatch(
                      selectModelAPI({
                        rider_id: basicDetail?.rider_id || rider_id,
                      }),
                      getBasicDetailsAPI({
                        rider_id: basicDetail?.rider_id || rider_id,
                      }),
                    );
                  }}>
                  <View
                    style={{
                      height: getResHeight(40),
                      width: getResHeight(40),
                      backgroundColor: '#000055',
                      borderRadius: getResWidth(100),
                      alignItems: 'center',
                      justifyContent: 'center',
                    }}>
                    {setVectorIcon({
                      type: 'FontAwesome',
                      name: 'bars',
                      size: getFontSize(20),
                      color: '#fff',
                    })}
                  </View>
                </TouchableOpacity>
                <View
                  style={{
                    justifyContent: 'flex-start',

                    width: '60%',
                  }}>
                  <Text
                    style={{
                      color: '#000055',
                      fontSize: getFontSize(15),
                      textTransform: 'uppercase',
                      fontWeight: 800,
                    }}>
                    Hi ,{' '}
                    {basicDetail?.first_name?.length > 15
                      ? basicDetail?.first_name.substring(0, 15) + '...'
                      : basicDetail?.first_name}
                  </Text>
                </View>
                <TouchableOpacity
                  onPress={() => {
                    // navigation.navigate(PromoCode);
                    navigation.navigate('Notifications');
                  }}>
                  <View
                    style={{
                      height: getResHeight(60),
                      width: getResHeight(60),
                      alignItems: 'center',
                      justifyContent: 'center',
                    }}>
                    {setVectorIcon({
                      type: 'Ionicons',
                      name: 'notifications',
                      size: getFontSize(25),
                      color: '#000',
                    })}
                  </View>
                </TouchableOpacity>
              </View>

              <View style={styles.swiperSlider}>
                <Swiper
                  style={{}}
                  showsButtons={false}
                  loop={true}
                  autoplay={true}>
                  {aboveSliderImage.map(item => (
                    <View key={item.id} style={{flex: 1, padding: 5}}>
                      <TouchableOpacity
                        style={{
                          flex: 1,
                          justifyContent: 'center',
                          alignItems: 'center',
                          backgroundColor: '#9DD6EB',
                          borderRadius: 20,
                        }}>
                        <Image
                          source={item.img}
                          resizeMethod="auto"
                          resizeMode="cover"
                          style={{
                            width: '100%',
                            height: '100%',
                            borderRadius: 20,
                          }}
                        />
                      </TouchableOpacity>
                    </View>
                  ))}
                </Swiper>
              </View>
              <View style={{marginTop: 10}}>
                <FlatList
                  numColumns={3}
                  data={Data}
                  keyExtractor={item => item.id}
                  renderItem={({item}) => {
                    return (
                      <View
                        style={{
                          flex: 1,
                          alignItems: 'center',
                          justifyContent: 'center',
                        }}>
                        <TouchableOpacity
                          style={{
                            height: getResHeight(100),
                            width: getResHeight(100),
                            borderRadius: getResWidth(100),
                            marginBottom: getResHeight(10),
                            justifyContent: 'center',
                            alignItems: 'center',
                          }}
                          onPress={item.onPress}>
                          <Image
                            resizeMode="contain"
                            style={{
                              height: getResHeight(90),
                              width: getResHeight(90),
                              borderRadius: getResWidth(90),
                              borderWidth: 3.5,
                              borderColor: '#000055',
                            }}
                            source={item.img}
                          />
                          {/* <View
                    style={
                      {
                        // height: getResHeight(90),
                        // width: getResHeight(90),
                        // borderRadius: getResWidth(90),
                        // marginBottom: getResHeight(10),
                        // justifyContent: 'center',
                        // alignItems: 'center',
                        // borderWidth: 1,
                        // borderColor: 'blue',
                        // zIndex: 55,
                        // // backgroundColor: '#000055',
                        // position: 'absolute',
                      }
                    }>
                    <Image
                      resizeMode="contain"
                      style={{
                        height: getResHeight(70),
                        width: getResHeight(70),
                        borderRadius: getResWidth(70),
                      }}
                      source={item.img}
                    />
                    <Text
                      style={{
                        color: '#fff',
                        fontSize: getFontSize(8),
                        textTransform: 'uppercase',
                        fontWeight: 600,
                        zIndex: 55,
                        bottom: '5%',
                      }}>
                      {item.title}
                    </Text>
                  </View> */}
                        </TouchableOpacity>
                      </View>
                    );
                  }}
                />
              </View>

              <View style={styles.swiperSlider}>
                <Swiper
                  style={{}}
                  showsButtons={false}
                  loop={true}
                  autoplay={true}>
                  {belowSliderImage.map(item => (
                    <View key={item.id} style={{flex: 1, padding: 5}}>
                      <TouchableOpacity
                        style={{
                          flex: 1,
                          justifyContent: 'center',
                          alignItems: 'center',
                          backgroundColor: '#9DD6EB',
                          borderRadius: 20,
                        }}>
                        <Image
                          source={item.img}
                          resizeMethod="auto"
                          resizeMode="cover"
                          style={{
                            width: '100%',
                            height: '100%',
                            borderRadius: 20,
                          }}
                        />
                      </TouchableOpacity>
                    </View>
                  ))}
                </Swiper>
              </View>
            </View>

            <View
              style={{
                flex: 1,
                position: 'absolute',
                width: WIDTH,
                height: 110,
                bottom: -1,
              }}>
              <View
                style={{
                  zIndex: 1,
                }}>
                <TouchableOpacity
                  style={{
                    height: getResHeight(60),
                    width: getResHeight(60),
                    borderRadius: 100,
                    borderWidth: 1,
                    borderColor: '#000055',
                    backgroundColor: '#ffffff',
                    justifyContent: 'center',
                    alignItems: 'center',
                    // position: 'absolute',
                    marginTop: '10%',
                    zIndex: 1,
                    bottom: getResHeight(18),
                    alignSelf: 'center',
                  }}>
                  <Image
                    style={{
                      height: getResHeight(40),
                      width: getResHeight(40),
                      backgroundColor: '#ffffff',
                      borderRadius: 50,
                    }}
                    source={require('../../assets/img/logo.png')}
                    resizeMode="contain"
                  />
                </TouchableOpacity>
              </View>
              <Image
                style={{
                  height: 135,
                  width: WIDTH,
                  borderWidth: 5,
                  position: 'absolute',
                  bottom: 1,
                }}
                resizeMode="cover"
                source={require('../../assets/img/homepage/Background.png')}
              />

              <TouchableOpacity
                onPress={() => {
                  // dispatch(
                  //   riderCancelAPI({
                  //     CancelRide: CancelRide,
                  //   }),
                  // );

                  Linking.openURL('tel:+917208878771');
                }}
                style={{
                  position: 'absolute',
                  bottom: getResHeight(10),
                  left: getResWidth(30),
                  justifyContent: 'center',
                  alignItems: 'center',
                  zIndex: 21,
                }}>
                <Image
                  style={{height: getResHeight(20), width: getResWidth(20)}}
                  resizeMode="stretch"
                  source={require('../../assets/img/homepage/contact-us.png')}
                />
                <Text
                  style={{
                    color: '#ffffff',
                    fontSize: getFontSize(13),
                    textTransform: 'uppercase',
                    fontWeight: 800,
                  }}>
                  Contact Us
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() => {
                  navigation.navigate('MyProfile');
                }}
                style={{
                  position: 'absolute',
                  bottom: getResHeight(10),
                  right: getResWidth(25),
                  justifyContent: 'center',
                  alignItems: 'center',
                  zIndex: 21,
                }}>
                <Image
                  style={{height: getResHeight(20), width: getResWidth(20)}}
                  resizeMode="stretch"
                  source={require('../../assets/img/homepage/user.png')}
                />
                <Text
                  style={{
                    color: '#ffffff',
                    fontSize: getFontSize(13),
                    textTransform: 'uppercase',
                    fontWeight: 800,
                  }}>
                  Profile
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        ) : (
          <View style={{flex: 1}}>
            <View style={styles.container}>
              <View
                style={{
                  flexDirection: 'row',
                  justifyContent: 'space-between',

                  alignItems: 'center',
                }}>
                <TouchableOpacity
                  onPress={() => {
                    navigation.toggleDrawer();
                    dispatch(
                      selectModelAPI({
                        rider_id: basicDetail?.rider_id || rider_id,
                      }),
                      getBasicDetailsAPI({
                        rider_id: basicDetail?.rider_id || rider_id,
                      }),
                    );
                  }}>
                  <View
                    style={{
                      height: getResHeight(40),
                      width: getResHeight(40),
                      backgroundColor: '#000055',
                      borderRadius: getResWidth(100),
                      alignItems: 'center',
                      justifyContent: 'center',
                    }}>
                    {setVectorIcon({
                      type: 'FontAwesome',
                      name: 'bars',
                      size: getFontSize(20),
                      color: '#fff',
                    })}
                  </View>
                </TouchableOpacity>
                <View
                  style={{
                    justifyContent: 'flex-start',

                    // alignSelf: 'center',
                    // // right: '60%',

                    // justifyContent: 'flex-start',
                    // marginRight: '25%',
                    width: '60%',
                  }}>
                  <Text
                    style={{
                      color: '#000055',
                      fontSize: getFontSize(15),
                      textTransform: 'uppercase',
                      fontWeight: 800,
                    }}>
                    Hi ,{' '}
                    {basicDetail?.first_name?.length > 15
                      ? basicDetail?.first_name.substring(0, 15) + '...'
                      : basicDetail?.first_name}
                  </Text>
                </View>
                <TouchableOpacity
                  onPress={() => {
                    // navigation.navigate(PromoCode);
                    navigation.navigate('Notifications');
                  }}>
                  <View
                    style={{
                      height: getResHeight(60),
                      width: getResHeight(60),
                      alignItems: 'center',
                      justifyContent: 'center',
                    }}>
                    {setVectorIcon({
                      type: 'Ionicons',
                      name: 'notifications',
                      size: getFontSize(25),
                      color: '#000',
                    })}
                  </View>
                </TouchableOpacity>
              </View>

              <View style={styles.swiperSlider}>
                <Swiper
                  style={{}}
                  showsButtons={false}
                  loop={true}
                  autoplay={true}>
                  {aboveSliderImage.map(item => (
                    <View key={item.id} style={{flex: 1, padding: 5}}>
                      <TouchableOpacity
                        style={{
                          flex: 1,
                          justifyContent: 'center',
                          alignItems: 'center',
                          backgroundColor: '#9DD6EB',
                          borderRadius: 20,
                        }}>
                        <Image
                          source={item.img}
                          resizeMethod="auto"
                          resizeMode="cover"
                          style={{
                            width: '100%',
                            height: '100%',
                            borderRadius: 20,
                          }}
                        />
                      </TouchableOpacity>
                    </View>
                  ))}
                </Swiper>
              </View>
              <View style={{marginTop: 10}}>
                <FlatList
                  numColumns={3}
                  data={Data}
                  keyExtractor={item => item.id}
                  renderItem={({item}) => {
                    return (
                      <View
                        style={{
                          flex: 1,
                          alignItems: 'center',
                          justifyContent: 'center',
                        }}>
                        <TouchableOpacity
                          style={{
                            height: getResHeight(100),
                            width: getResHeight(100),
                            borderRadius: getResWidth(100),
                            marginBottom: getResHeight(10),
                            justifyContent: 'center',
                            alignItems: 'center',
                          }}
                          onPress={item.onPress}>
                          <Image
                            resizeMode="contain"
                            style={{
                              height: getResHeight(90),
                              width: getResHeight(90),
                              borderRadius: getResWidth(90),
                              borderWidth: 3.5,
                              borderColor: '#000055',
                            }}
                            source={item.img}
                          />
                          {/* <View
                      style={
                        {
                          // height: getResHeight(90),
                          // width: getResHeight(90),
                          // borderRadius: getResWidth(90),
                          // marginBottom: getResHeight(10),
                          // justifyContent: 'center',
                          // alignItems: 'center',
                          // borderWidth: 1,
                          // borderColor: 'blue',
                          // zIndex: 55,
                          // // backgroundColor: '#000055',
                          // position: 'absolute',
                        }
                      }>
                      <Image
                        resizeMode="contain"
                        style={{
                          height: getResHeight(70),
                          width: getResHeight(70),
                          borderRadius: getResWidth(70),
                        }}
                        source={item.img}
                      />
                      <Text
                        style={{
                          color: '#fff',
                          fontSize: getFontSize(8),
                          textTransform: 'uppercase',
                          fontWeight: 600,
                          zIndex: 55,
                          bottom: '5%',
                        }}>
                        {item.title}
                      </Text>
                    </View> */}
                        </TouchableOpacity>
                      </View>
                    );
                  }}
                />
              </View>

              <View style={styles.swiperSlider}>
                <Swiper
                  style={{}}
                  showsButtons={false}
                  loop={true}
                  autoplay={true}>
                  {belowSliderImage.map(item => (
                    <View key={item.id} style={{flex: 1, padding: 5}}>
                      <TouchableOpacity
                        style={{
                          flex: 1,
                          justifyContent: 'center',
                          alignItems: 'center',
                          backgroundColor: '#9DD6EB',
                          borderRadius: 20,
                        }}>
                        <Image
                          source={item.img}
                          resizeMethod="auto"
                          resizeMode="cover"
                          style={{
                            width: '100%',
                            height: '100%',
                            borderRadius: 20,
                          }}
                        />
                      </TouchableOpacity>
                    </View>
                  ))}
                </Swiper>
              </View>
            </View>

            <View
              style={{
                flex: 1,
                position: 'absolute',
                width: WIDTH,
                height: 110,
                bottom: -1,
              }}>
              <View
                style={{
                  zIndex: 1,
                }}>
                <TouchableOpacity
                  style={{
                    height: getResHeight(60),
                    width: getResHeight(60),
                    borderRadius: 100,
                    borderWidth: 1,
                    borderColor: '#000055',
                    backgroundColor: '#ffffff',
                    justifyContent: 'center',
                    alignItems: 'center',
                    // position: 'absolute',
                    marginTop: '10%',
                    zIndex: 1,
                    bottom: getResHeight(18),
                    alignSelf: 'center',
                  }}>
                  <Image
                    style={{
                      height: getResHeight(40),
                      width: getResHeight(40),
                      backgroundColor: '#ffffff',
                      borderRadius: 50,
                    }}
                    source={require('../../assets/img/logo.png')}
                    resizeMode="contain"
                  />
                </TouchableOpacity>
              </View>
              <Image
                style={{
                  height: 135,
                  width: WIDTH,
                  borderWidth: 5,
                  position: 'absolute',
                  bottom: 1,
                }}
                resizeMode="cover"
                source={require('../../assets/img/homepage/Background.png')}
              />

              <TouchableOpacity
                onPress={() => {
                  // dispatch(
                  //   riderCancelAPI({
                  //     CancelRide: CancelRide,
                  //   }),
                  // );

                  Linking.openURL('tel:+917208878771');
                }}
                style={{
                  position: 'absolute',
                  bottom: getResHeight(10),
                  left: getResWidth(30),
                  justifyContent: 'center',
                  alignItems: 'center',
                  zIndex: 21,
                }}>
                <Image
                  style={{height: getResHeight(20), width: getResWidth(20)}}
                  resizeMode="stretch"
                  source={require('../../assets/img/homepage/contact-us.png')}
                />
                <Text
                  style={{
                    color: '#ffffff',
                    fontSize: getFontSize(13),
                    textTransform: 'uppercase',
                    fontWeight: 800,
                  }}>
                  Contact Us
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() => {
                  navigation.navigate('MyProfile');
                }}
                style={{
                  position: 'absolute',
                  bottom: getResHeight(10),
                  right: getResWidth(25),
                  justifyContent: 'center',
                  alignItems: 'center',
                  zIndex: 21,
                }}>
                <Image
                  style={{height: getResHeight(20), width: getResWidth(20)}}
                  resizeMode="stretch"
                  source={require('../../assets/img/homepage/user.png')}
                />
                <Text
                  style={{
                    color: '#ffffff',
                    fontSize: getFontSize(13),
                    textTransform: 'uppercase',
                    fontWeight: 800,
                  }}>
                  Profile
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        )}
      </>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: getResWidth(8),
    // backgroundColor: 'red',
  },
  swiperSlider: {
    height: '23%',
    justifyContent: 'center',
    alignSelf: 'center',
    borderRadius: 15,
  },
});
