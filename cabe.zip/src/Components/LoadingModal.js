import React from 'react';
import {Text, View, Modal, Image} from 'react-native';
import theme from '../theme';

export function LoadingModal(props) {
  const {loadingModal} = props;
  return (
    <Modal animationType="fade" transparent={true} visible={loadingModal}>
      <View
        style={{
          flex: 1,
          backgroundColor: theme.color.BACKGROUND,
          justifyContent: 'center',
          alignItems: 'center',
        }}>
        <View
          style={{
            width: '85%',
            // backgroundColor: '#fff',
            borderRadius: 10,
            flex: 1,
            maxHeight: 200,
          }}>
          <View
            style={{
              alignItems: 'center',
              //   flexDirection: isRTL ? 'row-reverse' : 'row',
              flex: 1,
              justifyContent: 'center',
            }}>
            <Image
              style={{
                width: 80,
                height: 80,
                backgroundColor: theme.TRANSPARENT,
              }}
              source={require('../../src/assets/img/loader.gif')}
            />
            <Text
              style={{
                color: 'red',
                fontSize: 16,
                //   textAlign: isRTL ? 'right' : 'left',
              }}>
              {/* {t('driver_finding_alert')}
               */}
              ddda fdsfsfsfaea es
            </Text>
            <View style={{flex: 1}}>
              <Text
                style={{
                  color: theme.BLACK,
                  fontSize: 16,
                  //   textAlign: isRTL ? 'right' : 'left',
                }}>
                {/* {t('driver_finding_alert')}
                 */}
                ddda fdsfsfsfaea es
              </Text>
            </View>
          </View>
        </View>
      </View>
    </Modal>
  );
}
