import React, {useState, useRef, useEffect} from 'react';
import {View, Text, TouchableOpacity, TextInput, Alert} from 'react-native';
import theme from '../../theme';
import {getFontSize, getResHeight} from '../../utility/responsive';
import {useRoute} from '@react-navigation/native';
import OTPResend from '../../Components/OTPResend';
import AsyncStorage from '@react-native-async-storage/async-storage';

import {login, onBoarding, userDetail} from '../../features/auth/authAPI';
import {useDispatch, useSelector} from 'react-redux';
import {
  authAPI,
  getBasicDetailsAPI,
} from '../../features/basicdetails/basicdetail';
import {getUserSession, setUserSession} from '../../config/session';

import {store} from '../../store';
import {BASE_URL} from '../../config/constants';
import {ActivityIndicator} from 'react-native-paper';

function VerifyOtp({navigation}) {
  const user = store.getState().auth.userLog;
  const {_id, phone_number, status} = user || {}; // Destructuring user object

  const [isVerifyLoading, setIsVerifyLoading] = useState(false);
  const [otp, setOtp] = useState('');
  const [error, setError] = useState(null);

  const refs = [useRef(null), useRef(null), useRef(null), useRef(null)];
  const dispatch = useDispatch();
  const {loggedIn} = useSelector(state => state.auth);

  useEffect(() => {
    if (loggedIn) {
      navigateToHomeScreen();
    }
  }, [loggedIn]);

  const navigateToHomeScreen = () => {
    navigation.reset({
      index: 0,
      routes: [{name: 'MainDrawer'}],
    });
  };

  const handleChange = (value, index) => {
    setOtp(prev => {
      const otpArray = prev.split('');
      otpArray[index] = value;
      return otpArray.join('');
    });
    if (value.length > 0 && index < refs.length - 1) {
      refs[index + 1].current.focus();
    } else if (value.length === 0 && index > 0) {
      refs[index - 1].current.focus();
    }
  };

  const handleVerifyOTP = () => {
    setIsVerifyLoading(true);
    fetch(`${BASE_URL}/api/verifyWithOtp`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({otp, phone_number, _id}),
    })
      .then(async response => {
        setIsVerifyLoading(false);
        if (response.status === 200) {
          const payload = {
            otp,
            phone_number,
            _id,
            rider_id: _id,
          };

          dispatch(login(payload));
          dispatch(authAPI({client_id: _id}));
          dispatch(getBasicDetailsAPI(payload));
          setUserSession();
          getUserSession();
          await AsyncStorage.setItem(
            'loginDetails',
            JSON.stringify({otp, phone_number, _id}),
          );
          dispatch(login({otp, phone_number, _id}));

          if (status === 'active') {
            navigation.navigate('RegisterEmail');
          } else {
            navigateToHomeScreen();
          }
        } else {
          setError('Invalid Mobile or OTP');
        }
      })
      .catch(error => setError(error.message));
  };

  const isButtonDisabled = otp.length !== 4;

  return (
    <View style={{flex: 1}}>
      <View
        style={{
          justifyContent: 'center',
          padding: 30,
          marginTop: '15%',
        }}>
        <Text
          style={{
            fontSize: getFontSize(30),
            color: theme.color.BLACK,
          }}>
          OTP Verification
        </Text>
        <Text style={{fontSize: 18, marginTop: 10}}>
          Enter the 4-digit code sent to you at
        </Text>

        <View style={{flexDirection: 'row'}}>
          <TouchableOpacity onPress={() => navigation.goBack()}>
            <Text
              style={{
                color: theme.color.primary,
                fontWeight: '900',
                fontSize: getFontSize(15),
              }}>
              {phone_number} Edit
            </Text>
          </TouchableOpacity>
        </View>

        <View
          style={{
            flexDirection: 'row',
            justifyContent: 'space-around',
            marginBottom: '15%',
            marginTop: '10%',
          }}>
          {[0, 1, 2, 3].map(index => (
            <TextInput
              key={index}
              maxLength={1}
              style={{
                borderBottomWidth: 4,
                borderBottomColor: '#000',
                flex: 0.2,
                textAlign: 'center',
                fontSize: 25,
              }}
              ref={refs[index]}
              returnKeyType="next"
              onChangeText={value => handleChange(value, index)}
              value={otp[index] || ''}
              blurOnSubmit={false}
              keyboardType="numeric"
              autoFocus={index === 0}
            />
          ))}
        </View>

        {error && (
          <Text
            style={{
              color: 'red',
              fontSize: getFontSize(15),
              fontWeight: '600',
            }}>
            {error}
          </Text>
        )}
        <OTPResend />
      </View>
      {isVerifyLoading ? (
        <ActivityIndicator color={theme.color.primary} size={29} />
      ) : (
        <TouchableOpacity
          style={{
            width: '90%',
            alignItems: 'center',
            position: 'absolute',
            alignSelf: 'center',
            justifyContent: 'center',
            bottom: 15,
            backgroundColor: !isButtonDisabled ? '#000055' : '#ddd',
            borderRadius: 12,
            padding: 11,
          }}
          onPress={handleVerifyOTP}
          disabled={isButtonDisabled} // Use the disabled state for the button
        >
          <Text
            style={{
              width: '95%',
              textAlign: 'center',
              fontSize: 18,
              color: '#fff',
            }}>
            Verify
          </Text>
        </TouchableOpacity>
      )}
    </View>
  );
}

export default VerifyOtp;
