import {combineReducers} from 'redux';

const RESET_STORE = 'RESET_STORE';
export const resetStore = () => {
  return {
    type: RESET_STORE,
  };
};

import authAPI from './auth/authAPI';
import location from './location/location';
import rider from './CreateToRide';
import hub from './hub';
import basicDetail from './basicdetails';
import Fare from './Fare';
import sos from './sos';
import reviewQuestion from './Review';
import Address from './Address';
// import {reviewQuestion} from './Review';

const initialState = {
  auth: {onBoarding: false},
  location: {},
  rider: {},
  hub: {},
  basicDetail: {},
  fare: {},
  sos: {},
  reviewQuestion: {},
  Address: {},
};

const rootReducer = (state = initialState, action) => {
  if (action.type === RESET_STORE) {
    return initialState;
  }
  return combineReducers({
    auth: authAPI,
    location: location,
    rider: rider,
    hub: hub,
    basicDetail: basicDetail,
    fare: Fare,
    sos: sos,
    reviewQuestion: reviewQuestion,
    Address: Address,
  })(state, action);
};

export default rootReducer;
