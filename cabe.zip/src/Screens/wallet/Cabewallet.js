import {
  StyleSheet,
  View,
  Text,
  Button,
  Image,
  SafeAreaView,
  FlatList,
  TouchableOpacity,
} from 'react-native';
import {createStackNavigator} from '@react-navigation/stack';
import React, {useState, defaultProps, propTypes, PropTypes} from 'react';
import {Alert} from 'react-native/Libraries/Alert/Alert';
import {TextInput} from 'react-native-gesture-handler';
// import Icon from 'react-native-vector-icons/EvilIcons';
import Icon from 'react-native-vector-icons/FontAwesome';
import arrowdown from 'react-native-vector-icons/Feather';
import Icon2 from 'react-native-vector-icons/FontAwesome';
import {RadioButton} from 'react-native-paper';
import theme from '../../theme';
import {getResHeight, getResWidth} from '../../utility/responsive';
import {Header} from 'react-native-elements';

const DATA = [
  {
    id: 'bd7acbea-c1b1-46c2-aed5-3ad53abb28ba',
    title: 'Daniel Austin',
    icon: 'wallet',
    icon2: 'rupee',
    subtitle: 'Dec 20 , 2024 | 10:00 AM',
    amount: '400',
    arrowdown: 'arrow-down',
  },
  {
    id: 'bd7acbea-c1b1-46c2-aed5-3ad53abb28ba',
    title: 'Daniel Austin',
    icon: 'wallet',
    icon2: 'rupee',
    subtitle: 'Dec 20 , 2024 | 10:00 AM',
    amount: '400',
    arrowdown: 'arrow-down',
  },
  {
    id: 'bd7acbea-c1b1-46c2-aed5-3ad53abb28ba',
    title: 'Daniel Austin',
    icon: 'wallet',
    icon2: 'rupee',
    subtitle: 'Dec 20 , 2024 | 10:00 AM',
    amount: '400',
    arrowdown: 'arrow-down',
  },
];

const Item = ({...props}) => (
  <View style={{flex: 1}}>
    <View
      style={{
        borderBottomWidth: 1,
        borderBottomColor: '#efebeb',
        width: '90%',
        alignSelf: 'center',
      }}
    />
    <View
      style={{
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-around',
      }}>
      <View
        style={{
          borderRadius: 150,
          marginLeft: '5%',
          backgroundColor: '#e6d8b3',
          justifyContent: 'center',
          height: '76%',
          width: '14.2%',
          alignItems: 'center',
          // opacity: 0.8,
        }}>
        <View
          style={{
            borderRadius: 150,
            height: '78%',
            width: '74%',
            justifyContent: 'center',
            backgroundColor: '#febd20',
            alignItems: 'center',
          }}>
          <Icon
            style={{
              color: '#000',
              width: 80,
              padding: 1,
              fontSize: 20,
              textAlign: 'center',
              borderRadius: 20,
            }}
            name={props.icon}
          />
        </View>
      </View>
      <View
        style={{
          paddingVertical: 17,
        }}>
        <Text
          style={{
            fontSize: 17,
            fontWeight: '800',
            color: '#000',
          }}>
          <Text style={{}}>{props.title}</Text>
        </Text>
        <Text
          style={{
            fontSize: 13,
            color: theme.color.primary,
            width: '100%',
            fontWeight: '700',
            fontFamily: theme.font.ThinItalic,
          }}>
          {props.subtitle}
        </Text>
      </View>

      <View
        style={{
          flexDirection: 'column',
        }}>
        <View
          style={{
            flexDirection: 'row',
          }}>
          <Icon2
            style={{
              color: '#000',
              fontSize: 21,
              marginTop: '5%',
              textAlign: 'center',
            }}
            name={props.icon2}
          />
          <Text
            style={{
              fontSize: 18,
              fontWeight: '800',
              color: '#000',
            }}>
            {props.amount}
          </Text>
        </View>

        <View
          style={{
            flexDirection: 'row',
            // width: '20%',
          }}>
          <Text
            style={{
              fontSize: 15,
              fontWeight: '400',
              color: '#000',
            }}>
            Expense
          </Text>
          <View
            style={{
              backgroundColor: 'green',
              padding: 1,
              position: 'relative',
              marginLeft: '5%',
            }}>
            <Icon2
              style={{
                color: '#000',
                fontSize: 18,
              }}
              name={props.arrowdown}
            />
          </View>
        </View>
      </View>
    </View>
  </View>
);

export default function Cabewallet({navigation}) {
  const [checked, setChecked] = useState('first');
  return (
    <>
      <SafeAreaView style={{}}>
        <Header
          centerComponent={
            <Text
              style={{
                color: 'FFF',
                fontFamily: 'Roboto-Bold',
                fontSize: 20,
              }}>
              newsta
            </Text>
          }
          containerStyle={{backgroundColor: 'fff', borderBottomWidth: 0}}
          innerContainerStyles={{marginLeft: 10, marginRight: 10}}
        />
        <View style={{height: '50%'}}>
          <View
            style={{
              backgroundColor: '#d6daf3',
              height: getResHeight(150),
              width: getResWidth(300),
              justifyContent: 'center',
              alignContent: 'center',
              alignSelf: 'center',
              alignItems: 'center',
              marginTop: '5%',
              borderRadius: 35,
            }}>
            <Image
              style={{
                borderRadius: 15,
                margin: 20,
                resizeMode: 'center',
                height: '40%',
                width: '60%',
              }}
              source={require('../../../src/assets/img/logo.png')}
            />
            <View
              style={{
                flexDirection: 'row',
                justifyContent: 'space-between',
                width: '80%',
                // bottom: '2%',
              }}>
              <View
                style={{
                  flexDirection: 'row',
                }}>
                <Icon2
                  style={{
                    color: '#000',
                    fontSize: 21,
                    marginTop: '12%',
                    textAlign: 'center',
                  }}
                  name="rupee"
                />
                <Text
                  style={{
                    fontSize: 25,
                    color: '#000',
                    marginTop: '7%',
                    fontFamily: theme.font.ExtraLight,
                  }}>
                  550
                </Text>
              </View>
              <TouchableOpacity
                style={{
                  padding: 10,
                  backgroundColor: '#959fe2',
                  borderRadius: 24,
                  marginTop: '2%',
                }}>
                <Text
                  style={{
                    fontSize: 20,
                    width: '100%',
                    fontWeight: 'bold',
                    fontWeight: '900',
                    color: 'white',
                  }}>
                  TOP UP
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>

        <FlatList
          data={DATA}
          renderItem={({item}) => (
            <Item
              title={item.title}
              icon={item.icon}
              icon2={item.icon2}
              subtitle={item.subtitle}
              amount={item.amount}
              arrowdown={item.arrowdown}
            />
          )}
          keyExtractor={item => item.id}
        />
      </SafeAreaView>
    </>
  );
}
