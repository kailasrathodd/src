import React from 'react';
import {createNativeStackNavigator} from '@react-navigation/native-stack';
import GetInTouch from './GetInTouch';
import ChargingStation from './ChargingStation';
import PrivacyPolicy from './PrivacyPolicy';
import TermCondition from './TermCondition';

const Stack = createNativeStackNavigator();

function GetInTouchStack({navigation}, props) {
  // const PrivayPolicy = () => {
  //   const [isLoading, setIsLoading] = React.useState(true);
  //   const [isError, setIsError] = React.useState(false);
  //   return (
  //     <View style={{flex: 1}}>
  //       <Header
  //         containerStyle={{
  //           width: '90%',
  //           alignSelf: 'center',
  //           marginRight: '5%',
  //         }}
  //         title={'Privacy & Policy'}
  //         backPress={() => {
  //           navigation.pop();
  //         }}
  //         {...props}
  //       />
  //       {isLoading && <ActivityIndicator size="large" color="#0000ff" />}
  //       {isError && (
  //         <View
  //           style={{flex: 1, alignItems: 'center', justifyContent: 'center'}}>
  //           <Text>Page not found</Text>
  //         </View>
  //       )}
  //       <WebView
  //         source={{uri: 'http://192.168.0.25:8000/api/privacy_policy'}}
  //         onLoad={() => setIsLoading(true)}
  //         onLoadEnd={() => setIsLoading(false)}
  //         onError={() => setIsError(true)}
  //       />
  //     </View>
  //   );
  // };

  // const TermCondition = () => {
  //   return (
  //     <>
  //       <Header
  //         containerStyle={{
  //           width: '90%',
  //           alignSelf: 'center',
  //           marginRight: '5%',
  //         }}
  //         title={'Term & Condition'}
  //         backPress={() => {
  //           navigation.pop();
  //         }}
  //         {...props}
  //       />
  //       <WebView
  //         source={{uri: 'http://192.168.0.25:8000/api/term_condition'}}
  //       />
  //     </>
  //   );
  // };

  return (
    <Stack.Navigator
      screenOptions={{
        headerTitleAlign: 'center',
      }}
      {...props}>
      <Stack.Screen
        name="GetInTouch"
        component={GetInTouch}
        options={{
          headerShown: false,
        }}
        // options={{
        //   headerTitle: 'Get in Touch',
        //   headerTitleAlign: 'center',
        //   headerLeft: () => (
        //     <Icon
        //       name="arrow-left"
        //       onPress={() => navigation.navigate('Home')}
        //       style={{
        //         fontSize: 20,
        //         color: 'black',
        //       }}
        //     />
        //   ),
        // }}
      />
      <Stack.Screen
        name="PrivayPolicy"
        component={PrivacyPolicy}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="TermCondition"
        component={TermCondition}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="ChargingStation"
        component={ChargingStation}
        options={{
          headerShown: false,
        }}
      />
    </Stack.Navigator>
  );
}

export default GetInTouchStack;
