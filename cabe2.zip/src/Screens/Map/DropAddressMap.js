import React, {useState, useEffect, useRef} from 'react';
import {View, Keyboard} from 'react-native';
import MapplsGL from 'mappls-map-react-native';
// import // Toast from 'react-native-simple-// Toast';
import {validateCoordinates} from '../../utility/Validate';
import {connect} from 'react-redux';
import {AddressPinDrop} from '../../features/location/location';
import {RideUpdateAPI} from '../../features/basicdetails/basicdetail';

const DropAddressMap = ({
  AddressPinDrop,
  RideUpdateAPI,
  ridr_id,
  pickUpeLoc,
  dropeLoc,
  drop,
  pickUp,
}) => {
  const [latitude, setLatitude] = useState('');
  const [longitude, setLongitude] = useState('');
  const [markerLat, setMarkerLat] = useState('');
  const [markerLng, setMarkerLng] = useState('');
  const [label, setLabel] = useState('');
  const [center, setCenter] = useState([72.8484724, 19.20425071]);
  const cameraRef = useRef(null);

  useEffect(() => {
    // Toast.show('press on map to call revgeocode api', // Toast.SHORT);
    revGeoCodeApi(19.206811694710566, 72.84045608606192);
  }, []);

  const revGeoCodeApi = (lat, lng) => {
    MapplsGL.RestApi.reverseGeocode({latitude: lat, longitude: lng})
      .then(data => {
        RideUpdateAPI({
          rider_id: ridr_id,
          drop_address: data.results[0].formatted_address,
          drop_latitude: data.results[0].lat,
          drop_longitude: data.results[0].lng,
          drop_details: data.results[0],
        });
        AddressPinDrop(data.results[0]);
        // Toast.show(data.results[0].formatted_address, // Toast.SHORT);
        setLabel(data.results[0].formatted_address);
      })
      .catch(error => {
        console.log('fail: ' + error.message);
        // Toast.show(error.message);
      });
  };

  const onClick = () => {
    if (validateCoordinates(longitude, latitude)) {
      revGeoCodeApi(latitude, longitude);
      setMarkerLat(parseFloat(latitude));
      setMarkerLng(parseFloat(longitude));
      setCenter([parseFloat(longitude), parseFloat(latitude)]);
      moveCamera(latitude, longitude);
      Keyboard.dismiss();
    }
  };

  const moveCamera = (latitude, longitude) => {
    cameraRef.current.moveTo([longitude, latitude]);
  };

  const onPress = event => {
    const {geometry, properties} = event;
    const longitude = geometry.coordinates[0];
    const latitude = geometry.coordinates[1];
    setMarkerLat(parseFloat(latitude));
    setMarkerLng(parseFloat(longitude));
    // setCenter([parseFloat(latitude), parseFloat(latitude)]);
    revGeoCodeApi(latitude, longitude);
  };

  const marker =
    markerLat !== '' && markerLng !== '' ? (
      <MapplsGL.PointAnnotation
        id="markerId"
        title="Marker"
        coordinate={[markerLng, markerLat]}>
        <MapplsGL.Callout title={label} />
      </MapplsGL.PointAnnotation>
    ) : null;

  return (
    <View style={{flex: 1}}>
      <MapplsGL.MapView style={{flex: 1}} onPress={e => onPress(e)}>
        <MapplsGL.Camera
          zoomLevel={12}
          ref={cameraRef}
          centerCoordinate={center}
        />
        {marker}
      </MapplsGL.MapView>
    </View>
  );
};

const mapDispatchToProps = {
  AddressPinDrop,
  RideUpdateAPI,
};

const mapStateToProps = (state, props) => ({
  pickUpeLoc: state.location.pickUpeLoc,
  dropeLoc: state.location.dropeLoc,
  drop: state.location.AddressPinDrop,
  pickUp: state.location.AddressPinPickUP,
  ridr_id: state.auth.user._id,
});

export default connect(mapStateToProps, mapDispatchToProps)(DropAddressMap);
