import {View, Text} from 'react-native';
import React from 'react';

const Dropdown = () => {
  return (
    <View>
      <Text>Dropdown</Text>
    </View>
  );
};

export default Dropdown;
