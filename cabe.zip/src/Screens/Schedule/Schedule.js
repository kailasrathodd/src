import React, {useState} from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  SafeAreaView,
  Alert,
} from 'react-native';
import DatePickerModal from 'react-native-modal-datetime-picker';
import TimePickerModal from 'react-native-modal-datetime-picker';
import {getFontSize} from '../../utility/responsive';
import setVectorIcon from '../../Components/VectorComponents';
import Header from '../../Components/HeaderComp';
import PlacePicker from '../Map/PlacePicker';

const Schedule = ({navigation}, props) => {
  const [selectedDateTime, setSelectedDateTime] = useState({
    date: '',
    time: 'Select Time',
  });
  const [isDatePickerVisible, setDatePickerVisibility] = useState(false);
  const [isTimePickerVisible, setTimePickerVisibility] = useState(false);

  const handleConfirmDate = date => {
    const currentDate = new Date();
    const selectedDate = new Date(date);
    const sevenDaysAhead = new Date();
    sevenDaysAhead.setDate(currentDate.getDate() + 7);
    if (selectedDate >= currentDate && selectedDate <= sevenDaysAhead) {
      const options = {
        weekday: 'short',
        month: 'short',
        day: 'numeric',
      };

      const dateLocale = date.toLocaleDateString('en-US', options);
      const formattedDate = dateLocale.toUpperCase();

      setSelectedDateTime({
        ...selectedDateTime,
        date: formattedDate,
      });
    } else {
      setSelectedDateTime({
        ...selectedDateTime,
        date: '',
      });
    }

    hideDatePicker();
  };

  const handleConfirmTime = time => {
    const hours = time.getHours();
    const minutes = time.getMinutes();
    let period = 'AM';

    let formattedHours = hours;
    if (hours > 12) {
      formattedHours = hours - 12;
      period = 'PM';
    } else if (hours === 12) {
      period = 'PM';
    } else if (hours === 0) {
      formattedHours = 12;
    }

    const selectedTime = `${formattedHours
      .toString()
      .padStart(2, '0')}:${minutes.toString().padStart(2, '0')} ${period}`;

    setSelectedDateTime({
      ...selectedDateTime,
      time: selectedTime,
    });

    hideTimePicker();
  };

  const showDatePicker = () => {
    setDatePickerVisibility(true);
  };

  const showTimePicker = () => {
    setTimePickerVisibility(true);
  };

  const hideDatePicker = () => {
    setDatePickerVisibility(false);
  };

  const hideTimePicker = () => {
    setTimePickerVisibility(false);
  };

  return (
    <SafeAreaView style={{flex: 1}}>
      <View style={{flex: 1, width: '90%', alignSelf: 'center'}}>
        <Header
          containerStyle={{
            width: '100%',
            // height: '100%',
            alignSelf: 'center',

            marginTop: '7.4%',
          }}
          title={''}
          backPress={() => {
            navigation.navigate('HomeScreen');
          }}
          {...props}
        />

        <Text
          style={{
            fontSize: getFontSize(22),
            color: 'black',
            fontWeight: '900',
            alignSelf: 'center',
            textAlign: 'center',
            width: '75%',
            marginTop: '15%',
            lineHeight: 35,
          }}>
          WHEN SHOULD YOUR CAB ARRIVE ?
        </Text>

        <View style={styles.dateTimeContainer}>
          <TouchableOpacity
            onPress={showDatePicker}
            style={styles.pickerButton}>
            <DatePickerModal
              display="inline"
              locale="en_GB"
              isVisible={isDatePickerVisible}
              mode="date"
              onConfirm={handleConfirmDate}
              onCancel={hideDatePicker}
              minimumDate={new Date()}
              maximumDate={new Date().setDate(new Date().getDate() + 7)} // Limit maximum selectable date
            />
            <Text style={styles.pickerText}>
              {selectedDateTime.date || 'Select Date'}
            </Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={showTimePicker} style={{}}>
            <TimePickerModal
              locale="en_GB"
              isVisible={isTimePickerVisible}
              mode="time"
              onConfirm={handleConfirmTime}
              onCancel={hideTimePicker}
            />
            <Text style={styles.pickerText}>{selectedDateTime.time}</Text>
          </TouchableOpacity>
        </View>

        <View
          style={{justifyContent: 'center', width: '90%', alignSelf: 'center'}}>
          <View style={{flexDirection: 'row'}}>
            {setVectorIcon({
              type: 'MaterialCommunityIcons',
              name: 'calendar-check',
              size: getFontSize(25),
              color: '#000',
            })}
            <Text
              style={{
                fontSize: getFontSize(18),
                marginLeft: '5%',

                marginTop: '-3%',
                color: '#000',
                lineHeight: 26,
              }}>
              Select your Date & Time Up-To 7 Days For Travel
            </Text>
          </View>
          <View style={{flexDirection: 'row', marginTop: '10%'}}>
            {setVectorIcon({
              type: 'MaterialCommunityIcons',
              name: 'clock-time-three',
              size: getFontSize(25),
              color: '#000',
            })}
            <Text
              style={{
                fontSize: getFontSize(18),
                marginLeft: '5%',

                marginTop: '-3%',
                color: '#000',
                lineHeight: 26,
              }}>
              Zero waiting charges - wait time 15 minutes
            </Text>
          </View>
          <View style={{flexDirection: 'row', marginTop: '10%'}}>
            {setVectorIcon({
              type: 'MaterialCommunityIcons',
              name: 'credit-card',
              size: getFontSize(25),
              color: '#000',
            })}
            <Text
              style={{
                fontSize: getFontSize(18),
                marginLeft: '5%',

                color: '#000',
              }}>
              Zero cancellation charges
            </Text>
          </View>
        </View>

        <TouchableOpacity
          style={{justifyContent: 'center', marginLeft: '5%', marginTop: '2%'}}>
          <Text
            style={{
              fontSize: getFontSize(15),

              marginTop: '3%',
              color: '#000',
              lineHeight: 26,
              fontWeight: '900',
            }}>
            See Terms
          </Text>
        </TouchableOpacity>
      </View>
      <TouchableOpacity
        style={styles.button}
        onPress={() => Alert.alert('Schedule', 'Coming Soon')}>
        <Text style={styles.buttonText}>Next</Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  title: {
    fontSize: 30,
    color: 'black',
    fontWeight: 'bold',
    alignSelf: 'center',
    textAlign: 'center',
    marginTop: 30,
  },
  dateTimeContainer: {
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 50,
    marginVertical: 20,
    // padding: 15,
    // backgroundColor: '#f9c74f',
    // borderRadius: 10,
  },
  pickerButton: {
    height: 35,
    width: '50%',
    borderBottomWidth: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  pickerText: {
    fontSize: 25,
    color: 'black',
  },
  infoContainer: {},
  infoItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 10,
  },
  infoIcon: {
    color: 'black',
  },
  infoText: {
    marginLeft: 15,
    fontSize: 18,
  },
  termsLink: {
    fontSize: 15,
    textDecorationLine: 'underline',
    textDecorationStyle: 'solid',
    color: 'black',
    marginLeft: 40,
  },
  button: {
    alignSelf: 'center',

    height: 45,
    borderRadius: 15,
    backgroundColor: '#000066',
    width: '90%',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: '5%',
  },
  buttonText: {
    color: 'white',
  },
});

export default Schedule;
