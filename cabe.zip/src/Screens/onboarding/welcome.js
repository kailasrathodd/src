import React, {useEffect} from 'react';

import {
  Button,
  View,
  ImageBackground,
  Text,
  Image,
  Alert,
  TouchableOpacity,
  StyleSheet,
  TextInput,
} from 'react-native';

export default function Login({navigation}, props) {
  useEffect(() => {
    setTimeout(() => {
      navigation.navigate('VerifyOtp');
    }, 1000);
  }, []);
  return (
    <ImageBackground
      source={require('../../assets/img/first_bg.png')}
      resizeMode="cover"
      style={{
        flex: 1,
        width: '100%',
        height: '100%',
        alignItems: 'center',
        justifyContent: 'space-between',
      }}>
      <View
        style={{
          justifyContent: 'center',
          alignItems: 'center',
          top: 50,
          flex: 1,
        }}>
        <Image
          source={require('../../assets/img/logo.png')}
          style={{width: 200, height: 100}}
        />
      </View>
      <View style={{justifyContent: 'center', alignItems: 'center', flex: 3}}>
        <Image
          source={require('../../assets/img/car_reg.png')}
          style={{width: 450, height: 200}}
        />
      </View>
      <View
        style={{
          position: 'absolute',
          height: '100%',
          width: '100%',
          backgroundColor: '#000',
          opacity: 0.5,
        }}></View>
      <View
        style={{
          position: 'relative',
          bottom: 30,
          flex: 1,
        }}>
        <TouchableOpacity
          style={{
            backgroundColor: '#3db24b',
            flex: 1,
            flexDirection: 'row',
            marginHorizontal: 20,
            marginVertical: 10,
            borderRadius: 25,
            alignItems: 'center',
            justifyContent: 'center',
          }}
          onPress={() => navigation.navigate('Registration')}>
          <Text
            style={{
              width: '100%',
              textAlign: 'center',
              fontSize: 20,
              color: '#fff',
              fontWeight: 'bold',
            }}>
            SIGN IN
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => navigation.navigate('Registration')}
          style={{
            backgroundColor: '#3db24b',
            flex: 1,
            marginHorizontal: 20,
            marginVertical: 10,
            borderRadius: 25,
            alignItems: 'center',
            justifyContent: 'center',
          }}>
          <Text
            style={{
              width: '100%',
              textAlign: 'center',
              fontSize: 20,
              color: '#fff',
              fontWeight: 'bold',
            }}>
            SIGN UP
          </Text>
        </TouchableOpacity>
      </View>
    </ImageBackground>
  );
}
