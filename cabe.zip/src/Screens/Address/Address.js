import React, {useEffect, useState} from 'react';
import {useSelector, useDispatch} from 'react-redux';
import {
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  SafeAreaView,
  FlatList,
  ActivityIndicator,
} from 'react-native';
import {RadioButton} from 'react-native-paper';
import {useNavigation} from '@react-navigation/native';
import Header from '../../Components/HeaderComp';
import setVectorIcon from '../../Components/VectorComponents';
import {getFontSize, getResHeight} from '../../utility/responsive';
import {
  deleteAddressAPI,
  getAddressAPI,
  selectedAddressAPI,
} from '../../features/Address/AddressAPI';

const AddressItem = React.memo(
  ({
    addressName,
    address,
    checked,
    onPress,
    onDelete,
    onEdit,
    isLoadingDeleteItemId,
    isDefaultAddress,
  }) => {
    const isLoading = isLoadingDeleteItemId === addressName;
    const shortAddressName =
      addressName?.length > 15 ? addressName.slice(0, 15) + '...' : addressName;

    return (
      <View style={styles.addressContainer}>
        <View style={[styles.iconContainer, {backgroundColor: 'red'}]}>
          {setVectorIcon({
            type: 'MaterialIcons',
            name: 'location-pin',
            size: getFontSize(25),
            color: '#fff',
          })}
        </View>
        <View style={{flexDirection: 'column', padding: 10}}>
          <Text style={styles.addressName}>{address}</Text>
          <Text style={styles.addressText}>{shortAddressName}</Text>
        </View>
        <TouchableOpacity onPress={onDelete} style={styles.deleteButton}>
          {isLoading ? (
            <ActivityIndicator size="small" color="red" />
          ) : (
            setVectorIcon({
              type: 'MaterialIcons',
              name: 'delete',
              size: getFontSize(20),
              color: 'red',
            })
          )}
        </TouchableOpacity>
        <TouchableOpacity onPress={onEdit} style={styles.editButton}>
          {setVectorIcon({
            type: 'MaterialIcons',
            name: 'edit',
            size: getFontSize(20),
            color: 'blue',
          })}
        </TouchableOpacity>
        <RadioButton
          value="checked"
          status={isDefaultAddress ? 'checked' : 'unchecked'}
          onPress={onPress}
        />
      </View>
    );
  },
);

const Address = () => {
  const navigation = useNavigation();
  const dispatch = useDispatch();
  const rider_id = useSelector(state => state.auth.user?._id);
  const getAddressData = useSelector(state => state.Address.getAddress);
  const defaultAddressId = useSelector(
    state => state.Address.selectedAddAddress.address_id,
  );
  const [getAddress, setGetAddress] = useState([]);
  const [isLoadingDeleteItemId, setIsLoadingDeleteItemId] = useState(null);

  useEffect(() => {
    fetchAddressData();
  }, []);

  useEffect(() => {
    setGetAddress(getAddressData || []);
  }, [getAddressData]);

  const fetchAddressData = () => {
    dispatch(getAddressAPI({rider_id}));
  };

  const handleAddressItemPress = itemKey => {
    dispatch(selectedAddressAPI({address_id: itemKey}));
    const updatedAddresses = getAddress.map(item =>
      item._id === itemKey
        ? {...item, checked: true}
        : {...item, checked: false},
    );
    setGetAddress(updatedAddresses);
  };

  const handleDeleteAddress = (itemValue, addressName) => {
    setIsLoadingDeleteItemId(addressName);

    const payload = {address_id: itemValue};
    dispatch(deleteAddressAPI(payload))
      .then(() => {
        const updatedAddresses = getAddress.filter(
          item => item._id !== itemValue,
        );
        setGetAddress(updatedAddresses);
      })
      .catch(error => {
        console.error(error);
      })
      .finally(() => {
        setIsLoadingDeleteItemId(null);
      });
  };

  const handleEditAddress = itemValue => {
    const selectedAddress = getAddress.find(item => item._id === itemValue);
    if (selectedAddress) {
      navigation.navigate('AddAddress', {addressData: selectedAddress});
    }
  };

  const renderAddressItem = ({item}) => (
    <AddressItem
      addressName={item.address_details}
      address={item.address}
      checked={item.checked}
      onDelete={() => handleDeleteAddress(item._id, item.address_details)}
      onEdit={() => handleEditAddress(item._id)}
      onPress={() => handleAddressItemPress(item._id)}
      isLoadingDeleteItemId={isLoadingDeleteItemId}
      isDefaultAddress={item._id === defaultAddressId}
    />
  );

  return (
    <SafeAreaView style={styles.container}>
      <Header
        containerStyle={{
          width: '100%',
          alignSelf: 'center',
        }}
        title={'Address'}
        backPress={() => navigation.navigate('HomeScreen')}
        addPress={
          getAddress.length !== 5
            ? () => navigation.navigate('AddAddress')
            : null
        }
      />
      <View style={styles.contentContainer}>
        {getAddress.length === 0 ? (
          <View style={styles.emptyListContainer}>
            <Text style={styles.emptyListText}>No Record Found.</Text>
          </View>
        ) : (
          <FlatList
            data={getAddress}
            renderItem={renderAddressItem}
            keyExtractor={item => item._id}
            style={styles.addressList}
          />
        )}
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  contentContainer: {
    flex: 1,
    paddingHorizontal: '5%',
  },
  addressList: {
    marginTop: '5%',
  },
  addressContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 15,
    marginBottom: '5%',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  iconContainer: {
    borderRadius: 50,
    height: getResHeight(40),
    width: getResHeight(40),
    alignItems: 'center',
    justifyContent: 'center',
  },
  addressName: {
    fontSize: 18,
    fontWeight: '700',
    color: '#000',
  },
  addressText: {
    fontSize: 13,
    fontWeight: '300',
    color: '#000',
    alignSelf: 'center',
  },
  deleteButton: {},
  deleteButtonText: {
    color: '#fff',
    fontWeight: 'bold',
  },
  emptyListContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  emptyListText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
  },
});

export default Address;
