/* eslint-disable react-native/no-inline-styles */
import React from 'react';
import {View, Modal} from 'react-native';
import {ColorPicker} from 'react-native-color-picker';

class RNColorPicker extends React.Component {
  render() {
    return (
      <Modal
        animationType="slide"
        transparent={true}
        visible={this.props.visible}
        onRequestClose={this.props.onRequestClose}>
        <View
          style={{
            flex: 1,
            justifyContent: 'center',
            alignItems: 'center',
            marginTop: 22,
          }}>
          <View
            style={{
              margin: 20,
              backgroundColor: 'white',
              borderRadius: 20,
              padding: 35,
              alignItems: 'center',
              shadowColor: '#000',
              shadowOffset: {
                width: 0,
                height: 2,
              },
              shadowOpacity: 0.25,
              shadowRadius: 4,
              elevation: 5,
            }}>
            <ColorPicker
              onColorSelected={this.props.onColorSelected}
              defaultColor={this.props.defaultColor}
              style={{flex: 1, width: 300}}
            />
          </View>
        </View>
      </Modal>
    );
  }
}

export default RNColorPicker;
