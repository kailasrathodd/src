import React, {Component} from 'react';
import {View, Keyboard} from 'react-native';
import MapplsGL from 'mappls-map-react-native';
// import // Toast from 'react-native-simple-// Toast';import {validateCoordinates} from '../../utility/Validate';
import {connect} from 'react-redux';
import {AddressPinPickUP} from '../../features/location/location';
class NewMap extends Component {
  constructor(props) {
    super(props);
    this.state = {
      latitude: '',
      logitude: '',
      markerLat: '',
      AddressPinPickUP: null,
      markerLng: '',
      label: '',
      center: [77.61234, 27.61234],
    };
  }

  componentDidMount() {
    // Toast.show('press on map to call revgeocode api', // Toast.SHORT);
    //this.revGeoCodeApi(27.61234, 77.61234);
  }

  revGeoCodeApi(lat, lng) {
    MapplsGL.RestApi.reverseGeocode({latitude: lat, longitude: lng})
      .then(data => {
        // console.tron.log(data.results[0]);
        this.props.AddressPinPickUP(data.results[0]);
        // Toast.show(data.results[0].formatted_address, // Toast.SHORT);
        this.setState({
          label: data.results[0].formatted_address,
        });
      })
      .catch(error => {
        console.log('fail: ' + error.message);
        // Toast.show(error.message);
      });
  }

  onClick() {
    const latitude = this.state.latitude;
    const logitude = this.state.logitude;
    if (validateCoordinates(logitude, latitude)) {
      this.revGeoCodeApi(latitude, logitude);
      this.setState({
        markerLat: parseFloat(latitude),
        markerLng: parseFloat(logitude),
        center: [parseFloat(logitude), parseFloat(latitude)],
      });
      //this.moveCamera(latitude, logitude);
      Keyboard.dismiss();
    }
  }

  moveCamera(latitude, longitude) {
    this.camera.moveTo([longitude, latitude]);
  }

  onPress = event => {
    const {geometry, properties} = event;
    const longitude = geometry.coordinates[0];
    const latitude = geometry.coordinates[1];
    // // Toast.show("Longitude :"+longitude+" Latitude :"+latitude,// Toast.SHORT);
    this.setState({
      markerLat: parseFloat(latitude),
      markerLng: parseFloat(longitude),
      //center:[parseFloat(logitude),parseFloat(latitude)]
    });
    this.revGeoCodeApi(latitude, longitude);
  };

  render() {
    const marker =
      this.state.markerLat != '' && this.state.markerLng != '' ? (
        <MapplsGL.PointAnnotation
          id="markerId"
          title="Marker"
          coordinate={[this.state.markerLng, this.state.markerLat]}>
          <MapplsGL.Callout title={this.state.label} />
        </MapplsGL.PointAnnotation>
      ) : null;

    return (
      <View style={{flex: 1}}>
        <MapplsGL.MapView style={{flex: 1}} onPress={e => this.onPress(e)}>
          <MapplsGL.Camera
            zoomLevel={12}
            ref={c => (this.camera = c)}
            centerCoordinate={this.state.center}
          />
          {marker}
        </MapplsGL.MapView>
      </View>
    );
  }
}

const mapDispatchToProps = {
  AddressPinPickUP,
};

export default connect(null, mapDispatchToProps)(NewMap);
