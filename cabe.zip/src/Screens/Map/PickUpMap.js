import React, {Component} from 'react';
import {View, Keyboard, PermissionsAndroid, Platform} from 'react-native';
import MapplsGL from 'mappls-map-react-native';
import {connect} from 'react-redux';
import {RideUpdateAPI} from '../../features/basicdetails/basicdetail';
import {
  AddressPinPickUP,
  updateLocation,
} from '../../features/location/location';
import RNAndroidLocationEnabler from 'react-native-android-location-enabler';
import {Button, Icon} from 'react-native-elements';
import * as Permissions from 'react-native-permissions';
class PickUpMap extends Component {
  constructor(props) {
    super(props);
    this.state = {
      latitude: '',
      longitude: '',
      gpsState: false,
      markerLat: '19.20425071',
      AddressPinPickUP: null,
      markerLng: '72.8484724',
      label: '',
      center: [72.8484724, 19.20425071],
      location: [72.8484724, 19.20425071],
    };
  }

  componentDidMount() {
    MapplsGL.locationManager.start();
    // this.props.AddressPin(this.props.label);
  }
  componentDidMount() {
    MapplsGL.locationManager.start();
  }

  componentWillUnmount() {
    MapplsGL.locationManager.stop();
  }

  revGeoCodeApi(lat, lng) {
    MapplsGL.RestApi.reverseGeocode({latitude: lat, longitude: lng})
      .then(data => {
        this.props.AddressPinPickUP(data.results[0]);

        this.props.RideUpdateAPI({
          rider_id: this.props.ridr_id,
          pickup_address: data.results[0].formatted_address,
          pickup_latitude: data.results[0].lat,
          pickup_longitude: data.results[0].lng,
          pickup_details: data.results[0],
        });
        this.setState({
          label: data.results[0].formatted_address,
        });
      })
      .catch(error => {
        console.log('fail: ' + error.message);
        // Toast.show(error.message);
      });
  }

  onClick() {
    const latitude = this.state.latitude;
    const longitude = this.state.longitude;
    if (validateCoordinates(longitude, latitude)) {
      this.revGeoCodeApi(latitude, longitude);
      this.setState({
        markerLat: parseFloat(latitude),
        markerLng: parseFloat(longitude),
        center: [parseFloat(longitude), parseFloat(latitude)],
      });
      //this.moveCamera(latitude, longitude);
      Keyboard.dismiss();
    }
  }

  moveCamera(latitude, longitude) {
    this.camera.moveTo([longitude, latitude]);
  }

  onPress = event => {
    const {geometry, properties} = event;
    const longitude = geometry.coordinates[0];
    const latitude = geometry.coordinates[1];
    this.setState({
      markerLat: parseFloat(latitude),
      markerLng: parseFloat(longitude),
    });
    this.revGeoCodeApi(latitude, longitude);
  };
  async requestLocationPermission() {
    if (Platform.OS === 'ios') {
      const {status} = await Permissions.request(
        Permissions.PERMISSIONS.IOS.LOCATION_WHEN_IN_USE,
      );
      return status;
    } else {
      const granted = await PermissionsAndroid.request(
        PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
        {
          title: 'Location Permission',
          message: 'CabeApp needs access to your location.',
          buttonNeutral: 'Ask Me Later',
          buttonNegative: 'Cancel',
          buttonPositive: 'OK',
        },
      );
      if (granted === PermissionsAndroid.RESULTS.GRANTED) {
        return 'granted';
      } else {
        return 'denied';
      }
    }
  }
  onUpdate(location) {
    const {latitude, longitude, accuracy} = location.coords;
    this.setState({
      latitude,
      longitude,
    });
    this.props.updateLocation({latitude, longitude});

    this.props.RideUpdateAPI({
      rider_id: this.props.ridr_id,
      current_loc: {latitude, longitude},
    });
  }
  onPressLocationButton() {
    this.requestLocationPermission().then(status => {
      const latitude = this.state.latitude;
      const longitude = this.state.longitude;
      if (latitude !== '') {
        this.revGeoCodeApi(latitude, longitude);
        this.camera.moveTo([longitude, latitude]);
        this.camera.zoomTo(12, 1000);
        this.setState({
          markerLat: parseFloat(latitude),
          markerLng: parseFloat(longitude),
          center: [parseFloat(longitude), parseFloat(latitude)],
        });
      }

      if (status === 'granted') {
        this.camera.zoomTo(18);
      } else {
        this.camera.zoomTo(20);
      }
    });
  }
  onfloatingButtonClick() {
    if (Platform.OS == 'android') {
      RNAndroidLocationEnabler.promptForEnableLocationIfNeeded({
        interval: 1000,
        fastInterval: 5000,
      })
        .then(data => {
          this.setState({
            gpsState: true,
          });
        })
        .catch(err => {
          // Toast.show('Please enable gps.');
        });
    } else {
      this.setState({
        gpsState: true,
      });
    }
  }
  async onMarkerClick(e) {
    const f = e.features;
    console.log(JSON.stringify(f));
    this.camera.setCamera();

    if (!f.properties.cluster) {
      console.log('marker click ' + JSON.stringify(f));
      console.log('markerID: ' + f.properties.id);
    } else {
      console.log(f);
      this.camera.setCamera({
        zoomLevel: 10,
        animationDuration: 1000,
        centerCoordinate: [
          f.geometry.coordinates[0],
          f.geometry.coordinates[1],
        ],
      });
    }
  }

  render() {
    const locationComponent = this.state.gpsState ? (
      <MapplsGL.UserLocation
        animated={true}
        visible={true}
        onUpdate={location => this.onUpdate(location)}
      />
    ) : null;
    const marker =
      this.state.markerLat != '' && this.state.markerLng != '' ? (
        <MapplsGL.PointAnnotation
          id="markerId"
          // draggable={true}
          title="Marker"
          coordinate={[this.state.markerLng, this.state.markerLat]}>
          <MapplsGL.Callout title={this.state.label} />
        </MapplsGL.PointAnnotation>
      ) : null;

    return (
      <View style={{flex: 1}}>
        <MapplsGL.MapView style={{flex: 1}} onPress={e => this.onPress(e)}>
          <MapplsGL.Camera
            zoomLevel={12}
            animationMode="flyTo"
            ref={c => (this.camera = c)}
            centerCoordinate={this.state.center}
          />

          {marker}

          {locationComponent}
        </MapplsGL.MapView>
        <View
          style={{
            width: 50,
            height: 50,
            backgroundColor: 'transparent',
            position: 'absolute',
            top: '80%',
            left: '80%',
            zIndex: 10,
          }}>
          <Button
            icon={<Icon name="my-location" size={35} color="white" />}
            onPress={() => {
              this.onfloatingButtonClick();
              this.onPressLocationButton();
              const latitude = this.state.latitude;
              const longitude = this.state.longitude;
              if (latitude !== '') {
                this.revGeoCodeApi(latitude, longitude);
                this.setState({
                  markerLat: parseFloat(latitude),
                  markerLng: parseFloat(longitude),
                  center: [parseFloat(longitude), parseFloat(latitude)],
                });
              }
            }}
          />
        </View>
      </View>
    );
  }
}

const mapDispatchToProps = {
  AddressPinPickUP,
  updateLocation,
  RideUpdateAPI,
};
const mapStateToProps = (state, props) => ({
  pickUpeLoc: state.location.pickUpeLoc,
  dropeLoc: state.location.dropeLoc,
  drop: state.location.AddressPinDrop,
  pickUp: state.location.AddressPinPickUP,
  ridr_id: state.auth.user?._id,
  basicDetail: state.basicDetail.basicDetail,
});
export default connect(mapStateToProps, mapDispatchToProps)(PickUpMap);
