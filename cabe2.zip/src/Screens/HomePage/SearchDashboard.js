/* eslint-disable react-native/no-inline-styles */
/* eslint-disable react-hooks/exhaustive-deps */
import React, {useEffect} from 'react';
import {View, Text, TouchableOpacity} from 'react-native';
import {useDispatch, useSelector} from 'react-redux';
import {getFontSize} from '../../utility/responsive';
import {getBasicDetailsAPI} from '../../features/basicdetails/basicdetail';
import Header from '../../Components/HeaderComp';
import MapplsPlacePicker from '../Map/MapplsPlacePicker';
import {resetPin, typeLocation} from '../../features/location/location';
import setVectorIcon from '../../Components/VectorComponents';

export default function SearchDashboard({navigation}) {
  const dispatch = useDispatch();
  const riderUpdate = useSelector(
    state => state.basicDetail?.riderUpdate?.Rider_Data,
  );
  const basicDetail = useSelector(state => state.basicDetail?.basicDetail);
  const rider_id = useSelector(state => state.auth.user?._id);

  useEffect(() => {
    dispatch(getBasicDetailsAPI({rider_id: rider_id}));
  }, []);

  return (
    <View style={{position: 'relative', height: '100%'}}>
      <View style={{width: '100%', height: '100%'}}>
        <MapplsPlacePicker />
      </View>

      <View
        style={{
          zIndex: 1,
          position: 'absolute',
          width: '100%',
          paddingHorizontal: 20,
          flexDirection: 'row',
          justifyContent: 'space-between',
        }}>
        <Header
          containerStyle={{
            width: '100%',
            alignSelf: 'center',
          }}
          title={''}
          backPress={() => {
            navigation.navigate('HomeScreen');
          }}
          {...this.props}
        />
      </View>

      <View
        style={{
          paddingHorizontal: 20,
          paddingVertical: 20,
          backgroundColor: '#fFf',
          borderRadius: 20,
          width: '90%',
          margin: 20,
          top: '10%',
          zIndex: 1,
          position: 'absolute',
        }}>
        <View>
          <Text
            style={{
              fontSize: getFontSize(14),
              fontWeight: '600',
              color: '#ddd',
              paddingLeft: 1,
              borderRadius: 50,
              backgroundColor: '#fff',
              flexDirection: 'row',
              justifyContent: 'center',
              margin: 1,
            }}>
            {setVectorIcon({
              type: 'Entypo',
              name: 'controller-record',
              size: getFontSize(15),
              color: '#000',
            })}{' '}
            Pickup Location
          </Text>
          <View
            style={{
              color: '#ddd',
              backgroundColor: '#fff',
              justifyContent: 'space-between',
            }}>
            <TouchableOpacity
              style={{
                borderColor: '#ddd',
                borderBottomWidth: 0.21,
                width: '100%',
                textAlign: 'left',
                fontSize: getFontSize(14),
                padding: 10,
              }}
              onPress={() => {
                dispatch(resetPin(true));
                dispatch(typeLocation('PickUp'));
                navigation.navigate('PickupSearch');
              }}>
              {basicDetail && riderUpdate.pickup_address !== null ? (
                <Text style={{color: '#000', opacity: 0.51, width: '100%'}}>
                  {riderUpdate?.pickup_address || 'Enter Your Pickup Location'}
                </Text>
              ) : (
                <Text style={{color: '#000', opacity: 0.51, width: '100%'}}>
                  {riderUpdate?.pickup_address || 'Enter Your Pickup Location'}
                </Text>
              )}
            </TouchableOpacity>
          </View>
        </View>
        <View>
          <Text
            style={{
              fontSize: getFontSize(14),
              fontWeight: '600',
              color: '#ddd',
              paddingLeft: 1,
              borderRadius: 50,
              backgroundColor: '#fff',
              flexDirection: 'row',
              justifyContent: 'center',
              margin: 1,
            }}>
            {setVectorIcon({
              type: 'Entypo',
              name: 'controller-record',
              size: getFontSize(15),
              color: '#000',
            })}{' '}
            Drop Location
          </Text>
          <View
            style={{
              color: '#ddd',
              backgroundColor: '#fff',
              justifyContent: 'space-between',
            }}>
            <TouchableOpacity
              style={{
                borderColor: '#ddd',
                borderBottomWidth: 0.21,
                width: '100%',
                fontSize: getFontSize(14),
                padding: 10,
                flexDirection: 'row',
              }}
              onPress={() => {
                dispatch(resetPin(true));
                dispatch(typeLocation('Drop'));
                navigation.navigate('DropSearch');
              }}>
              <Text style={{color: '#000', opacity: 0.51, width: '100%'}}>
                Enter Your Drop Location
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </View>
  );
}
