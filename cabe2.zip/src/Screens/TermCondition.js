import React from 'react';
import {StyleSheet, Text, View, ActivityIndicator} from 'react-native';
import WebView from 'react-native-webview';
import Header from '../Components/HeaderComp';

const TermCondition = ({navigation}, props) => {
  const [isLoading, setIsLoading] = React.useState(true);
  return (
    <View style={{flex: 1}}>
      <Header
        containerStyle={{
          alignSelf: 'center',
        }}
        title={'Term & Condition'}
        backPress={() => {
          navigation.pop();
        }}
        {...props}
      />
      <View style={{flex: 1}}>
        {isLoading && <ActivityIndicator size="large" color="#0000ff" />}

        <WebView
          source={{uri: 'http://192.168.0.25:8000/api/term_condition'}}
          onLoad={() => setIsLoading(true)}
          onLoadEnd={() => setIsLoading(false)}
        />
      </View>
    </View>
  );
};

export default TermCondition;

const styles = StyleSheet.create({});
