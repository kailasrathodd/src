import React, {Component} from 'react';
import {
  Text,
  View,
  TouchableOpacity,
  StyleSheet,
  ActivityIndicator,
  Button,
  Modal,
} from 'react-native';
import MapplsGL from 'mappls-map-react-native';
import Polyline from 'mappls-polyline';
import {Platform} from 'react-native';
import MyContext from '../utility/MyContext';
import exampleIcon from '../assets/img/marker.png';
import {connect} from 'react-redux';
import {myDistance, myDuration} from '../features/location/location';
const styles = {
  icon: {
    iconImage: exampleIcon,
    iconAllowOverlap: true,
    iconSize: 5,
    iconAnchor: 'bottom',
  },
};

const layerStyles = {
  route: {
    lineColor: 'black',
    lineCap: 'round',
    lineJoin: 'round',
    lineWidth: 5,
  },
};

class GetDirectionAPP extends Component {
  constructor(props) {
    super(props);
    // this.handleClick();
    this.state = {
      distance: '',
      duration: '',
      route: '',
      backW: 'blue',
      backD: 'blue',
      backB: 'blue',
      isVisible: false,
      // sourceCoordinates: this.props.pickUpeLoc,
      sourceCoordinates: this.props.basicDetail?.pickup_Eloc,
      destinationCoordinates: this.props.basicDetail?.drop_Eloc,
      center: [78.186982, 29.554676],
      markerSourceCoordinates: [
        this.props.basicDetail?.pickup_longitude,
        this.props.basicDetail?.pickup_latitude,
      ],
      markerDestCoordinates: [
        this.props.basicDetail?.drop_latitude,
        this.props.basicDetail?.drop_longitude,
      ],
      markerSourceEloc: null,
      markerDestEloc: null,
    };
  }

  handleClick = () => {
    console.log(
      'DDD',
      this.props.markerDestCoordinates,
      this.props.markerSourceCoordinates,
      this.props.basicDetail?.drop_longitude,
      this.props.basicDetail?.drop_latitude,
    );

    myDistance(this.state.distance);
    this.props.onData(this.state);
  };

  callApi(setProfile) {
    const sCoordinates = this.state?.sourceCoordinates?.split(',');
    const dCoordinates = this.state?.destinationCoordinates?.split(',');

    MapplsGL.RestApi.direction({
      origin: this.state.sourceCoordinates,
      destination: this.state.destinationCoordinates,
      profile: setProfile,
      overview: MapplsGL.RestApi.DirectionsCriteria.OVERVIEW_FULL,
      geometries: 'polyline6',
    })
      .then(data => {
        console.log(JSON.stringify(data));

        let routeGeoJSON = Polyline.toGeoJSON(data.routes[0].geometry, 6);
        //let bound = bbox(routeGeoJSON);
        //console.log(JSON.stringify(routeGeoJSON));
        this.setState({
          distance: this.getFormattedDistance(data.routes[0].distance),
          duration: this.getFormattedDuration(data.routes[0].duration),
          route: routeGeoJSON,
          center: routeGeoJSON.coordinates[0],
        });
      })
      .catch(error => {
        console.tron.log(error);
        // // Toast.show(error.message, // Toast.SHORT);
      });
  }

  componentDidMount() {
    this.callApi('driving');
    myDuration(this.state.duration);
    myDistance(this.state.duration);

    this.setState({
      backD: 'white',
    });
  }

  componentDidUpdate() {
    this.handleClick();
    myDuration(this.state.duration);
    myDistance(this.state.duration);
  }

  getFormattedDistance(distance) {
    if (distance / 1000 < 1) {
      return distance + 'mtr.';
    }
    let dis = distance / 1000;
    dis = dis.toFixed(2);
    return dis + 'Km.';
  }

  getFormattedDuration(duration) {
    let min = parseInt(duration / 60);
    // let hours = parseInt((duration % 86400) / 3600);
    // let days = parseInt(duration / 86400);

    return min;
    // if (days > 0) {
    //   return (
    //     days +
    //     ' ' +
    //     (days > 1 ? 'Days' : 'Day') +
    //     ' ' +
    //     hours +
    //     ' ' +
    //     'hr' +
    //     (min > 0 ? ' ' + min + ' ' + 'min.' : '')
    //   );
    // } else {
    //   return hours > 0
    //     ? hours + ' ' + 'hr' + (min > 0 ? ' ' + min + ' ' + 'min' : '')
    //     : min + ' ' + 'min.';
    // }
  }

  render() {
    const keyBoardBehaviour = Platform.OS === 'android' ? 'height' : 'padding';

    const destMarker = (
      // <MapplsGL.ShapeSource
      //   id="symbolLocationSource"
      //   shape={point(this.state.markerDestCoordinates)}>
      //   <MapplsGL.SymbolLayer
      //     id="symbolLocationSymbols"
      //     minZoomLevel={1}
      //     style={styles.icon}
      //   />
      // </MapplsGL.ShapeSource>
      <MapplsGL.PointAnnotation
        id="markerId"
        title="Marker"
        onSelected={() => {}}
        onDeselected={() => {}}
        mapplsPin={this.state.destinationCoordinates}>
        <MapplsGL.Callout title={this.state.distance} />
      </MapplsGL.PointAnnotation>
    );

    const soruceMarker = (
      // <MapplsGL.ShapeSource
      //   id="symbolLocationSource2"
      //   shape={point(this.state.markerSourceCoordinates)}>
      //   <MapplsGL.SymbolLayer
      //     id="symbolLocationSymbols2"
      //     minZoomLevel={1}
      //     style={styles.icon}
      //   />
      // </MapplsGL.ShapeSource>
      <MapplsGL.PointAnnotation
        id="markerId"
        title="Marker"
        minZoomLevel={1}
        maxZoomLevel={8}
        zoomLevel={5}
        onSelected={() => {}}
        onDeselected={() => {}}
        // mapplsPin='C7JXWD'
        mapplsPin={this.state.sourceCoordinates}>
        <MapplsGL.Callout title={this.state.duration} />

        <MapplsGL.MarkerView />
      </MapplsGL.PointAnnotation>
    );

    if (this.state.route === '') {
      return (
        <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
          <ActivityIndicator animating={true} />
        </View>
      );
    }

    return (
      <MyContext.Provider value={this.state}>
        {/* <View
          style={{
            // backgroundColor: 'none',
            flexDirection: 'row',
            height: '10%',
            alignItems: 'center',
            paddingLeft: 5,
          }}>
          <Text style={{color: 'red'}}>{this.state.distance}</Text>
          <Text>({this.state.duration} M) </Text>
        </View> */}
        <View style={{flex: 1}}>
          <MapplsGL.MapView style={{flex: 1}}>
            <MapplsGL.Camera
              zoomLevel={11}
              ref={c => (this.camera = c)}
              centerCoordinate={this.state.center}
            />

            <MapplsGL.ShapeSource id="routeSource" shape={this.state.route}>
              <MapplsGL.LineLayer id="routeFill" style={layerStyles.route} />
            </MapplsGL.ShapeSource>
            {soruceMarker}
            {destMarker}

            {/* <MapplsGL.MarkerView
              coordinate={[this.props.pickUp?.lng, this.props?.pickUp?.lat]}>
              <MapplsGL.Callout title={this.props.pickUpLocation} />
            </MapplsGL.MarkerView>
            <MapplsGL.MarkerView
              coordinate={[this.props.drop.lng, this.props.drop.lat]}>
              <MapplsGL.Callout title={this.props.dropLocation} />
            </MapplsGL.MarkerView> */}
          </MapplsGL.MapView>
        </View>
      </MyContext.Provider>
    );
  }
}

const style = StyleSheet.create({
  buttons: {justifyContent: 'center', alignItems: 'center', flex: 1},
  text: {fontWeight: 'bold'},
});

const mapDispatchToProps = dispatch => {
  return {
    myDistance: payload => dispatch(myDistance(payload)),
    myDuration: payload => dispatch(myDuration(payload)),
  };
};
const mapStateToProps = (state, props) => ({
  pickUpLocation: state.location.pickUpLocation,
  dropLocation: state.location.dropLocation,
  drop: state.location.AddressPinDrop,
  pickUp: state.location.AddressPinPickUP,
  basicDetail: state.basicDetail.basicDetail,
});
export default connect(mapStateToProps, mapDispatchToProps)(GetDirectionAPP);
