/* eslint-disable no-undef */
import {createAsyncThunk} from '@reduxjs/toolkit';
import API from '../../APIs/RepositoryFactory';

import * as rider from './index';
import {store} from '../../store';

export const selectModelAPI = createAsyncThunk(
  'selectModelAPI/selectModelAPI',
  async (payload, thunkAPI) => {
    try {
      const response = await API.RiderRepository.searchParentCategory(payload);
      if (response) {
        thunkAPI.dispatch(rider.setselectModel(response.data.data));
      }
      return response.data.data;
    } catch (error) {
      error;
    }
  },
);
export const fareCalculateAPI = createAsyncThunk(
  'fareCalculateAPI/fareCalculateAPI',
  async (payload, thunkAPI) => {
    try {
      const response = await API.RiderRepository.FareCalCordinate(payload);
      // console.tron.log('payload payload', response.data);
      if (response) {
        thunkAPI.dispatch(rider.FareCal(response?.data));
      }
      return response;
    } catch (error) {
      error;
    }
  },
);
export const CreaterideAPI = createAsyncThunk(
  'CreaterideAPI/CreaterideAPI',
  async (payload, thunkAPI) => {
    try {
      const response = await API.RiderRepository.RiderCreateToRide(payload);
      // console.tron.log('payload payload', response.data.status);
      if (response.data.status === 200) {
        thunkAPI.dispatch(rider.CreateRide(response.data?.data));
      }
      return response.data;
    } catch (error) {
      error;
    }
  },
);
export const getDriverAPI = createAsyncThunk(
  'getDriverAPI/getDriverAPI',
  async (payload, thunkAPI) => {
    try {
      if (store.getState().auth.onBoarding === true) {
        const response = await API.RiderRepository.getDriver(payload);
        if (response.data.status === 200) {
          thunkAPI.dispatch(rider.getDriver(response.data.data));
        }
      } // console.log('payload payload', response.data);
      return response.data;
    } catch (error) {
      error;
    }
  },
);
export const riderJourneyHistoryAPI = createAsyncThunk(
  'riderJourneyHistoryAPI/riderJourneyHistoryAPI',
  async (payload, thunkAPI) => {
    try {
      if (store.getState().auth.onBoarding === true) {
        const response = await API.RiderRepository.riderJourneyHistory(payload);
        if (response.data.status === 200) {
          thunkAPI.dispatch(rider.riderJourneyHistory(response.data.data));
        }
      }
      return response.data;
    } catch (error) {
      error;
    }
  },
);

export const getRideDetailAPI = createAsyncThunk(
  'hub/getRideDetailAPI',
  async (payload, thunkAPI) => {
    try {
      if (store.getState().auth.onBoarding === true) {
        const response = await API.RiderRepository.GetRideDetail(payload);

        if (response.data.status === 200) {
          const rideDetail = response.data.data;
          thunkAPI.dispatch(rider.GetRideDetail(rideDetail));
        }
      }
      return response;
    } catch (error) {
      error;
    }
  },
);
export const driveLocAPI = createAsyncThunk(
  'driveLocAPI/driveLocAPI',
  async (payload, thunkAPI) => {
    try {
      if (store.getState().auth.onBoarding === true) {
        const response = await API.RiderRepository.getDriveLoc(payload);

        if (response.data.status === 200) {
          const rideDetail = response.data.location;
          thunkAPI.dispatch(rider.getDriverLoc(rideDetail));
        }
      }
      return response;
    } catch (error) {
      error;
    }
  },
);
export const paymentAttributesAPI = createAsyncThunk(
  'paymentAttributesAPI/paymentAttributesAPI',
  async (payload, thunkAPI) => {
    try {
      const response = await API.RiderRepository.paymentAttributes(payload);
      if (response.data.status === 200) {
        const rideDetail = response.data.data;
        thunkAPI.dispatch(rider.paymentAttributes(rideDetail));
      }
      return response;
    } catch (error) {
      error;
    }
  },
);
export const rideTimeOutAPI = createAsyncThunk(
  'rideTimeOutAPI/rideTimeOutAPI',
  async (payload, thunkAPI) => {
    try {
      const response = await API.RiderRepository.rideTimeOutAPI(payload);
      if (response.data.status === 200) {
        const rideDetail = response.data.data;
        thunkAPI.dispatch(rider.rideTimeOut(rideDetail));
      }
    } catch (error) {
      error;
    }
  },
);
