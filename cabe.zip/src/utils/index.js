import {Platform} from 'react-native';
import {store} from '../store';

export const IS_ANDROID = Platform.OS === 'android';
export const DEFAULT_CENTER_COORDINATE = [72.877426, 19.07609];
export const MyLocation = [72.877426, 19.07609];
export const DROPLOC = [DROP_latitude, DROP_longitude];
// export const PICKLOC = PICK_latitude, PICKLOC_longitude
export const DROP_longitude =
  store.getState().basicDetail?.basicDetail?.drop_longitude;
export const DROP_latitude =
  store.getState().basicDetail.basicDetail.drop_latitude;
export const PICKLOC_longitude =
  store.getState().basicDetail.basicDetail.pickup_longitude;
export const PICK_latitude =
  store.getState().basicDetail.basicDetail.pickup_latitude;
