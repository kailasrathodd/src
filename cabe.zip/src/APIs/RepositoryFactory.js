import RiderRepository from './RiderRepository';
import authRepository from './authRepository';
import hubRepository from './hubRepository';
import fareRepository from './fareRepository';
import sosRepository from './sosRepository';
import reviewRepository from './reviewRepository';
import AddressRepository from './AddressRepository';
export default repositories = {
  authRepository,
  RiderRepository,
  hubRepository,
  fareRepository,
  sosRepository,
  reviewRepository,
  AddressRepository,
};
