import {Dimensions} from 'react-native';
import {store} from '../store';
export const SCREEN_SIZE = Dimensions.get('window');
export const STATUS_BAR_COLOR = 'white';
export const islive = true;
const access_token = store.getState().auth?.authApi?.access_token;
const token = store.getState().auth?.mappleToken?.accessToken;
export const razorpay_key_id = 'rzp_test_6puyR1hr49TSCJ';
export const razorpay_secret_key = '7INhBkFUNOZPuCH9Eepreba7';
export const BASE_URL = islive
  ? 'http://hostbrick.net.in'
  : 'http://192.168.0.20:8000';
export const APP_BASE_URL = 'http://hostbrick.net.in';
export const MapplsGL_URL = 'https://explore.mappls.com';
export const UAT_URL = 'http://192.168.0.32:8001';
export const HEADERS = {
  'Content-Type': 'application/json',
  // Authorization: `Bearer ${access_token}`,
  'cache-control': 'no-cache, private',
};
export const Image_Header = {
  'Content-Type': 'multipart/form-data',
  // Authorization: `Bearer ${access_token}`,
  Accept: 'application/json',
};
export const HEADERS_MAPPLE = {
  'Content-Type': 'application/json',
  Authorization: `Bearer ${token}`,
};

export const VERSION = '1.02';
