import {
  StyleSheet,
  Text,
  View,
  Alert,
  Share,
  Button,
  Image,
  ScrollView,
  Linking,
  Dimensions,
  Modal,
  Pressable,
  TextInput,
  SafeAreaView,
} from 'react-native';
import React, {useState} from 'react';
import BottomSheet from 'react-native-simple-bottom-sheet';
import {TouchableOpacity} from 'react-native-gesture-handler';
import {getFontSize, getResHeight} from '../../utility/responsive';
import Header from '../../Components/HeaderComp';
import LiveLoacation from '../Map/liveLoacation';
import {useDispatch, useSelector} from 'react-redux';
import {
  ProfileUpdateAPI,
  RideUpdateAPI,
  getBasicDetailsAPI,
} from '../../features/basicdetails/basicdetail';

export default function AddAddress({navigation}, props) {
  const [addressName, setAddressName] = React.useState('');
  const [address, setAddress] = React.useState('');
  const dispatch = useDispatch();
  const rider_id = useSelector(state => state.auth.user?._id);
  return (
    <View style={{position: 'relative', height: '100%'}}>
      <>
        <Header
          containerStyle={{
            width: '100%',
            alignSelf: 'center',
          }}
          title={'Add New Address'}
          backPress={() => {
            navigation.navigate('HomeScreen');
          }}
          {...this.props}
        />
        <View
          style={{
            position: 'absolute',
            bottom: 0,
            width: '100%',
            height: getResHeight(250),
          }}>
          <BottomSheet
            isOpen
            innerContentStyle={{
              width: '100%',
              height: '100%',
            }}
            sliderMaxHeight={460}>
            <View>
              <View
                style={{
                  borderBottomWidth: 1,
                  borderColor: '#ddd',
                  paddingBottom: 20,
                  justifyContent: 'center',
                }}>
                <Text
                  style={{
                    fontSize: getFontSize(getFontSize(20)),
                    textAlign: 'center',
                    color: '#000',
                    fontWeight: 'bold',
                    marginTop: '5%',
                  }}>
                  Add Address
                </Text>
              </View>

              <View>
                <Text
                  style={{
                    paddingLeft: 10,
                    color: '#000',
                    fontWeight: '800',
                    fontSize: getFontSize(20),
                  }}>
                  Address
                </Text>

                <TextInput
                  value={addressName}
                  onChangeText={setAddressName}
                  placeholder="Address Name"
                  style={{
                    width: '100%',
                    fontSize: getFontSize(15),
                    fontWeight: '600',
                    backgroundColor: '#ddd',
                    borderRadius: 12,
                    marginTop: '5%',
                    textAlign: 'auto',
                    padding: 15,
                  }}
                />
              </View>
              <View>
                <Text
                  style={{
                    marginLeft: '3%',
                    color: '#000',
                    fontWeight: '800',
                    fontSize: getFontSize(20),
                    marginTop: '5%',
                  }}>
                  Address Details
                </Text>

                <TextInput
                  value={address}
                  onChangeText={setAddress}
                  placeholder="Address Details"
                  style={{
                    width: '100%',
                    fontSize: getFontSize(15),
                    fontWeight: '600',
                    backgroundColor: '#ddd',
                    borderRadius: 12,
                    marginTop: '5%',
                    textAlign: 'auto',
                    padding: 15,
                    bottom: '5%',
                  }}
                />
                <TouchableOpacity
                  style={{
                    width: '100%',
                    alignItems: 'center',
                    justifyContent: 'center',
                    marginTop: '10%',
                    height: '45%',
                    padding: 10,
                  }}
                  onPress={async () => {
                    const payload = {
                      phone_number: rider_id.phone_number,
                      address: address,
                      addressName: addressName,

                      rider_id: rider_id,
                      _id: rider_id,
                    };
                    const payloadd = {
                      phone_number: rider_id.phone_number,

                      addressName: addressName,

                      rider_id: rider_id,
                      // _id: rider_id,
                    };
                    dispatch(ProfileUpdateAPI(payload));
                    dispatch(RideUpdateAPI(payloadd));

                    dispatch(getBasicDetailsAPI({rider_id: rider_id}));
                    await navigation.navigate('Address');
                  }}>
                  <Text
                    style={{
                      backgroundColor: '#000055',
                      width: '100%',

                      textAlign: 'center',
                      fontSize: getFontSize(15),
                      // paddingVertical: 2,
                      borderRadius: 16,
                      padding: 14,
                      color: '#fff',
                      bottom: 11,
                      position: 'relative',
                    }}>
                    Add Address
                  </Text>
                </TouchableOpacity>
              </View>
            </View>
          </BottomSheet>
        </View>
      </>
      <View
        style={{
          width: '100%',
          height: '100%',
          top: 0,
          position: 'absolute',
          zIndex: -1,
        }}>
        <LiveLoacation />
      </View>
    </View>
  );
}
