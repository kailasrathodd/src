import React, {useState} from 'react';
import {View} from 'react-native';
import {Text} from 'react-native-elements';
import PhoneInput from 'react-native-phone-number-input';

const PhoneNumberInput = () => {
  const [value, setValue] = useState('');
  const [countryCode, setCountryCode] = useState('');

  const handleOnChangeText = text => {
    setValue(text);
    setCountryCode(phoneInput.getCountryCode());
  };

  return (
    <View>
      <PhoneInput
        ref={ref => {
          phoneInput = ref;
        }}
        defaultValue={value}
        defaultCode="US"
        onChangeText={handleOnChangeText}
      />
      <Text>Country Code: {countryCode}</Text>
    </View>
  );
};

export default PhoneNumberInput;
