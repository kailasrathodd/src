import {
  View,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  SafeAreaView,
  Image,
} from 'react-native';
import React, {useState} from 'react';
import {getFontSize} from '../utility/responsive';
import setVectorIcon from './VectorComponents';

export default function DrawerSlide({navigation}, props) {
  return (
    <View
      style={{
        // position: 'absolute',
        width: '100%',
        paddingHorizontal: 20,
        flexDirection: 'row',
        top: 10,
        justifyContent: 'space-between',
      }}>
      <TouchableOpacity onPress={() => navigation.toggleDrawer()}>
        <View
          style={{
            height: 60,
            width: 60,
            // backgroundColor: '#000052',
            borderRadius: 50,

            alignItems: 'center',
            justifyContent: 'center',
          }}>
          {setVectorIcon({
            type: 'FontAwesome',
            name: 'bars',
            size: getFontSize(30),
            color: 'red',
          })}
        </View>
      </TouchableOpacity>
      <View
        style={{
          height: 60,
          width: 60,
          alignItems: 'center',
          justifyContent: 'center',
        }}>
        <View style={{justifyContent: 'center', alignItems: 'center'}}>
          <TouchableOpacity>
            {setVectorIcon({
              type: 'Ionicons',
              name: 'notifications',
              size: getFontSize(38),
              color: '#000',
            })}
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({});
