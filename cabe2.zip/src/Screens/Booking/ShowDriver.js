/* eslint-disable react-native/no-inline-styles */
import React, {useEffect, useState, useRef} from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  Linking,
  SafeAreaView,
  Alert,
  ActivityIndicator,
} from 'react-native';
import {Avatar} from 'react-native-paper';
import BottomSheet from 'react-native-simple-bottom-sheet';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import Icon2 from 'react-native-vector-icons/Ionicons';
import {useSelector, useDispatch} from 'react-redux';
import {
  driveLocAPI,
  getDriverAPI,
  getRideDetailAPI,
} from '../../features/CreateToRide/riderAPI';
import {riderCanclledToRide} from '../../features/basicdetails/basicdetail';
import {ride_id} from '../../features/CreateToRide';
import theme from '../../theme';
import {CreateRide, GetRideDetail} from '../../features/CreateToRide';
import {getFontSize} from '../../utility/responsive';
import setVectorIcon from '../../Components/VectorComponents';
import DriverRout from '../../Components/DriverRout';
import DriverComing from '../../Components/DriverComing';

function ShowDriver({navigation}) {
  const dispatch = useDispatch();
  const Createride = useSelector(state => state.rider?.CreateRide?._id);
  const getDriver = useSelector(state => state?.rider?.getDriver);
  const rideId = useSelector(state => state?.rider?.ride_id);
  const Create_ride = useSelector(state => state.rider?.CreateRide);
  const rider = useSelector(state => state?.rider?.GetRideDetail);
  const fare = useSelector(state => state.fare?.fare?.Fare_data);
  const ride_amount = parseFloat(fare?.Sub_Total).toFixed(2);
  const panelRef = useRef(null);
  const [isVerifyLoading, setIsVerifyLoading] = useState(null);

  useEffect(() => {
    if (Create_ride !== null) {
      dispatch(getDriverAPI({ride_id: Createride || rideId}));
      dispatch(driveLocAPI({ride_id: Createride || rideId}));
    }

    const interval = setInterval(() => {
      if (Create_ride !== null) {
        dispatch(getDriverAPI({ride_id: Create_ride?._id || rideId}));
        dispatch(getRideDetailAPI(Create_ride?._id || rideId));
        dispatch(driveLocAPI({ride_id: Createride}));
      }

      if (rider) {
        switch (rider.status) {
          case 'started':
            navigation.navigate('TripDestination');
            break;
          case 'timeout':
          case 'customer_cancelled':
            navigation.navigate('HomeScreen');
            break;
          case 'ended':
            navigation.navigate('EndtoRider');
            break;
          case 'completed':
            navigation.navigate('RateDriver');
            break;
        }
      }
    }, 10000);

    return () => clearInterval(interval);
  }, [rider, dispatch, Create_ride, Createride, rideId, navigation]);

  const navigateToHomeScreen = () => {
    navigation.reset({
      index: 0,
      routes: [{name: 'HomeScreen'}],
    });
  };

  const handleRide = () => {
    const payload = {ride_id: rider?._id};
    setIsVerifyLoading(true);

    dispatch(riderCanclledToRide(payload))
      .then(data => {
        setIsVerifyLoading(false);
        if (data.payload.status === 200) {
          Alert.alert('Ride cancelled successfully');
          dispatch(CreateRide(null));
          dispatch(GetRideDetail(null));
          dispatch(ride_id(null));
          navigateToHomeScreen();
        }
      })
      .catch(error => {
        setIsVerifyLoading(false);
        console.error(error);
        Alert.alert('Something went wrong. Please try again.');
      });
  };

  return (
    <SafeAreaView style={{flex: 1}}>
      <View
        style={{
          width: '90%',
          padding: 15,
          backgroundColor: '#fff',
          justifyContent: 'center',
          alignItems: 'center',
          position: 'absolute',
          alignSelf: 'center',
          shadowColor: '#000',
          marginTop: '10%',
          zIndex: 455,
          borderRadius: 15,
          shadowOffset: {
            width: 0,
            height: 12,
          },
          shadowOpacity: 0.58,
          shadowRadius: 16.0,
          elevation: 24,
        }}>
        <DriverComing />
      </View>
      <DriverRout />

      {isVerifyLoading ? (
        <ActivityIndicator color={theme.color.primary} size={35} />
      ) : (
        <BottomSheet ref={ref => (panelRef.current = ref)} wrapperStyle={{}}>
          <View style={{flex: 1}}>
            <View
              style={{
                flexDirection: 'row',
                justifyContent: 'center',
                alignSelf: 'center',
                alignContent: 'center',
              }}>
              <View
                style={{
                  flex: 1,
                  flexDirection: 'row',
                  borderRadius: 40,
                  justifyContent: 'space-evenly',
                }}>
                <View
                  style={{
                    justifyContent: 'center',
                    borderRadius: 20,
                  }}>
                  <View
                    style={{
                      flex: 1,
                      flexDirection: 'column',
                      width: '80%',
                    }}>
                    <View style={{alignItems: 'center'}}>
                      <Avatar.Image
                        size={125}
                        source={require('../../assets/img/avater.jpg')}
                      />
                    </View>
                    <TouchableOpacity
                      style={{
                        justifyContent: 'center',
                      }}>
                      <Text
                        style={{
                          textAlign: 'center',
                          backgroundColor: '#fff',
                          borderRadius: 4,
                        }}>
                        <Icon name="star" color="#F5C000" /> 4.5
                      </Text>
                    </TouchableOpacity>
                    <View
                      style={{
                        alignContent: 'center',
                        justifyContent: 'center',
                        alignSelf: 'center',
                        width: '100%',
                      }}>
                      <Text
                        style={{
                          fontSize: 16,
                          width: '100%',
                          color: '#000055',
                          fontWeight: 'bold',
                          alignSelf: 'center',
                          justifyContent: 'center',
                          marginTop: '10%',
                        }}>
                        {getDriver?.driver_first_name?.toUpperCase() ||
                          'Driver Name'}{' '}
                      </Text>
                    </View>
                  </View>
                </View>
                <View style={{}}>
                  <View style={{justifyContent: 'center'}}>
                    <Text
                      style={{
                        fontSize: getFontSize(18),
                        color: '#000055',
                        fontWeight: 800,
                        alignSelf: 'center',
                        width: '100%',
                      }}>
                      OTP :- {getDriver?.otp || '_ _ _ _'}
                    </Text>
                  </View>
                  <View style={{justifyContent: 'center'}}>
                    <Text
                      style={{
                        fontSize: getFontSize(18),
                        color: '#000055',
                        fontWeight: 500,
                        alignSelf: 'center',
                        marginTop: '5%',
                        width: '100%',
                      }}>
                      {getDriver?.vehicle_name?.toUpperCase() || '_ _ _ _'}
                    </Text>
                    <Text
                      style={{
                        fontSize: getFontSize(18),
                        color: '#000055',
                        width: '100%',
                        fontWeight: 800,
                        marginTop: '5%',
                      }}>
                      {getDriver?.drive_car_no?.toUpperCase() || '_ _ _ _ _'}
                    </Text>
                  </View>
                  <Text
                    style={{
                      fontSize: getFontSize(18),
                      color: '#000055',
                      fontWeight: 600,
                      alignSelf: 'center',
                      marginTop: '5%',
                      width: '100%',
                    }}>
                    ESTD : - ₹ {Math.round(ride_amount) + 1 || '_ _ _ _'}
                  </Text>
                </View>
              </View>
            </View>

            <View
              style={{
                flexDirection: 'row',
                justifyContent: 'space-between',
                alignItems: 'center',
                marginBottom: 10,
                padding: 15,
              }}>
              <TouchableOpacity
                onPress={() => Linking.openURL('tel:+912250141419')}
                style={{
                  alignItems: 'center',
                  justifyContent: 'center',
                }}>
                {setVectorIcon({
                  type: 'Feather',
                  name: 'phone-call',
                  color: '#000',
                  size: getFontSize(25),
                })}
                <Text
                  style={{
                    fontSize: getFontSize(16),
                    fontWeight: 800,
                    color: '#000',
                  }}>
                  Call
                </Text>
              </TouchableOpacity>

              <TouchableOpacity>
                <Icon2
                  style={{
                    fontSize: 35,
                    alignItems: 'center',
                    textAlign: 'center',
                    color: '#000',
                  }}
                  name="chatbubble-ellipses-outline"
                />
                <Text
                  style={{
                    fontSize: getFontSize(16),
                    fontWeight: 800,
                    color: '#000',
                  }}>
                  Chat
                </Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={handleRide}>
                <Icon
                  style={{
                    fontSize: 35,
                    alignItems: 'center',
                    textAlign: 'center',
                    color: 'red',
                  }}
                  name="cancel"
                />
                <Text
                  style={{
                    fontSize: getFontSize(16),
                    fontWeight: 800,
                    color: '#000',
                  }}>
                  Cancel
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </BottomSheet>
      )}
    </SafeAreaView>
  );
}
export default ShowDriver;
