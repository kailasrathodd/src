import {
  StyleSheet,
  View,
  Text,
  Button,
  Input,
  Image,
  TouchableOpacity,
  SafeAreaView,
} from 'react-native';

import React, {useState} from 'react';
import {RadioButton} from 'react-native-paper';
import Header from '../../Components/HeaderComp';
import setVectorIcon from '../../Components/VectorComponents';
import {getFontSize, getResHeight} from '../../utility/responsive';
import {useDispatch, useSelector} from 'react-redux';
export default function Address({navigation}, props) {
  const [checked, setChecked] = useState('first');
  const basicDetail = useSelector(state => state?.basicDetail?.basicDetail);
  const Profile = useSelector(state => state?.basicDetail?.Profile);
  return (
    <SafeAreaView style={{flex: 1, backgroundColor: '#fff'}}>
      <Header
        containerStyle={{
          width: '100%',
          alignSelf: 'center',
        }}
        title={'Address'}
        backPress={() => {
          navigation.navigate('AddAddress');
        }}
        {...this.props}
      />
      <View
        style={{
          width: '90%',
          alignSelf: 'center',

          flex: 1,
        }}>
        <View
          style={{
            flexDirection: 'row',
            width: '100%',
            height: '15%',
            backgroundColor: '#fff',
            justifyContent: 'space-between',
            marginTop: '5%',
            borderRadius: 10,
            padding: 15,
            alignContent: 'center',
            alignSelf: 'center',
            shadowColor: '#000',
            shadowOffset: {
              width: 0,
              height: 2,
            },
            shadowOpacity: 0.25,
            shadowRadius: 3.84,

            elevation: 5,
            alignItems: 'center',
          }}>
          <View
            style={{
              borderRadius: 50,

              height: getResHeight(40),
              width: getResHeight(40),
              backgroundColor: '#f90436',
              alignItems: 'center',
              justifyContent: 'center',
            }}>
            {setVectorIcon({
              type: 'MaterialIcons',
              name: 'location-pin',
              size: getFontSize(25),
              color: '#fff',
            })}
          </View>

          <View style={{flexDirection: 'column'}}>
            <Text
              style={{
                fontSize: 18,
                fontWeight: '700',
                color: '#000',
                marginLeft: '3%',
              }}>
              {basicDetail?.addressName?.length > 15
                ? basicDetail?.addressName.substring(0, 15) + '...'
                : basicDetail?.addressName}
            </Text>
            <Text
              style={{
                fontSize: 13,
                fontWeight: '300',
                color: '#000',
                alignSelf: 'center',
                marginLeft: '3%',
              }}>
              {Profile?.address}
            </Text>
          </View>

          <View></View>
          <RadioButton.Item
            value="first"
            status={checked === 'first' ? 'checked' : 'unchecked'}
            onPress={() => setChecked('first')}
          />
        </View>
        <View
          style={{
            flexDirection: 'row',
            width: '100%',
            height: '15%',
            backgroundColor: '#fff',
            justifyContent: 'space-between',
            marginTop: '5%',
            borderRadius: 10,
            padding: 15,
            alignContent: 'center',
            alignSelf: 'center',
            shadowColor: '#000',
            shadowOffset: {
              width: 0,
              height: 2,
            },
            shadowOpacity: 0.25,
            shadowRadius: 3.84,

            elevation: 5,
            alignItems: 'center',
          }}>
          <View
            style={{
              borderRadius: 50,

              height: getResHeight(40),
              width: getResHeight(40),
              backgroundColor: '#ff657b',
              //   alignItems: 'flex-end',
              alignItems: 'center',
              justifyContent: 'center',
            }}>
            {setVectorIcon({
              type: 'MaterialIcons',
              name: 'location-pin',
              size: getFontSize(25),
              color: '#fff',
            })}
          </View>

          <View style={{flexDirection: 'column'}}>
            <Text
              style={{
                fontSize: 18,
                fontWeight: '700',
                color: '#000',
              }}>
              office
            </Text>
            <Text
              style={{
                fontSize: 13,
                fontWeight: '300',
                color: '#000',
                alignSelf: 'center',
              }}>
              123, oberio, Goregaon E 400065
            </Text>
          </View>
          <RadioButton.Item
            value="second"
            status={checked === 'second' ? 'checked' : 'unchecked'}
            onPress={() => setChecked('second')}
          />
        </View>
        <View
          style={{
            flexDirection: 'row',
            width: '100%',
            height: '15%',
            backgroundColor: '#fff',
            justifyContent: 'space-between',
            marginTop: '5%',
            borderRadius: 10,
            padding: 15,
            alignContent: 'center',
            alignSelf: 'center',
            shadowColor: '#000',
            shadowOffset: {
              width: 0,
              height: 2,
            },
            shadowOpacity: 0.25,
            shadowRadius: 3.84,

            elevation: 5,
            alignItems: 'center',
          }}>
          <View
            style={{
              borderRadius: 50,

              height: getResHeight(40),
              width: getResHeight(40),
              backgroundColor: '#ffaa00',
              //   alignItems: 'flex-end',
              alignItems: 'center',
              justifyContent: 'center',
            }}>
            {setVectorIcon({
              type: 'MaterialIcons',
              name: 'location-pin',
              size: getFontSize(25),
              color: '#fff',
            })}
          </View>

          <View style={{flexDirection: 'column'}}>
            <Text
              style={{
                fontSize: 18,
                fontWeight: '700',
                color: '#000',
              }}>
              Home
            </Text>
            <Text
              style={{
                fontSize: 13,
                fontWeight: '300',
                color: '#000',
                alignSelf: 'center',
              }}>
              123, oberio, Goregaon E 400065
            </Text>
          </View>
          <RadioButton.Item
            value="second"
            status={checked === 'Third' ? 'checked' : 'unchecked'}
            onPress={() => setChecked('Third')}
          />
        </View>
        <View
          style={{
            flexDirection: 'row',
            width: '100%',
            height: '15%',
            backgroundColor: '#fff',
            justifyContent: 'space-between',
            marginTop: '5%',
            borderRadius: 10,
            padding: 15,
            alignContent: 'center',
            alignSelf: 'center',
            shadowColor: '#000',
            shadowOffset: {
              width: 0,
              height: 2,
            },
            shadowOpacity: 0.25,
            shadowRadius: 3.84,

            elevation: 5,
            alignItems: 'center',
          }}>
          <View
            style={{
              borderRadius: 50,

              height: getResHeight(40),
              width: getResHeight(40),
              backgroundColor: '#6f65ff',
              //   alignItems: 'flex-end',
              alignItems: 'center',
              justifyContent: 'center',
            }}>
            {setVectorIcon({
              type: 'MaterialIcons',
              name: 'location-pin',
              size: getFontSize(25),
              color: '#fff',
            })}
          </View>
          <View style={{flexDirection: 'column'}}>
            <Text
              style={{
                fontSize: 18,
                fontWeight: '700',
                color: '#000',
              }}>
              Mall Plaza
            </Text>
            <Text
              style={{
                fontSize: 13,
                fontWeight: '300',
                color: '#000',
                alignSelf: 'center',
              }}>
              123, oberio, Goregaon E 400065
            </Text>
          </View>
          <RadioButton.Item
            value="second"
            status={checked === 'Four' ? 'checked' : 'unchecked'}
            onPress={() => setChecked('Four')}
          />
        </View>

        <TouchableOpacity
          style={{
            width: '100%',
            alignItems: 'center',
            position: 'absolute',

            justifyContent: 'center',
            bottom: 10,
          }}
          onPress={() => navigation.navigate('HomeScreen')}>
          <Text
            style={{
              backgroundColor: '#000055',
              width: '100%',
              textAlign: 'center',
              fontSize: 18,
              borderRadius: 12,
              padding: 10,
              color: '#fff',
            }}>
            Done
          </Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}
