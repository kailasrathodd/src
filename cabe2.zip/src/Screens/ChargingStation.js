import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  ActivityIndicator,
  SafeAreaView,
} from 'react-native';
import Header from '../Components/HeaderComp';
import setVectorIcon from '../Components/VectorComponents';
import {getFontSize, getResHeight, getResWidth} from '../utility/responsive';

function ChargingStation({navigation}, props) {
  const [data, setData] = React.useState([]);
  const [dataSuccess, setDataSuccess] = React.useState([]);
  const [isLoading, setIsLoading] = React.useState(true);

  const fetchData = async () => {
    const resp = await fetch('http://192.168.0.25:8000/api/chargingHub');
    const data = await resp.json();
    setDataSuccess(data.data.success);
    setData(data.data.data);
    setIsLoading(false);
  };

  React.useEffect(() => {
    fetchData();
  }, []);

  var its = [];
  if (dataSuccess == 201) {
    data.forEach(element => {
      if (element.hub_status === '1') {
        its.push(element);
      }
    });
  }

  if (dataSuccess == 200) {
    return (
      <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
        <Text style={{fontSize: 20}}>No Hubs Added</Text>
      </View>
    );
  }
  // console.log(its);
  const renderItem = ({item}) => {
    return (
      <View style={styles.button}>
        <TouchableOpacity activeOpacity={0.7}>
          <View style={styles.chargingButton}>
            <View
              style={{
                height: getResHeight(40),
                width: getResHeight(40),
                borderRadius: 25,
                backgroundColor: '#aeafd9',
                justifyContent: 'center',
                alignItems: 'center',
              }}>
              <View
                style={{
                  height: getResHeight(28),
                  width: getResHeight(28),
                  borderRadius: 25,
                  backgroundColor: '#4c4ac2',
                  justifyContent: 'center',
                  alignItems: 'center',
                }}>
                {setVectorIcon({
                  type: 'FontAwesome',
                  name: 'map-marker-alt',
                  color: '#fff',
                  size: getFontSize(25),
                })}
              </View>
            </View>

            <Text style={styles.chargingButtonText}>{item.hub_name}</Text>
          </View>
        </TouchableOpacity>
      </View>
    );
  };

  return (
    <SafeAreaView style={{flex: 1}}>
      <Header
        containerStyle={{
          alignSelf: 'center',
          backgroundColor: '#fff',
        }}
        title={'My Charging Station'}
        backPress={() => {
          navigation.pop();
        }}
        {...props}
      />

      <View style={styles.buttonContainer}>
        {isLoading == true ? (
          <View
            style={{flex: 1, alignItems: 'center', justifyContent: 'center'}}>
            <ActivityIndicator size="large" color="#0000ff" />
          </View>
        ) : (
          <FlatList
            data={its}
            renderItem={renderItem}
            keyExtractor={item => item._id}
          />
        )}
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  button: {
    width: getResWidth(270),
    borderRadius: 10,
    marginTop: 10,
    marginBottom: 10,
    backgroundColor: '#fff',
    alignSelf: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,

    elevation: 5,
  },
  chargingButton: {
    flexDirection: 'row',
    gap: 20,
    alignItems: 'center',
    width: getResWidth(240),
    height: getResHeight(70),
    alignSelf: 'center',
    justifyContent: 'flex-start',
  },
  chargingButtonText: {
    color: '#000',
    fontSize: getFontSize(18),
  },
  buttonContainer: {
    flex: 1,
    backgroundColor: '#fff',
  },
});

export default ChargingStation;
