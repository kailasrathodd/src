import {Repository} from './Repository';

const chargingHub = 'chargingHub';
export default {
  chargingHub(payload) {
    return Repository.get(transformRoute(chargingHub), payload);
  },
};

const transformRoute = route => {
  return `/api/${route}`;
};
