import React, {useEffect} from 'react';
import {useSelector, useDispatch} from 'react-redux';
import {getRideDetailAPI} from '../../features/CreateToRide/riderAPI';
import {useNavigation} from '@react-navigation/native'; // Import the useNavigation hook
import SearchingDriver from './SearchingDriver';
import ShowDriver from './ShowDriver';
import RateDriver from '../RateDriver';
import HomeScreen from '../HomePage/homeScreen';
import JourneyDetails from '../JourneyDetails';
import EndtoRider from '../EndRider';
import DriverReached from './DriverReached';

function RideStatus({status}) {
  const dispatch = useDispatch();
  const rider = useSelector(state => state?.rider?.GetRideDetail);
  const navigation = useNavigation(); // Get the navigation object using useNavigation

  useEffect(() => {
    if (rider && status === 'requested') {
      dispatch(getRideDetailAPI(rider?._id));
      navigation.navigate('SearchingDriver');
    } else if (rider && status === 'accepted') {
      dispatch(getRideDetailAPI(rider?._id));
      navigation.navigate('ShowDriver');
    } else if (status === 'started') {
      navigation.navigate('TripDestination');
    } else if (rider && status === 'ended') {
      dispatch(getRideDetailAPI(rider?._id));
      navigation.navigate('EndtoRider');
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [status]);

  switch (status) {
    case 'requested':
      return null; // We will show the SearchingDriver component after navigation
    case 'accepted':
      return <ShowDriver />;
    case 'started':
      return <DriverReached />;
    case 'ended':
      return <EndtoRider />;
    case 'completed':
      return <RateDriver />;
    case 'timeout':
      return <HomeScreen />;
    case 'customer_cancelled':
      return <HomeScreen />;
    case 'admin_cancelled':
      return <JourneyDetails />;
    default:
      return <HomeScreen />;
  }
}

export default RideStatus;
