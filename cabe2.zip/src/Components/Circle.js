import React, {useEffect, useState} from 'react';
import {View} from 'react-native';
import MapplsGL from 'mappls-map-react-native';

const Circle = () => {
  const [polygon, setPolygon] = useState({
    type: 'FeatureCollection',
    features: [
      {
        type: 'Feature',
        geometry: {
          type: 'Polygon',
          coordinates: [],
        },
      },
    ],
  });

  useEffect(() => {
    const liveLocationCoordinates = [77.22263216972351, 28.62292461876685];
    const circleCoordinates = calculateCircleCoordinates(
      liveLocationCoordinates,
      2000,
    );
    setPolygon({
      type: 'FeatureCollection',
      features: [
        {
          type: 'Feature',
          geometry: {
            type: 'Polygon',
            coordinates: [circleCoordinates],
          },
        },
      ],
    });
  }, []);

  const calculateCircleCoordinates = (centerCoordinates, radius) => {
    const latitude = centerCoordinates[1];
    const longitude = centerCoordinates[0];
    const earthRadius = 6378.1;

    const coordinates = [];
    const slices = 64;

    for (let i = 0; i <= slices; i++) {
      const angle = (Math.PI / 180) * (i / slices) * 360;
      const circleLatitude =
        latitude + (radius / earthRadius) * Math.cos(angle);
      const circleLongitude =
        longitude +
        ((radius / earthRadius) * Math.sin(angle)) /
          Math.cos(circleLatitude * (Math.PI / 180));

      coordinates.push([circleLongitude, circleLatitude]);
    }

    coordinates.push(coordinates[0]);

    return coordinates;
  };

  return (
    <View style={{flex: 1}}>
      <MapplsGL.MapView style={{flex: 1}}>
        <MapplsGL.Camera
          zoomLevel={15}
          animationMode="moveTo"
          centerCoordinate={[77.22263216972351, 28.62292461876685]}
        />

        <MapplsGL.ShapeSource id="routeSource" shape={polygon}>
          <MapplsGL.FillLayer
            id="routeFill"
            style={{
              fillColor: 'blue',
              fillOpacity: 0.5,
              fillAntialias: true,
            }}
          />
        </MapplsGL.ShapeSource>
      </MapplsGL.MapView>
    </View>
  );
};

export default Circle;
