import React, {useState} from 'react';
import {View, TextInput, FlatList, Text} from 'react-native';

const TextinputSearch = () => {
  const [searchTerm1, setSearchTerm1] = useState('');
  const [searchTerm2, setSearchTerm2] = useState('');
  const [data, setData] = useState([
    {id: 1, name: 'Apple'},
    {id: 2, name: 'Banana'},
    {id: 3, name: 'Cherry'},
    {id: 4, name: 'Date'},
    {id: 5, name: 'Elderberry'},
    {id: 6, name: 'Fig'},
    {id: 7, name: 'Grape'},
    {id: 8, name: 'Honeydew'},
    {id: 9, name: 'Kiwi'},
    {id: 10, name: 'Lemon'},
  ]);
  const handleSearch1 = text => {
    setSearchTerm1(text);
    const mergedSearchTerm = `${text} ${searchTerm2}`;
    const filteredData = performSearch(mergedSearchTerm);
    setData(filteredData);
  };

  const handleSearch2 = text => {
    setSearchTerm2(text);
    const mergedSearchTerm = `${searchTerm1} ${text}`;
    const filteredData = performSearch(mergedSearchTerm);
    setData(filteredData);
  };

  const performSearch = searchTerm => {
    const filteredData = data.filter(item =>
      item.name.toLowerCase().includes(searchTerm.toLowerCase()),
    );
    return filteredData;
  };

  const renderItem = ({item}) => (
    <View>
      <Text>{item.name}</Text>
    </View>
  );

  return (
    <View>
      <TextInput
        style={{height: 40, borderColor: 'gray', borderWidth: 1}}
        onChangeText={handleSearch1}
        value={searchTerm1}
        placeholder="Search term 1"
      />
      <TextInput
        style={{height: 40, borderColor: 'gray', borderWidth: 1}}
        onChangeText={handleSearch2}
        value={searchTerm2}
        placeholder="Search term 2"
      />
      <FlatList
        data={data}
        renderItem={renderItem}
        keyExtractor={item => item.id.toString()}
      />
    </View>
  );
};

export default TextinputSearch;
