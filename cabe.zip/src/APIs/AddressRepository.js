import {Repository} from './Repository';

const getAddress = 'getListAddressByRiderId';
const addAddress = 'addAddress';
const editAddAddress = 'editAddAddress';
const deleteAddAddress = 'deleteAddAddress';
const selectedAddAddress = 'selectedAddAddress';
export default {
  //   getAddress(payload) {
  //     return Repository.get(transformRoute(getListAddressByRiderId), payload);
  //   },
  getAddress(payload) {
    return Repository.post(transformRoute(getAddress), payload);
  },
  addAddress(payload) {
    return Repository.post(transformRoute(addAddress), payload);
  },
  editAddAddress(payload) {
    return Repository.post(transformRoute(editAddAddress), payload);
  },
  deleteAddAddress(payload) {
    return Repository.post(transformRoute(deleteAddAddress), payload);
  },
  selectedAddAddress(payload) {
    return Repository.post(transformRoute(selectedAddAddress), payload);
  },
};
const transformRoute = route => {
  return `/api/${route}`;
};
