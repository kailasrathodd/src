import {
  StyleSheet,
  Text,
  View,
  TextInput,
  TouchableOpacity,
  Linking,
} from 'react-native';
import React from 'react';
import {ScrollView, SafeAreaView} from 'react-native-gesture-handler';

import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import Icon2 from 'react-native-vector-icons/Ionicons';

function Chat() {
  const [text, onChangeText] = React.useState('');
  return (
    <>
      <ScrollView>
        <View>
          <View style={{width: '100%'}}>
            <View
              style={{
                backgroundColor: '#ddd',
                width: '70%',
                borderRadius: 10,
                shadowColor: '#171717',
                shadowOffset: {width: -2, height: 4},
                shadowOpacity: 0.2,
                shadowRadius: 3,
                padding: 30,
                marginHorizontal: 10,
                marginVertical: 20,
              }}>
              <Text>
                In publishing and graphic design, Lorem ipsum is a placeholder
                text commonly used to demonstrate the visual form of a document
                or a typeface without relying on meaningful content. Lorem ipsum
                may be used as a placeholder before final copy is available.
              </Text>
            </View>
            <View
              style={{
                shadowColor: '#171717',
                shadowOffset: {width: -2, height: 4},
                shadowOpacity: 0.2,
                shadowRadius: 3,
                borderRadius: 10,
                backgroundColor: '#ddd',
                width: '70%',
                padding: 30,
                position: 'relative',
                marginRight: 20,
                left: 150,
              }}>
              <Text>
                In publishing and graphic design, Lorem ipsum is a placeholder
                text commonly used to demonstrate the visual form of a document
                or a typeface without relying on meaningful content. Lorem ipsum
                may be used as a placeholder before final copy is available.
              </Text>
            </View>
          </View>
        </View>
      </ScrollView>
      <View
        style={{
          backgroundColor: '#fff',
          flexDirection: 'row',
          justifyContent: 'space-between',
          padding: 10,
        }}>
        <View style={{width: '90%'}}>
          <TextInput
            onChangeText={onChangeText}
            value={text}
            style={{
              backgroundColor: '#fff',
              borderColor: '#000',
              borderWidth: 2,
              borderRadius: 10,
            }}
          />
        </View>

        <TouchableOpacity style={{width: '10%', marginHorizontal: 10}}>
          <Icon2 name="send-sharp" size={40} color={'#000'} />
        </TouchableOpacity>
      </View>
    </>
  );
}

export default Chat;

const styles = StyleSheet.create({});
