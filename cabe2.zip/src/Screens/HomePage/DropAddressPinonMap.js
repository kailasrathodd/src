import {View, Text, TouchableOpacity, SafeAreaView} from 'react-native';
import React, {useState, useEffect} from 'react';
import {Searchbar} from 'react-native-paper';
import {useDispatch, useSelector} from 'react-redux';
// import DropAddressMap from '../Map/DropAddressMap';
import {getFontSize} from '../../utility/responsive';
import {getBasicDetailsAPI} from '../../features/basicdetails/basicdetail';
import {store} from '../../store';
import {ActivityIndicator} from 'react-native';
import theme from '../../theme';
import MapplsPlacePicker from '../Map/MapplsPlacePicker';
export default function DropAddressPinonMap({navigation}, props) {
  const riderUpdate = useSelector(
    state => state.basicDetail?.riderUpdate?.Rider_Data,
  );
  const rider_id = useSelector(state => state.auth.user?._id);
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [accessToken, setAccessToken] = useState([]);
  const [query, setQuery] = useState('');
  const [search, setSearch] = useState('');
  const [filteredDataSource, setFilteredDataSource] = useState([]);
  const dispatch = useDispatch();
  const [isVerifyLoading, setIsVerifyLoading] = useState(null);
  useEffect(() => {
    if (store.getState().auth.onBoarding !== true) {
      dispatch(
        getBasicDetailsAPI({
          rider_id: rider_id,
        }),
      );
    }
  }, []);
  const handleSend = () => {
    setIsVerifyLoading(true);
    const payload = {
      rider_id: rider_id,
    };

    dispatch(getBasicDetailsAPI(payload))
      .then(data => {
        if (data.payload.status === 200) {
          navigation.navigate('HomePage');

          setIsVerifyLoading(false);
        }
      })
      .catch(error => {
        setIsVerifyLoading(false);
        console.error(error);
        Alert.alert('something went wrong please try again');
      });
  };
  const searchFilterFunction = text => {
    if (text) {
      const newData = data?.filter(function (item) {
        const itemData = item.placeAddress
          ? item.placeAddress.toUpperCase()
          : ''.toUpperCase();
        const textData = text.toUpperCase();
        return itemData.indexOf(textData) > -1;
      });
      setFilteredDataSource(newData);
      setQuery(text || '');
    } else {
      setFilteredDataSource(data);
      setQuery(text || '');
    }
  };
  handleSearchClear = () => searchFilterFunction('');

  return (
    <SafeAreaView
      style={{
        position: 'relative',
        height: '100%',
      }}>
      <View
        style={{
          width: '100%',
          height: '100%',
        }}>
        {/* <DropAddressMap /> */}
        <MapplsPlacePicker />
      </View>

      <View
        style={{
          width: '90%',
          alignSelf: 'center',
          //   backgroundColor: '#fff',
          marginTop: '10%',
          borderRadius: 20,
          zIndex: 5455,
          position: 'absolute',
          height: '15%',
        }}>
        <Searchbar
          icon
          placeholder="Choose Drop Address "
          onClear={text => searchFilterFunction(text)}
          multiline
          style={{
            width: '100%',

            position: 'absolute',

            paddingLeft: 10,

            margin: 10,
            borderColor: '#009688',
            backgroundColor: '#FFFFFF',

            elevation: 20,
            shadowColor: '#e2006A',
          }}
          autoFocus={false}
          editable={false}
          // onChangeText={values => {
          //   setQuery(values);
          //   searchFilterFunction(values);
          // }}
          value={query || riderUpdate?.drop_address}
        />
      </View>

      <TouchableOpacity
        style={{
          width: '100%',
          alignItems: 'center',
          justifyContent: 'center',
          bottom: '7%',
        }}
        onPress={handleSend}>
        {isVerifyLoading == true ? (
          <ActivityIndicator color={theme.color.primary} size={35} />
        ) : (
          <Text
            style={{
              backgroundColor: '#000055',
              width: '95%',
              textAlign: 'center',
              fontSize: getFontSize(14),
              borderRadius: 12,
              padding: 10,
              color: '#fff',
            }}>
            Done
          </Text>
        )}
      </TouchableOpacity>
    </SafeAreaView>
  );
}
