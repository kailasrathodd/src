import React, { Component } from "react";
import { Platform, Text, View, PermissionsAndroid } from "react-native";
// import MapmyIndiaGL from 'mapmyindia-map-react-native-beta';
import MapplsGL from "mappls-map-react-native";
// import {DEFAULT_CENTER_COORDINATE} from '../utils/index';
import // Toast from "react-native-simple-// Toast";
import RNAndroidLocationEnabler from "react-native-android-location-enabler";
import { Button, Icon } from "react-native-elements";

import { DEFAULT_CENTER_COORDINATE } from "../utility/Index";
import * as Permissions from "react-native-permissions";
import { connect } from "react-redux";
import { updateLocation } from "../redux/reducers/locationReducer";

class CurrentLocationActivity extends Component {
  constructor(props) {
    super(props);
    this.state = {
      gpsState: false,
    };
  }

  componentDidMount() {
    MapplsGL.locationManager.start();
    // Toast.show("To get current location press my location button ", // Toast.LONG);
  }

  componentWillUnmount() {
    MapplsGL.locationManager.stop();
  }

  onUpdate(location) {
    console.log(location);
    const { latitude, longitude, accuracy } = location.coords;

    this.props.updateLocation({ latitude, longitude });
    this.camera.zoomTo(18, 1000);
    this.camera.flyTo([longitude, latitude]);
  }

  async requestLocationPermission() {
    if (Platform.OS === "ios") {
      const { status } = await Permissions.request(
        Permissions.PERMISSIONS.IOS.LOCATION_WHEN_IN_USE
      );
      return status;
    } else {
      const granted = await PermissionsAndroid.request(
        PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
        {
          title: "Location Permission",
          message: "App needs access to your location.",
          buttonNeutral: "Ask Me Later",
          buttonNegative: "Cancel",
          buttonPositive: "OK",
        }
      );
      if (granted === PermissionsAndroid.RESULTS.GRANTED) {
        return "granted";
      } else {
        return "denied";
      }
    }
  }

  onPressLocationButton() {
    this.requestLocationPermission().then((status) => {
      if (status === "granted") {
        //
      } else {
        // hjh
      }
    });
  }

  onfloatingButtonClick() {
    if (Platform.OS == "android") {
      RNAndroidLocationEnabler.promptForEnableLocationIfNeeded({
        interval: 10000,
        fastInterval: 5000,
      })
        .then((data) => {
          this.setState({
            gpsState: true,
          });
        })
        .catch((err) => {
          // Toast.show("Please enable gps.");
        });
    } else {
      this.setState({
        gpsState: true,
      });
    }
  }

  render() {
    const locationComponent = this.state.gpsState ? (
      <MapplsGL.UserLocation
        animated={true}
        visible={true}
        onUpdate={(location) => this.onUpdate(location)}
      />
    ) : null;

    return (
      <View style={{ flex: 1 }}>
        <MapplsGL.MapView style={{ flex: 1 }}>
          <MapplsGL.Camera
            ref={(c) => (this.camera = c)}
            zoomLevel={18}
            centerCoordinate={DEFAULT_CENTER_COORDINATE}
          />
          {locationComponent}
        </MapplsGL.MapView>
        <View
          style={{
            width: 50,
            height: 50,
            backgroundColor: "transparent",
            position: "absolute",
            top: "80%",
            left: "80%",
            zIndex: 10,
          }}
        >
          <Button
            icon={<Icon name="my-location" size={35} color="white" />}
            onPress={() => {
              this.onfloatingButtonClick();
              this.onPressLocationButton();
            }}
          />
        </View>
      </View>
    );
  }
}
const mapDispatchToProps = {
  updateLocation,
};

// export default connect(mapStateToProps)(CurrentLocationActivity);
// export default CurrentLocationActivity;
export default connect(null, mapDispatchToProps)(CurrentLocationActivity);
