import React, {useState, useRef, useEffect} from 'react';
import {View, Text, TouchableOpacity} from 'react-native';
import theme from '../theme';
import {getFontSize} from '../utility/responsive';
import {useRoute} from '@react-navigation/native';
import {BASE_URL} from '../config/constants';

const OTPResend = () => {
  const [countdown, setCountdown] = useState(30);
  const route = useRoute();
  const phone_number = route.params?.Mobile;
  const [ContactCode, setContactCode] = React.useState('');

  const [showSendOtp, setShowSendOtp] = React.useState(false);
  const [error, setError] = useState(null);
  const [OTPView, setOTPView] = useState(null);
  const MobileOtp = OTPView;
  const Mobile = phone_number;
  const handleSendOTP = () => {
    fetch(`${BASE_URL}/api/RegisterAndOldRiderNewOtp`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({phone_number}),
    })
      .then(response => response.json())
      .then(response => {
        console.log(setOTPView(response.data.otp));
        if (response.status === 200) {
          navigation.navigate('VerifyOtp', {
            Mobile: phone_number,
            MobileOtp: OTPView,
          });
          navigation.navigate(VerifyOtp, {
            Mobile: phone_number,
            MobileOtp: OTPView,
          });
        } else {
          setError('Invalid Mobile or Otp');
        }
      })
      .then(data => console.log(data))
      .catch(error => setError(error));
  };

  useEffect(() => {
    MobileOtp;
    OTPView;
    {
      Mobile;
    }
  });
  useEffect(() => {
    let interval;
    if (countdown > 0) {
      interval = setInterval(() => {
        setCountdown(countdown - 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [countdown]);

  const handleResendOTP = () => {
    // Code to resend OTP
    setCountdown(30);
    handleSendOTP();
  };

  return (
    <View
      style={{
        marginTop: '2%',
      }}>
      {countdown > 0 ? (
        <Text>Please wait {countdown} seconds before resending OTP</Text>
      ) : (
        <View
          style={{
            marginTop: '2%',
            flexDirection: 'row',
          }}>
          <Text
            style={{
              color: theme.color.grey2,
              fontWeight: '900',
              fontSize: getFontSize(15),
            }}>
            Don't receive the otp ?{' '}
          </Text>
          <TouchableOpacity onPress={handleResendOTP}>
            <Text
              style={{
                color: theme.color.primary,
                fontWeight: '900',
                fontSize: getFontSize(15),
              }}>
              Resend OTP
            </Text>
          </TouchableOpacity>
        </View>
      )}
    </View>
  );
};

export default OTPResend;
