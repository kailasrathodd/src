import {StyleSheet, Text, View, Button} from 'react-native';
import React from 'react';

import {createStackNavigator} from '@react-navigation/stack';
import Test from './../Screens/Test';
// const HomeMap = () => {
//   return (
//     <View
//       style={{
//         height: 300,
//         backgroundColor: '#ddd',
//         justifyContent: 'center',
//         alignItems: 'center',
//       }}>
//       <Text>HomeMap</Text>

//       <Button
//         title="Go to Aboutwe"
//         onPress={() => {
//           navigation.navigate('NewCusotom');
//         }}></Button>
//     </View>
//   );
// };

const Stack = createStackNavigator();
export default function HomeMap({navigation}) {
  return (
    <Stack.Navigator
      screenOptions={{
        headerTitleAlign: 'center',
        headerTransparent: false,
        headerShown: false,
      }}>
      <Stack.Screen name="Test" component={Test} />
    </Stack.Navigator>
  );

  return (
    <View>
      <Text>ytdyt</Text>
    </View>
  );
}

const styles = StyleSheet.create({});
