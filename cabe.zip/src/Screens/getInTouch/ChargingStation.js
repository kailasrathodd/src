import React, {useEffect, useState} from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  ActivityIndicator,
  SafeAreaView,
} from 'react-native';
import Header from '../../Components/HeaderComp';
// import setVectorIcon from '../../components/VectorComponent';

import {useDispatch, useSelector} from 'react-redux';
import styles from './styles';
import {getFontSize, getResHeight} from '../../utility/responsive';
import setVectorIcon from '../../Components/VectorComponents';
import {chargingHubAPI} from '../../features/hub/hub';

function ChargingStation({navigation}, props) {
  // const {success, data, loading} = useSelector(state => state.apifetch);

  const loading = useSelector(state => state?.hub.hub);
  const hub = useSelector(state => state?.hub.hub);

  const [isRefreshing, setIsRefreshing] = useState(false);
  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(chargingHubAPI());
  }, [dispatch]);
  const onRefresh = () => {
    setIsRefreshing(true);
    dispatch(chargingHubAPI());
    setIsRefreshing(false);
  };

  const renderItem = ({item}) => {
    return (
      <View style={styles.button}>
        <TouchableOpacity activeOpacity={0.7}>
          <View style={[styles.chargingButton, {height: getResHeight(60)}]}>
            <View
              style={{
                height: getResHeight(40),
                width: getResHeight(40),
                borderRadius: 25,
                backgroundColor: '#aeafd9',
                justifyContent: 'center',
                alignItems: 'center',
              }}>
              <View
                style={{
                  height: getResHeight(28),
                  width: getResHeight(28),
                  borderRadius: 25,
                  backgroundColor: '#4c4ac2',
                  justifyContent: 'center',
                  alignItems: 'center',
                }}>
                {setVectorIcon({
                  type: 'MaterialCommunityIcons',
                  name: 'map-marker',
                  color: '#fff',
                  size: getFontSize(25),
                })}
              </View>
            </View>

            <Text style={styles.chargingButtonText}>{item.hub_name}</Text>
          </View>
        </TouchableOpacity>
      </View>
    );
  };

  return (
    <SafeAreaView style={{flex: 1}}>
      <Header
        containerStyle={{
          alignSelf: 'center',
          backgroundColor: '#fff',
        }}
        title={'My Charging Stations'}
        backPress={() => {
          navigation.pop();
        }}
        {...props}
      />

      <View style={styles.buttonContainer}>
        {loading == true ? (
          <View
            style={{flex: 1, alignItems: 'center', justifyContent: 'center'}}>
            <ActivityIndicator size="large" color="#0000ff" />
          </View>
        ) : (
          <FlatList
            data={hub}
            renderItem={renderItem}
            keyExtractor={item => item._id}
            onRefresh={onRefresh}
            refreshing={isRefreshing}
          />
        )}
      </View>
    </SafeAreaView>
  );
}

export default ChargingStation;
