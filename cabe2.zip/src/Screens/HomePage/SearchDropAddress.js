import {
  View,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  SafeAreaView,
  Image,
  FlatList,
} from 'react-native';
import React, {useState, useEffect} from 'react';
import {Searchbar} from 'react-native-paper';
import {useDispatch, useSelector} from 'react-redux';
import {
  DropLocation,
  PickUpLocation,
  PickUpeLoc,
} from '../../features/location/location';
import {
  RideUpdateAPI,
  getBasicDetailsAPI,
  getElocTotDropAPI,
  eLocDrop,
} from '../../features/basicdetails/basicdetail';

export default function SearchDropAddress({navigation}) {
  const coordinate = useSelector(state => state.basicDetail.getElocTotDropAPI);
  const basicDetail = useSelector(state => state.basicDetail.basicDetail);
  const rider_id = useSelector(state => state.auth.user?._id);
  const Longitude = coordinate?.longitude;
  const Latitude = coordinate?.latitude;
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [accessToken, setAccessToken] = useState([]);
  const [query, setQuery] = useState('');
  const [filteredDataSource, setFilteredDataSource] = useState([]);
  const dispatch = useDispatch();
  useEffect(() => {
    if (coordinate?.longitude !== basicDetail.drop_latitude) {
      dispatch(
        RideUpdateAPI({
          drop_latitude: Latitude,
          drop_longitude: Longitude,
          rider_id: rider_id,
        }),
      );
    }
    coordinate;
  }, [coordinate, dispatch]);
  if (coordinate?.longitude !== basicDetail.drop_latitude) {
    dispatch(
      RideUpdateAPI({
        drop_latitude: Latitude,
        drop_longitude: Longitude,
        rider_id: rider_id,
      }),
    );
  }
  const searchFilterFunction = text => {
    if (text) {
      const newData = data?.filter(function (item) {
        const itemData = `${item.placeAddress.toUpperCase()}`;

        const textData = text.toUpperCase();
        return itemData.indexOf(textData) - 1;
      });
      setFilteredDataSource(newData);
      setQuery(text);
    } else {
      setFilteredDataSource('');
      setQuery('');
    }
  };
  handleSearchClear = () => searchFilterFunction('');
  const [isFocus, setIsFocus] = useState(false);
  const fetchAccessToken = async () => {
    const resp2 = await fetch(
      'https://outpost.mapmyindia.com/api/security/oauth/token?grant_type=client_credentials&client_id=33OkryzDZsJ5zN81E9FCF9vruFDY_8wEJySBHTVN2YroM6YVpgCRG8GjfY_w_wHLGWA24P-wObVzK2I7yH0AtQ==&client_secret=lrFxI-iSEg_7x4WFo74p0-leBomnlnqQTpyHrd7f--g-2lk3ZpOOZwBvabvkCEVBSC1yny1ymG7pZN0FkXFrzi8og6fFRBF7',
      {
        method: 'POST',
      },
    );

    const accessToken = await resp2.json();
    console.log(accessToken);
    setAccessToken(accessToken.access_token);
  };
  const showSuggestion = () => {
    fetchAccessToken();
    fetchData();
  };
  //https://atlas.mappls.com/api/places/search/json
  const fetchData = async () => {
    const resp = await fetch(
      `https://atlas.mappls.com/api/places/search/json?access_token=${accessToken}&query=${query} || ${query}`,
    );
    const data = await resp.json();
    setData(data.suggestedLocations);

    setLoading(false);
  };

  const NewSetButton = item => {
    // setQuerys(item.placeAddress);
    // console.tron.log(item.placeAddress);
    setQuery(item.placeAddress);
  };
  const renderItem = ({item}) => {
    return (
      <TouchableOpacity
        activeOpacity={0.7}
        onPress={() => {
          navigation.navigate('HomePage');
          NewSetButton(item);
          setQuery(item.placeAddress);
          const eloc = item.eLoc;

          dispatch(getElocTotDropAPI(eloc));
          dispatch(eLocDrop(eloc));
          dispatch(DropLocation(item.placeAddress));
          dispatch(
            RideUpdateAPI({
              drop_address: item.placeAddress,
              drop_latitude: Latitude,
              drop_longitude: Longitude,
              drop_details: item,
              drop_Eloc: eloc,
              rider_id: rider_id,
            }),
          );

          dispatch(
            getBasicDetailsAPI({
              rider_id: rider_id,
            }),
          );
        }}
        style={{
          backgroundColor: '#ffff',
          width: '100%',
          padding: 10,

          alignSelf: 'center',
        }}>
        <View
          style={{
            backgroundColor: '#ffff',
            width: '100%',

            alignSelf: 'center',
          }}>
          <Text style={{padding: 5, fontWeight: 700, fontSize: 15}}>
            {item.placeName}
          </Text>
          <Text style={{padding: 5, fontWeight: 700, fontSize: 10}}>
            {item.placeAddress}
          </Text>
        </View>
      </TouchableOpacity>
    );
  };
  const ItemSeparatorView = () => {
    return (
      <View
        style={{
          height: 0.5,
          width: '100%',
          backgroundColor: '#C8C8C8',
        }}
      />
    );
  };
  return (
    <SafeAreaView style={{flex: 1}}>
      <View
        style={{
          width: '90%',
          alignSelf: 'center',
          backgroundColor: '#fff',
          marginTop: '10%',
          borderRadius: 20,
        }}>
        <Searchbar
          placeholder="Search Here"
          onClear={text => searchFilterFunction(text)}
          style={{
            height: 50,

            paddingLeft: 10,
            margin: 10,
            borderColor: '#009688',
            backgroundColor: '#FFFFFF',

            elevation: 20,
            shadowColor: '#e2006A',
          }}
          autoFocus={true}
          onChangeText={values => {
            setQuery(values);
            searchFilterFunction(values);
          }}
          value={query || ''}
          onChange={item => {
            showSuggestion(item);
            setIsFocus(true);
          }}
        />

        {/* <TextInput
          name="Searchpickup"
          style={[(borderColor = 'red'), isFocus && {borderColor: 'blue'}]}
          value={query}
          search
          onChangeText={values => setQuery(values)}
          onFocus={() => setIsFocus(true)}
          onBlur={() => setIsFocus(false)}
          onChange={item => {
            showSuggestion(item);
            setIsFocus(true);
          }}
          multiline
          placeholder="Kandivali East, Mumbai, Maharashtra 400101"
        /> */}
      </View>
      <View
        style={{
          width: '100%',
          alignSelf: 'center',
          marginTop: '5%',
        }}>
        {filteredDataSource && (
          <FlatList
            data={filteredDataSource}
            renderItem={renderItem}
            keyExtractor={item => item.placeAddress}
            ItemSeparatorComponent={ItemSeparatorView}
          />
        )}
      </View>
      <TouchableOpacity
        style={{
          width: '30%',
          alignSelf: 'flex-start',
          marginLeft: '5%',
          backgroundColor: '#000055',
          borderRadius: 10,
          padding: 2,
          // alignItems: 'center',
          marginTop: '5%',
        }}
        onPress={() => navigation.navigate('DropAddressPinonMap')}>
        <Text
          style={{
            padding: 5,
            fontWeight: 700,
            fontSize: 12,
            color: '#fff',
            alignSelf: 'center',
          }}>
          choose on Map
        </Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
}
