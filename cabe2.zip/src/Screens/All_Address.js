import {
  StyleSheet,
  View,
  Text,
  Button,
  Image,
  SafeAreaView,
  FlatList,
  StatusBar,
} from 'react-native';
import {createStackNavigator} from '@react-navigation/stack';
import React, {useState} from 'react';
import Icon from 'react-native-vector-icons/EvilIcons';
import Icon2 from 'react-native-vector-icons/FontAwesome5';
import Header from '../Components/HeaderComp';

const DATA = [
  {
    id: 'bd7acbea-c1b1-46c2-aed5-3ad53abb28ba',
    title: 'First Item',
    icon: 'location',
    icon2: 'edit',
    subtitle: 'Special Promo only Today',
  },
  {
    id: 'bd7acbea-c1b1-46c2-aed5-3ad53abb28ba',
    title: 'First Item',
    icon: 'location',
    icon2: 'edit',
    subtitle: 'Special Promo only Today',
  },
  {
    id: 'bd7acbea-c1b1-46c2-aed5-3ad53abb28ba',
    title: 'First Item',
    icon: 'location',
    icon2: 'edit',
    subtitle: 'Special Promo only Today',
  },
  {
    id: 'bd7acbea-c1b1-46c2-aed5-3ad53abb28ba',
    title: 'First Item',
    icon: 'location',
    icon2: 'edit',
    subtitle: 'Special Promo only Today',
  },
  {
    id: 'bd7acbea-c1b1-46c2-aed5-3ad53abb28ba',
    title: 'First Item',
    icon: 'location',
    icon2: 'edit',
    subtitle: 'Special Promo only Today',
  },
  {
    id: 'bd7acbea-c1b1-46c2-aed5-3ad53abb28ba',
    title: 'First Item',
    icon: 'location',
    icon2: 'edit',
    subtitle: 'Special Promo only Today',
  },
  {
    id: 'bd7acbea-c1b1-46c2-aed5-3ad53abb28ba',
    title: 'First Item',
    icon: 'location',
    icon2: 'edit',
    subtitle: 'Special Promo only Today',
  },
  {
    id: 'bd7acbea-c1b1-46c2-aed5-3ad53abb28ba',
    title: 'First Item',
    icon: 'location',
    icon2: 'edit',
    subtitle: 'Special Promo only Today',
  },
  {
    id: 'bd7acbea-c1b1-46c2-aed5-3ad53abb28ba',
    title: 'First Item',
    icon: 'location',
    icon2: 'edit',
    subtitle: 'Special Promo only Today',
  },
  {
    id: 'bd7acbea-c1b1-46c2-aed5-3ad53abb28ba',
    title: 'First Item',
    icon: 'location',
    icon2: 'edit',
    subtitle: 'Special Promo only Today',
  },
  {
    id: 'bd7acbea-c1b1-46c2-aed5-3ad53abb28ba',
    title: 'First Item',
    icon: 'location',
    icon2: 'edit',
    subtitle: 'Special Promo only Today',
  },
  {
    id: 'bd7acbea-c1b1-46c2-aed5-3ad53abb28ba',
    title: 'First Item',
    icon: 'location',
    icon2: 'edit',
    subtitle: 'Special Promo only Today',
  },
  {
    id: 'bd7acbea-c1b1-46c2-aed5-3ad53abb28ba',
    title: 'First Item',
    icon: 'location',
    icon2: 'edit',
    subtitle: 'Special Promo only Today',
  },
  {
    id: 'bd7acbea-c1b1-46c2-aed5-3ad53abb28ba',
    title: 'First Item',
    icon: 'location',
    icon2: 'edit',
    subtitle: 'Special Promo only Today',
  },
  {
    id: 'bd7acbea-c1b1-46c2-aed5-3ad53abb28ba',
    title: 'First Item',
    icon: 'location',
    icon2: 'edit',
    subtitle: 'Special Promo only Today',
  },
  {
    id: 'bd7acbea-c1b1-46c2-aed5-3ad53abb28ba',
    title: 'First Item',
    icon: 'location',
    icon2: 'edit',
    subtitle: 'Special Promo only Today',
  },
  {
    id: 'bd7acbea-c1b1-46c2-aed5-3ad53abb28ba',
    title: 'First Item',
    icon: 'location',
    icon2: 'edit',
    subtitle: 'Special Promo only Today',
  },
];

const Item = ({...props}) => (
  <View style={{flex: 1}}>
    <StatusBar backgroundColor="#000055" barStyle="light-content" />
    <View
      style={{
        borderBottomWidth: 1,
        borderBottomColor: '#efebeb',
        width: '90%',
        alignSelf: 'center',
      }}
    />
    <View
      style={{
        flexDirection: 'row',
        alignItems: 'center',
        marginVertical: 10,
        width: '100%',
        justifyContent: 'space-between',
      }}>
      <View
        style={{
          borderRadius: 150,
          marginLeft: '5%',
          backgroundColor: '#959cdd',
          justifyContent: 'center',
          height: '76%',
          width: '14.2%',
          alignItems: 'center',
          opacity: 0.8,
        }}>
        <View
          style={{
            borderRadius: 150,
            height: '74%',
            width: '74%',
            justifyContent: 'center',
            backgroundColor: '#4449c0',
            alignItems: 'center',
          }}>
          <Icon
            style={{
              color: 'white',
              width: 80,
              padding: 1,
              fontSize: 30,
              textAlign: 'center',
              borderRadius: 20,
            }}
            name={props.icon}
          />
        </View>
      </View>
      <View
        style={{
          paddingVertical: 17,
        }}>
        <Text
          style={{
            fontSize: 17,
            fontWeight: '800',
            color: '#000',
          }}>
          <Text style={{}}>{props.title}</Text>
        </Text>
        <Text
          style={{
            fontSize: 13,
            color: '#000',
            width: '100%',
            fontWeight: '500',
          }}>
          {props.subtitle}
        </Text>
      </View>
      <View
        style={{
          alignItems: 'center',
          justifyContent: 'center',
        }}>
        <Icon2
          style={{
            color: '#000',
            width: 100,
            padding: 10,
            fontSize: 22,
            textAlign: 'center',
            borderRadius: 20,
          }}
          name={props.icon2}
        />
      </View>
    </View>
  </View>
);

export default function All_Address({navigation}) {
  const [checked, setChecked] = useState('first');
  return (
    <>
      <SafeAreaView style={{}}>
        <Header
          containerStyle={{
            width: '100%',
            alignSelf: 'center',
          }}
          title={'Addresses'}
          backPress={() => {
            // navigation.navigate(PromoCode);
            navigation.pop();
          }}
          {...this.props}
        />
        <FlatList
          data={DATA}
          renderItem={({item}) => (
            <Item
              title={item.title}
              icon={item.icon}
              icon2={item.icon2}
              subtitle={item.subtitle}
            />
          )}
          keyExtractor={item => item.id}
        />
      </SafeAreaView>
    </>
  );
}
