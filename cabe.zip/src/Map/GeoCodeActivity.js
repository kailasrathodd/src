import React, {Component} from 'react';
import {View, TextInput, Button, Keyboard} from 'react-native';
import MapplsGL from 'mappls-map-react-native';
import Mapmyindia from 'mapmyindia-restapi-react-native-beta';
// import // Toast from 'react-native-simple-// Toast';
class GeoCodeActivity extends Component {
  constructor(props) {
    super(props);
    this.state = {
      query: '',
      lat: 0,
      lng: 0,
      label: '',
    };
  }

  async componentDidMount() {
    this.geoCodeApi('lucknow');
  }

  geoCodeApi(placeName) {
    MapplsGL.setMapSDKKey('57ed4a46a04bb48819af047eede68cee'); //place your mapsdkKey
    MapplsGL.setRestAPIKey('fa00fe4ec72020f44813576d13d6cd41'); //your restApiKey
    MapplsGL.setAtlasClientId(
      '33OkryzDZsJ5zN81E9FCF9vruFDY_8wEJySBHTVN2YroM6YVpgCRG8GjfY_w_wHLGWA24P-wObVzK2I7yH0AtQ==',
    ); //your atlasClientId key
    MapplsGL.setAtlasClientSecret(
      'lrFxI-iSEg_7x4WFo74p0-leBomnlnqQTpyHrd7f--g-2lk3ZpOOZwBvabvkCEVBSC1yny1ymG7pZN0FkXFrzi8og6fFRBF7',
    ); //your atlasClientSecret key
    // MapplsGL.setAtlasGrantType('client_credentials');
    Mapmyindia.atlas_geocode({address: placeName}, response => {
      const longitude = response.copResults.longitude;
      const latitude = response.copResults.latitude;
      const eLoc = response.copResults.eLoc;
      this.setState({
        lat: parseFloat(latitude),
        lng: parseFloat(longitude),
      });
      console.log(response);

      // Toast.show(
        `Longitude :${longitude} Latitude :${latitude} Eloc :${eLoc}`,
        // Toast.LONG,
      );
      this.setState({
        label: response.copResults.formattedAddress,
      });
    });
  }

  onClick() {
    if (this.state.query.trim().length > 0) {
      this.setState({
        markerLat: this.state.lat,
        markerLng: this.state.lng,
      });
      this.geoCodeApi(this.state.query);
      Keyboard.dismiss();
      // this.moveCamera(this.state.lng,this.state.lat);
    } else {
      // Toast.show('please enter some value');
    }
  }

  render() {
    return (
      <View style={{flex: 1}}>
        <View
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'space-between',
            paddingLeft: 1,
            paddingRight: 1,
          }}>
          <TextInput
            placeholder="Enter address to get geocode details "
            style={{
              borderWidth: 1,
              borderRadius: 4,
              height: 40,
              padding: 10,
              margin: 5,
              minWidth: 200,
            }}
            onChangeText={text => this.setState({query: text})}
          />
          <Button title="call geocode" onPress={() => this.onClick()} />
        </View>
        {/* <GooglePlacesAutocomplete
          styles={{...styles.autoCompleteStyle, ...styleProps}}
          nearbyPlacesAPI="GooglePlacesSearch"
          enablePoweredByContainer={false}
          placeholder={placeholder}
          minLength={2}
          returnKeyType="search"
          fetchDetails={true}
          onPress={(data, details = null) => onChangeInput(data, details)}
          query={query}
          debounce={400}
        /> */}
        <MapplsGL.MapView style={{flex: 1}}>
          <MapplsGL.Camera
            zoomLevel={12}
            ref={c => (this.camera = c)}
            centerCoordinate={[this.state.lng, this.state.lat]}
          />

          <MapplsGL.PointAnnotation
            id="markerId"
            title="Marker"
            coordinate={[this.state.lng, this.state.lat]}>
            <MapplsGL.Callout title={this.state.label} />
          </MapplsGL.PointAnnotation>
        </MapplsGL.MapView>
      </View>
    );
  }
}

export default GeoCodeActivity;
