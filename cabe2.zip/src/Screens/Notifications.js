import {StyleSheet, Text, View, Button} from 'react-native';
import React from 'react';
// import Notifications from './Notifications';
import {createStackNavigator} from '@react-navigation/stack';
import HomeMap from './../Components/HomeMap';

// const Notifications = props => {
//   return (
//     <View>
//       <Text>Notifications</Text>
//       <Button
//         title="Go to About"
//         onPress={() => {
//           props.navigation.navigate('Test');
//         }}></Button>
//     </View>
//   );
// };

const Notificationsscreen = props => {
  return (
    <View>
      <Text>Notifications</Text>
      <Button
        title="Go to About"
        onPress={() => {
          props.navigation.navigate('HomeMap');
        }}></Button>
    </View>
  );
};

// export default Notifications;

// const styles = StyleSheet.create({});
const Stack = createStackNavigator();
export default function Notifications({navigation}, props) {
  return (
    <Stack.Navigator
      screenOptions={{
        headerTitleAlign: 'center',
        headerTransparent: false,
        headerShown: false,
      }}
      {...props}>
      <Stack.Screen
        name="Notificationsscreen"
        component={Notificationsscreen}
      />
      <Stack.Screen name="  " component={HomeMap} />
    </Stack.Navigator>
  );
}
