import {
  StyleSheet,
  View,
  Text,
  Button,
  Input,
  Image,
  TouchableOpacity,
  SafeAreaView,
} from 'react-native';

import React, {useState} from 'react';
import {RadioButton} from 'react-native-paper';
import Header from '../../Components/HeaderComp';
import setVectorIcon from '../../Components/VectorComponents';
import {getFontSize, getResHeight} from '../../utility/responsive';
export default function PromoCode({navigation}, props) {
  const [checked, setChecked] = useState('first');

  return (
    <SafeAreaView style={{flex: 1, backgroundColor: '#fff'}}>
      <Header
        containerStyle={{
          width: '100%',
          alignSelf: 'center',
        }}
        title={'Promo Code'}
        backPress={() => {
          navigation.pop();
        }}
        {...this.props}
      />
      <View
        style={{
          width: '90%',
          alignSelf: 'center',

          flex: 1,
        }}>
        <View
          style={{
            flexDirection: 'row',
            width: '100%',
            height: '15%',
            backgroundColor: '#fff',
            justifyContent: 'space-between',
            marginTop: '5%',
            borderRadius: 10,
            padding: 15,
            alignContent: 'center',
            alignSelf: 'center',
            shadowColor: '#000',
            shadowOffset: {
              width: 0,
              height: 2,
            },
            shadowOpacity: 0.25,
            shadowRadius: 3.84,

            elevation: 5,
            alignItems: 'center',
          }}>
          <View
            style={{
              borderRadius: 50,

              height: getResHeight(40),
              width: getResHeight(40),
              backgroundColor: '#f90436',
              alignItems: 'center',
              justifyContent: 'center',
            }}>
            {setVectorIcon({
              type: 'MaterialIcons',
              name: 'local-offer',
              size: getFontSize(25),
              color: '#fff',
            })}
          </View>

          <View style={{flexDirection: 'column'}}>
            <Text
              style={{
                fontSize: 18,
                fontWeight: '700',
                color: '#000',
              }}>
              Special 25% off
            </Text>
            <Text
              style={{
                fontSize: 13,
                fontWeight: '300',
                color: '#000',
                alignSelf: 'center',
              }}>
              Special promo only today !
            </Text>
          </View>

          <View></View>
          <RadioButton.Item
            value="first"
            status={checked === 'first' ? 'checked' : 'unchecked'}
            onPress={() => setChecked('first')}
          />
        </View>
        <View
          style={{
            flexDirection: 'row',
            width: '100%',
            height: '15%',
            backgroundColor: '#fff',
            justifyContent: 'space-between',
            marginTop: '5%',
            borderRadius: 10,
            padding: 15,
            alignContent: 'center',
            alignSelf: 'center',
            shadowColor: '#000',
            shadowOffset: {
              width: 0,
              height: 2,
            },
            shadowOpacity: 0.25,
            shadowRadius: 3.84,

            elevation: 5,
            alignItems: 'center',
          }}>
          <View
            style={{
              borderRadius: 50,

              height: getResHeight(40),
              width: getResHeight(40),
              backgroundColor: '#ff657b',
              //   alignItems: 'flex-end',
              alignItems: 'center',
              justifyContent: 'center',
            }}>
            {setVectorIcon({
              type: 'MaterialIcons',
              name: 'local-offer',
              size: getFontSize(25),
              color: '#fff',
            })}
          </View>

          <View style={{flexDirection: 'column'}}>
            <Text
              style={{
                fontSize: 18,
                fontWeight: '700',
                color: '#000',
              }}>
              Special 25% off
            </Text>
            <Text
              style={{
                fontSize: 13,
                fontWeight: '300',
                color: '#000',
                alignSelf: 'center',
              }}>
              Special promo only today !
            </Text>
          </View>
          <RadioButton.Item
            value="second"
            status={checked === 'second' ? 'checked' : 'unchecked'}
            onPress={() => setChecked('second')}
          />
        </View>
        <View
          style={{
            flexDirection: 'row',
            width: '100%',
            height: '15%',
            backgroundColor: '#fff',
            justifyContent: 'space-between',
            marginTop: '5%',
            borderRadius: 10,
            padding: 15,
            alignContent: 'center',
            alignSelf: 'center',
            shadowColor: '#000',
            shadowOffset: {
              width: 0,
              height: 2,
            },
            shadowOpacity: 0.25,
            shadowRadius: 3.84,

            elevation: 5,
            alignItems: 'center',
          }}>
          <View
            style={{
              borderRadius: 50,

              height: getResHeight(40),
              width: getResHeight(40),
              backgroundColor: '#ffaa00',
              //   alignItems: 'flex-end',
              alignItems: 'center',
              justifyContent: 'center',
            }}>
            {setVectorIcon({
              type: 'MaterialIcons',
              name: 'local-offer',
              size: getFontSize(25),
              color: '#fff',
            })}
          </View>

          <View style={{flexDirection: 'column'}}>
            <Text
              style={{
                fontSize: 18,
                fontWeight: '700',
                color: '#000',
              }}>
              Special 25% off
            </Text>
            <Text
              style={{
                fontSize: 13,
                fontWeight: '300',
                color: '#000',
                alignSelf: 'center',
              }}>
              Special promo only today !
            </Text>
          </View>
          <RadioButton.Item
            value="second"
            status={checked === 'Third' ? 'checked' : 'unchecked'}
            onPress={() => setChecked('Third')}
          />
        </View>
        <View
          style={{
            flexDirection: 'row',
            width: '100%',
            height: '15%',
            backgroundColor: '#fff',
            justifyContent: 'space-between',
            marginTop: '5%',
            borderRadius: 10,
            padding: 15,
            alignContent: 'center',
            alignSelf: 'center',
            shadowColor: '#000',
            shadowOffset: {
              width: 0,
              height: 2,
            },
            shadowOpacity: 0.25,
            shadowRadius: 3.84,

            elevation: 5,
            alignItems: 'center',
          }}>
          <View
            style={{
              borderRadius: 50,

              height: getResHeight(40),
              width: getResHeight(40),
              backgroundColor: '#6f65ff',
              //   alignItems: 'flex-end',
              alignItems: 'center',
              justifyContent: 'center',
            }}>
            {setVectorIcon({
              type: 'MaterialIcons',
              name: 'local-offer',
              size: getFontSize(25),
              color: '#fff',
            })}
          </View>
          <View style={{flexDirection: 'column'}}>
            <Text
              style={{
                fontSize: 18,
                fontWeight: '700',
                color: '#000',
              }}>
              Special 25% off
            </Text>
            <Text
              style={{
                fontSize: 13,
                fontWeight: '300',
                color: '#000',
                alignSelf: 'center',
              }}>
              Special promo only today !
            </Text>
          </View>
          <RadioButton.Item
            value="second"
            status={checked === 'Four' ? 'checked' : 'unchecked'}
            onPress={() => setChecked('Four')}
          />
        </View>

        <TouchableOpacity
          style={{
            width: '100%',
            alignItems: 'center',
            position: 'absolute',

            justifyContent: 'center',
            bottom: 10,
          }}
          onPress={() => navigation.navigate('Pin')}>
          <Text
            style={{
              backgroundColor: '#000055',
              width: '100%',
              textAlign: 'center',
              fontSize: getResHeight(13),
              borderRadius: 12,
              padding: 15,
              fontWeight: '700',
              color: '#fff',
            }}>
            Apply Promo
          </Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}
