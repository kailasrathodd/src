import React, {useState} from 'react';
import {View, Text, TouchableOpacity, SafeAreaView} from 'react-native';
import {useDispatch, useSelector} from 'react-redux';
import {getFontSize} from '../../utility/responsive';
import {TextInput} from 'react-native-paper';
import {ProfileAPI} from '../../features/basicdetails/basicdetail';

export default function RegisterEmail({navigation}) {
  const [email, setEmail] = useState('');
  const [isValidEmail, setIsValidEmail] = useState(true);

  const validateEmail = email => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  const rider_id = useSelector(state => state.auth.user);
  const dispatch = useDispatch();

  const navigateToHomeScreen = () => {
    navigation.reset({
      index: 0,
      routes: [{name: 'EnterName'}],
    });
  };

  const handleEmailChange = value => {
    setEmail(value.toLowerCase().replace(/\s/g, ''));
    setIsValidEmail(validateEmail(value));
  };

  const onContinuePressed = async () => {
    if (isValidEmail) {
      dispatch(
        ProfileAPI({
          email: email,
          _id: rider_id && rider_id._id,
          phone_number: rider_id && rider_id.phone_number,
        }),
      );
      const loggedIn = true;
      if (loggedIn) {
        if (rider_id._id === rider_id._id) {
          navigation.navigate('EnterName');
        } else {
          navigateToHomeScreen();
        }
      }
    }
  };

  return (
    <SafeAreaView style={{backgroundColor: '#fff', flex: 1}}>
      <View
        style={{
          width: '100%',
          alignItems: 'center',
          alignSelf: 'center',
          marginLeft: '10%',
          marginTop: '10%',
        }}>
        <Text
          style={{
            width: '100%',
            color: '#000',
            fontWeight: '700',
            marginTop: '5%',
            fontSize: getFontSize(25),
          }}>
          Enter Your e-mail
        </Text>
      </View>
      <View
        style={{
          width: '90%',
          justifyContent: 'center',
          alignContent: 'center',
          alignSelf: 'center',
          marginTop: '35%',
        }}>
        <TextInput
          autoCorrect={false}
          keyboardAppearance="default"
          onChangeText={handleEmailChange}
          value={email}
          label="Enter Your E-mail"
          style={{
            width: '95%',
            fontSize: 15,
            fontWeight: '300',
            backgroundColor: '#ffffff',
            textAlign: 'auto',
            borderColor: isValidEmail ? '#dddddd' : 'red',
            borderBottomWidth: isValidEmail ? 0 : 2,
            alignSelf: 'center',
          }}
          onFocus={() => setIsValidEmail(true)}
        />
        {!isValidEmail && (
          <Text style={{color: 'red', marginLeft: '5%'}}>
            Email is invalid. Please try again
          </Text>
        )}
      </View>

      <TouchableOpacity
        style={{
          width: '100%',
          alignItems: 'center',
          justifyContent: 'center',
          position: 'absolute',
          bottom: '5%',
        }}
        onPress={onContinuePressed}
        disabled={!isValidEmail}>
        <Text
          style={{
            backgroundColor: isValidEmail ? '#000055' : '#dddddd',
            width: '95%',
            textAlign: 'center',
            fontSize: 14,
            borderRadius: 12,
            padding: 10,
            color: isValidEmail ? '#fff' : '#777',
          }}>
          Continue
        </Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
}
