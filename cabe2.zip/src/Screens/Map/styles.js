import {StyleSheet} from 'react-native';
const styles = StyleSheet.create({
  bottomContainer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    justifyContent: 'flex-end',
  },

  buttonContainer: {
    padding: 10,
    backgroundColor: 'white',
    alignItems: 'center',
  },
  bottomText: {
    color: 'grey',
    marginBottom: 5,
    alignItems: 'center',
  },
  currentLocation: {
    height: 50,
    width: 50,
    bottom: 30,
    alignSelf: 'flex-end',
    right: 20,
    backgroundColor: 'red',
    justifyContent: 'center',
    alignContent: 'center',
    alignSelf: 'center',
  },
  searchButton: {
    height: 50,
    width: 50,
    bottom: 30,
    alignSelf: 'flex-end',
    right: 20,
  },
  rootView: {flex: 1, top: 0, bottom: 0, right: 0, left: 0},
  centerMaker: {
    height: 50,
    width: 30,
    position: 'absolute',
    top: '44%',
    right: '46.3%',
  },
  logoButtonRow: {
    width: '100%',
    // flexDirection: 'row',
    justifyContent: 'space-between',
  },
});
export default styles;
