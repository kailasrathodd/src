import React from 'react';
import {createStackNavigator} from '@react-navigation/stack';
import All_Address from '../Screens/All_Address';
import RateDriver from '../Screens/RateDriver';
import CancelScreen from '../Screens/CancelScreen';
import Cabewallet from '../Screens/wallet/Cabewallet';
import Sos from '../Screens/Sos';
import RateCab from '../Screens/RateCab';
import TopUp from '../Screens/wallet/TopUp';
import PaymentMethod from '../Screens/wallet/PaymentMethod';
import UPI from '../Screens/wallet/UPI';
import PromoCode from '../Screens/wallet/PromoCode';
import AddAddress from '../Screens/Address/AddAddress';
import Address from '../Screens/Address/Address';
import MyProfile from '../Screens/profile/MyProfile';
import HomePage from '../Screens/HomePage/HomePage';
import Pin from '../Screens/wallet/Pin';
import SplashScreen from '../Screens/onboarding/SplashScreen';
import VerifyOtp from '../Screens/profile/VerifyOtp';
import Splash from '../Screens/onboarding/Splash';
import Splash1 from '../Screens/onboarding/Splash1';
import RateServices from '../Screens/RateServices';
import Journey from '../Screens/journey/Journey';
import Search from '../Screens/HomePage/Search';
import PickUpOnmap from '../Screens/HomePage/PickUpOnmap';
import DropAddressPinonMap from '../Screens/HomePage/DropAddressPinonMap';
import SearchPickAddress from '../Screens/HomePage/SearchPickAddress';
import ShowDriver from '../Screens/Booking/ShowDriver';
import SearchingDriver from '../Screens/Booking/SearchingDriver';
import ConfirmBooking from '../Screens/Booking/ConfirmBooking';
import TripDestination from '../Screens/TripDestination';
import HomeScreen from '../Screens/HomePage/homeScreen';
import EndtoRider from '../Screens/EndRider';
import SearchMap from '../Screens/HomePage/SearchMap';
import PickupSearch from '../Screens/HomePage/PickupSearch';
import DropSearch from '../Screens/HomePage/DropSearch';
import GetInTouchStack from '../Screens/getInTouch/GetInTouchStack';
import SearchDashboard from '../Screens/HomePage/SearchDashboard';
import Nodata from '../Screens/Nodata';
import Notifications from '../Screens/Notification/Notifications';
import Promo_Code from '../Screens/PromoCode/Promo_Code';
import Comingsoon from '../Screens/Comingsoon';
import DriverReached from '../Screens/Booking/DriverReached';
import Schedule from '../Screens/Schedule/Schedule';
import RegisterEmail from '../Screens/profile/RegisterEmail';
import EnterName from '../Screens/profile/EnterName';
import DropSchedule from '../Screens/Schedule/DropSchedule';
import DirectionSchedule from '../Screens/Schedule/DirectionSchedule';
import PickupSchedule from '../Screens/Schedule/PickupSchedule';
import SearchSchedule from '../Screens/Schedule/SearchSchedule';

const Stack = createStackNavigator();

function Home() {
  return (
    <Stack.Navigator initialRouteName="HomeScreen ">
      <Stack.Screen
        name="HomeScreen"
        component={HomeScreen}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="SearchDashboard"
        component={SearchDashboard}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="DriverReached"
        component={DriverReached}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="DropSchedule"
        component={DropSchedule}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="HomePage"
        component={HomePage}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="DirectionSchedule"
        component={DirectionSchedule}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="SearchSchedule"
        component={SearchSchedule}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="PickupSchedule"
        component={PickupSchedule}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="DropSearch"
        component={DropSearch}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="Comingsoon"
        component={Comingsoon}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="Notifications"
        component={Notifications}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="Schedule"
        component={Schedule}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="EnterName"
        component={EnterName}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="RegisterEmail"
        component={RegisterEmail}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="Promo_Code"
        component={Promo_Code}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="Nodata"
        component={Nodata}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="SearchMap"
        component={SearchMap}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="PickupSearch"
        component={PickupSearch}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="EndtoRider"
        component={EndtoRider}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="PickUpOnmap"
        component={PickUpOnmap}
        options={{
          headerShown: false,
        }}
      />

      <Stack.Screen
        name="SearchingDriver"
        component={SearchingDriver}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="DropAddressPinonMap"
        component={DropAddressPinonMap}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="Search"
        component={Search}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="All_Address"
        component={All_Address}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="SearchPickAddress"
        component={SearchPickAddress}
        options={{
          headerShown: false,
        }}
      />

      <Stack.Screen
        name="ConfirmBooking"
        component={ConfirmBooking}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="TripDestination"
        component={TripDestination}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="Journey"
        component={Journey}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="PaymentMethod"
        component={PaymentMethod}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="RateDriver"
        component={RateDriver}
        options={{
          headerShown: false,
        }}
      />

      <Stack.Screen
        name="Cabewallet"
        component={Cabewallet}
        options={{
          headerShown: false,
        }}
      />

      <Stack.Screen
        name="PromoCode"
        component={PromoCode}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="RateServices"
        component={RateServices}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="UPI"
        component={UPI}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="CancelScreen"
        component={CancelScreen}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="ShowDriver"
        component={ShowDriver}
        options={{
          headerShown: false,
        }}
      />

      <Stack.Screen
        name="GetInTouchStack"
        component={GetInTouchStack}
        options={{
          headerShown: false,
        }}
      />

      <Stack.Screen
        name="Sos"
        component={Sos}
        options={{
          headerShown: false,
        }}
      />

      <Stack.Screen
        name="RateCab"
        component={RateCab}
        options={{
          headerShown: false,
        }}
      />

      <Stack.Screen
        name="TopUp"
        component={TopUp}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="AddAddress"
        component={AddAddress}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="Address"
        component={Address}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="MyProfile"
        component={MyProfile}
        options={{
          headerShown: false,
        }}
      />

      <Stack.Screen
        name="SplashScreen"
        component={SplashScreen}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="Splash1"
        component={Splash1}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="Splash"
        component={Splash}
        options={{headerShown: false}}
      />

      <Stack.Screen
        name="VerifyOtp"
        component={VerifyOtp}
        options={{headerShown: false}}
      />

      <Stack.Screen name="Pin" component={Pin} options={{headerShown: false}} />
    </Stack.Navigator>
  );
}

export default Home;
