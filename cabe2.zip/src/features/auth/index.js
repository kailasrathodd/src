import {createAsyncThunk, createSlice} from '@reduxjs/toolkit';
import AsyncStorage from '@react-native-async-storage/async-storage';

export const Auth = createSlice({
  name: 'Auth',
  initialState: {
    loggedIn: false,
    user: null,
    UserData: null,
    isLoading: false,
    error: null,
    userDetail: null,
    mappleToken: null,
    onBoarding: false,
    userLog: null,
  },
  reducers: {
    loginRequest: state => {
      state.isLoading = true;
      state.error = null;
    },

    onBoarding: (state, action) => {
      state.onBoarding = action.payload;
      AsyncStorage.setItem('@onBoarding', JSON.stringify(action.payload));
    },
    mappleToken: (state, action) => {
      state.mappleToken = action.payload;
    },
    userLog: (state, action) => {
      state.userLog = action.payload;
    },
    userDetail: (state, action) => {
      state.userDetail = action.payload;
    },
    login: (state, action) => {
      state.loggedIn = true;
      state.onBoarding = true;
      state.user = action.payload;
      state.isLoading = false;
      state.error = null;
    },
    UserData: (state, action) => {
      state.loggedIn = true;
      state.onBoarding = true;
      state.user = action.payload;
      state.isLoading = false;
      state.error = null;
    },
    logout: state => {
      state.loggedIn = false;
      state.user = null;
      state.isLoading = false;
      state.onBoarding = true;
      state.error = null;
    },
  },
});

export const {
  onBoarding,
  login,
  UserData,
  logout,
  userLog,
  setUserDetail,
  userDetail,
  mappleToken,
} = Auth.actions;

export default Auth.reducer;
