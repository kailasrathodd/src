import React from 'react';
import {View, Button, TouchableOpacity, Text, StatusBar} from 'react-native';
import DirectionSettings from '../Screens/singletons/DirectionSettings';
import MapmyindiaDirectionWidget, {
  DirectionsCriteria,
  PlaceOptionsConstants,
} from 'mappls-direction-widget-react-native';
// import // Toast from 'react-native-simple-// Toast';import {getFormattedDistance, getFormattedDuration} from '../utils/Utils';
import CurrentLocation from '../Map/LiveLoc';
import {getFontSize} from '../utility/responsive';

class DirectionWidgetActivity extends React.Component {
  openDirection = async () => {
    let instance = DirectionSettings.getInstance();
    console.log(instance.destination);

    try {
      const data = await MapmyindiaDirectionWidget.openDirectionWidget({
        showStartNavigation: instance.showStartNavigation,
        steps: instance.steps,
        showAlternative: instance.showAlternative,
        profile: instance.profile,
        overview: instance.overview,
        attributions: instance.attributions,
        excludes: instance.excludes,
        destination: instance.destination,
        resource: instance.resource,
        searchPlaceOption: {
          location: instance.location,
          backgroundColor: instance.backgroundColor,
          toolbarColor: instance.toolbarColor,
          zoom: parseInt(instance.zoom),
          pod: instance.pod,
          tokenizeAddress: instance.tokenizeAddress,
          saveHistory: instance.saveHistory,
          historyCount: parseInt(instance.historyCount),
          attributionHorizontalAlignment:
            instance.attributionHorizontalAlignment,
          attributionVerticalAlignment: instance.attributionVerticalAlignment,
          logoSize: instance.logoSize,
          filter: instance.filter,
        },
      });
      instance.destination = {};
      console.log(JSON.stringify(data));
      let duration = data.directionsResponse.routes[0].duration;
      let distance = data.directionsResponse.routes[0].distance;
      // // Toast.show(
      //   `Duration: ${getFormattedDuration(
      //     duration,
      //   )}, Distance: ${getFormattedDistance(distance)}`,
      //   // Toast.SHORT,
      // );
    } catch (e) {
      console.log(e);
    }
  };

  render() {
    return (
      <View
        style={{
          flex: 1,
          justifyContent: 'center',
          alignItems: 'center',
        }}>
        <StatusBar backgroundColor={'transparent'} translucent={true} />

        <View
          style={{
            width: '100%',
            height: '100%',
            top: 0,
            position: 'absolute',
            zIndex: -1,
          }}>
          <CurrentLocation />
        </View>
        <TouchableOpacity
          style={{
            width: '100%',
            alignItems: 'center',

            justifyContent: 'center',
            bottom: '6%',
            position: 'absolute',
          }}
          onPress={() => this.openDirection()}>
          <Text
            style={{
              backgroundColor: '#000055',
              width: '95%',
              textAlign: 'center',
              fontSize: getFontSize(14),
              borderRadius: 12,
              padding: 10,
              color: '#fff',
            }}>
            Done
          </Text>
        </TouchableOpacity>
      </View>
    );
  }
}

DirectionWidgetActivity.navigationOptions = {
  title: 'Hello!',
};

export default DirectionWidgetActivity;
