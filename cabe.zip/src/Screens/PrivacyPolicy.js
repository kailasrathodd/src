import React from 'react';
import {
  StyleSheet,
  Text,
  View,
  ActivityIndicator,
  SafeAreaView,
} from 'react-native';
import WebView from 'react-native-webview';
import Header from '../Components/HeaderComp';

const PrivacyPolicy = ({navigation}, props) => {
  const [isLoading, setIsLoading] = React.useState(true);
  return (
    <SafeAreaView style={{flex: 1}}>
      <Header
        containerStyle={{
          alignSelf: 'center',
        }}
        title={'Privacy & Policy'}
        backPress={() => {
          navigation.pop();
        }}
        {...props}
      />
      <View style={{flex: 1, backgroundColor: '#fff'}}>
        {isLoading && <ActivityIndicator size="large" color="#0000ff" />}

        <WebView
          source={{uri: 'http://192.168.0.25:8000/api/privacy_policy'}}
          onLoad={() => setIsLoading(true)}
          onLoadEnd={() => setIsLoading(false)}
        />
      </View>
    </SafeAreaView>
  );
};

export default PrivacyPolicy;

const styles = StyleSheet.create({});
