import {View, Text} from 'react-native';
import React from 'react';
import RideStatus from '../Booking/RideStatus';

const home = () => {
  return (
    <View>
      <RideStatus status={'requested'} />;
    </View>
  );
};

export default home;
