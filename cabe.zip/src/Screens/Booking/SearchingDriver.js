/* eslint-disable react-native/no-inline-styles */
import React, {useEffect} from 'react';
import {View, SafeAreaView} from 'react-native';
import {useDispatch, useSelector} from 'react-redux';
import ButtonSlide from '../../Components/ButtonSlide';
import {
  getDriverAPI,
  getRideDetailAPI,
  driveLocAPI,
} from '../../features/CreateToRide/riderAPI';
import {ride_id} from '../../features/CreateToRide';
import Retry from '../../Components/Retry';
import MapLive from '../Map/MapLive';

const SearchingDriver = React.memo(({navigation}) => {
  const dispatch = useDispatch();
  const rider = useSelector(state => state?.rider?.GetRideDetail);

  useEffect(() => {
    const rideDetailInterval = setInterval(() => {
      if (rider && rider?.requested) {
        dispatch(getRideDetailAPI(rider?._id));
        dispatch(ride_id(rider?._id));
      } else if (rider?.arrived || rider?.accepted || rider?.started) {
        dispatch(getDriverAPI({ride_id: rider._id}));
        dispatch(driveLocAPI({ride_id: rider._id}));
        console.tron.log('SearchingDriver');
      }
    }, 1000);

    return () => clearInterval(rideDetailInterval);
  }, [rider, dispatch]);

  useEffect(() => {
    dispatch(getDriverAPI({ride_id: rider?._id}));
    const riderStatusInterval = setInterval(() => {
      console.tron.log('SearchingDriver222');
      if (rider) {
        switch (rider.status) {
          case 'accepted':
          case 'arrived':
            dispatch(getDriverAPI({ride_id: rider._id}));
            dispatch(driveLocAPI({ride_id: rider._id}));
            navigation.navigate('ShowDriver');
            break;
          case 'timeout':
          case 'customer_cancelled':
            navigation.navigate('HomeScreen');
            break;
          default:
            break;
        }
      }
    }, 5000);

    return () => clearInterval(riderStatusInterval);
  }, [rider, navigation]);

  return (
    <SafeAreaView style={{flex: 1, backgroundColor: '#fff'}}>
      <View style={{width: '100%', height: '100%', position: 'absolute'}}>
        <MapLive />
      </View>
      <View
        style={{
          width: '100%',
          alignItems: 'center',
          justifyContent: 'space-evenly',
          flexDirection: 'row',
          marginTop: '5%',
        }}>
        <View
          style={{
            width: '90%',
            padding: 15,
            backgroundColor: '#fff',
            shadowColor: '#000',
            marginTop: '10%',
            borderRadius: 15,
            shadowOffset: {width: 0, height: 12},
            shadowOpacity: 0.58,
            shadowRadius: 16.0,
            elevation: 24,
          }}>
          <Retry />
        </View>
      </View>
      <ButtonSlide />
    </SafeAreaView>
  );
});

export default SearchingDriver;
