import React, {useEffect, useState} from 'react';
import {
  View,
  StyleSheet,
  ActivityIndicator,
  PermissionsAndroid,
} from 'react-native';
import MapplsGL from 'mappls-map-react-native';
import Polyline from 'mappls-polyline';
import {point} from '@turf/helpers';
import exampleIcon from '../../assets/marker.png';
import Toast from 'react-native-simple-toast';
import {Button, Icon} from 'react-native-elements';
import * as Permissions from 'react-native-permissions';
import RNAndroidLocationEnabler from 'react-native-android-location-enabler';

import {getFontSize, getResHeight} from '../../utility/responsive';
import NavigationButton from '../../components/NavigationButton';
import LocationButton from '../../components/LocationButton';
import {useDispatch, useSelector} from 'react-redux';
import {getRideDetailAPI} from '../../features/ride/ride';
import {setLocation} from '../../features/profile';

const HomeMap = ({...props}) => {
  const dispatch = useDispatch();
  const [gpsStateValue, setGpsStateValue] = useState(false);

  const handleGpsStateChange = newState => {
    setGpsStateValue(newState);
  };

  const styles = {
    icon: {
      iconImage: exampleIcon,
      iconAllowOverlap: true,
      iconSize: 0.2,
      iconAnchor: 'bottom',
    },
  };

  const layerStyles = {
    route: {
      lineColor: 'red',
      lineCap: 'round',
      lineJoin: 'round',
      lineWidth: 5,
      lineGradient: [
        'interpolate',
        ['linear'],
        ['line-progress'],
        0,
        '#000052',
        1,
        '#000052',
      ],
    },
  };

  const initialState = {
    route: '',
    distance: '15',
    backW: 'blue',
    backD: 'blue',
    backB: 'blue',
    isVisible: false,
    sourceCoordinates: '72.848357,19.203732',
    destinationCoordinates: '72.8462,19.1677',
    center: [78.186982, 29.554676],
    markerSourceCoordinates: [72.848357, 19.203732],
    markerDestCoordinates: [72.8462, 19.1677],
  };

  const [state, setState] = useState(initialState);

  const setStateProperty = (property, value) => {
    setState(prevState => ({...prevState, [property]: value}));
  };
  const {rideDetail} = useSelector(state => state.rideDetail);
  useEffect(() => {
    MapplsGL.locationManager.start();
    Toast.show('To get current location press my location button ', Toast.LONG);

    return () => {
      MapplsGL.locationManager.stop();
    };
  }, []);

  // useEffect(() => {
  //   const intervalId = setInterval(() => {
  //     dispatch(getRideDetailAPI(rideDetail && rideDetail._id));
  //   }, 10000);
  //   return () => clearInterval(intervalId);
  // }, [rideDetail]);
  // if (props && props.driverStatus) {
  useEffect(() => {
    if (
      rideDetail &&
      rideDetail.pick_up_longitude &&
      rideDetail.pick_up_latitude &&
      rideDetail.drop_off_longitude &&
      rideDetail.drop_off_latitude
    ) {
      setStateProperty(
        'sourceCoordinates',
        `${rideDetail.pick_up_longitude},${rideDetail.pick_up_latitude}`,
      );
      setStateProperty(
        'destinationCoordinates',
        `${rideDetail.drop_off_longitude},${rideDetail.drop_off_latitude}`,
      );
      setStateProperty('markerSourceCoordinates', [
        parseFloat(rideDetail.pick_up_longitude),
        parseFloat(rideDetail.pick_up_latitude),
      ]);
      setStateProperty('markerDestCoordinates', [
        parseFloat(rideDetail.drop_off_longitude),
        parseFloat(rideDetail.drop_off_latitude),
      ]);
    }
    callApi('driving');
  }, [rideDetail]);
  // }

  const onUpdate = location => {
    const {latitude, longitude, accuracy} = location.coords;
    if (latitude !== null && longitude !== null) {
      dispatch(setLocation({latitude, longitude}));
    }
    this.camera.zoomTo(getZoomLevel());
    this.camera.flyTo([longitude, latitude]);
  };

  const locationComponent = gpsStateValue && (
    <MapplsGL.UserLocation animated={true} visible={true} onUpdate={onUpdate} />
  );

  const getFormattedDistance = distance => {
    // if (distance / 1000 < 1) {
    //   return distance;
    // }
    let dis = distance / 1000;
    dis = Math.round(dis);
    return dis;
  };
  const callApi = async setProfile => {
    try {
      const response = await MapplsGL.RestApi.direction({
        origin: state.sourceCoordinates,
        destination: state.destinationCoordinates,
        profile: setProfile,
        overview: MapplsGL.RestApi.DirectionsCriteria.OVERVIEW_FULL,
        geometries: 'polyline6',
        alternatives: true,
        steps: true,
        traffic: true,
      });

      const routeGeoJSON = Polyline.toGeoJSON(response.routes[0].geometry, 6);
      setStateProperty('route', routeGeoJSON);
      setStateProperty(
        'distance',
        getFormattedDistance(response.routes[0].distance),
      );
      setStateProperty('center', routeGeoJSON.coordinates[0]);
    } catch (error) {
      console.tron.log(error);
    }
  };

  const destMarker =
    ((props && props.status === 'requested') ||
      (props && props.status === 'accepted') ||
      (props && props.status === 'arrived') ||
      (props && props.status === 'started')) &&
    state.route ? (
      <MapplsGL.ShapeSource
        id="symbolLocationSource"
        shape={point(state.markerDestCoordinates)}>
        <MapplsGL.SymbolLayer
          id="symbolLocationSymbols"
          minZoomLevel={1}
          style={styles.icon}
        />
      </MapplsGL.ShapeSource>
    ) : null;

  const sourceMarker =
    ((props && props.status === 'requested') ||
      (props && props.status === 'accepted') ||
      (props && props.status === 'arrived') ||
      (props && props.status === 'started')) &&
    state.route ? (
      <MapplsGL.ShapeSource
        id="symbolLocationSource2"
        shape={point(state.markerSourceCoordinates)}>
        <MapplsGL.SymbolLayer
          id="symbolLocationSymbols2"
          minZoomLevel={1}
          style={styles.icon}
        />
      </MapplsGL.ShapeSource>
    ) : null;

  const routeMaker =
    ((props && props.status === 'requested') ||
      (props && props.status === 'accepted') ||
      (props && props.status === 'arrived') ||
      (props && props.status === 'started')) &&
    state.route ? (
      <MapplsGL.ShapeSource id="routeSource" shape={state.route}>
        <MapplsGL.LineLayer id="routeFill" style={layerStyles.route} />
      </MapplsGL.ShapeSource>
    ) : null;

  const getZoomLevel = () => {
    if (state.route) {
      const distance = state.distance;
      const zoomLevel = Math.round(14 - Math.log2(distance) / 2);
      return zoomLevel;
    }
    return 18;
  };

  if (props && props.status == 'ended') {
    return null;
  }
  return (
    <>
      <MapplsGL.MapView style={{flex: 1}}>
        <MapplsGL.Camera
          zoomLevel={getZoomLevel()}
          ref={c => (this.camera = c)}
          centerCoordinate={state.center}
        />
        {locationComponent}
        {routeMaker}
        {sourceMarker}
        {destMarker}
      </MapplsGL.MapView>

      {props && props.status == undefined && (
        <LocationButton onGpsStateChange={handleGpsStateChange} />
      )}
      {(props && props.status === 'accepted') ||
      (props && props.status === 'started') ? (
        <NavigationButton />
      ) : null}
    </>
  );
};

export default HomeMap;
