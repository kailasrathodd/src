import React, {Component} from 'react';
import {BackHandler, View} from 'react-native';
import MapplsGL from 'mappls-map-react-native';

MapplsGL.setMapSDKKey('57ed4a46a04bb48819af047eede68cee'); //place your mapsdkKey
MapplsGL.setRestAPIKey('fa00fe4ec72020f44813576d13d6cd41'); //your restApiKey
MapplsGL.setAtlasClientId(
  '33OkryzDZsJ5zN81E9FCF9vruFDY_8wEJySBHTVN2YroM6YVpgCRG8GjfY_w_wHLGWA24P-wObVzK2I7yH0AtQ==',
); //your atlasClientId key
MapplsGL.setAtlasClientSecret(
  'lrFxI-iSEg_7x4WFo74p0-leBomnlnqQTpyHrd7f--g-2lk3ZpOOZwBvabvkCEVBSC1yny1ymG7pZN0FkXFrzi8og6fFRBF7',
); //your atlasClientSecret key
// MapplsGL.setAtlasGrantType('client_credentials');

export default class MapPage extends Component {
  render() {
    return (
      <View style={{flex: 1}}>
        <MapplsGL.MapView style={{flex: 1}}>
          <MapplsGL.Camera
            ref={c => (this.camera = c)}
            zoomLevel={12}
            minZoomLevel={4}
            maxZoomLevel={22}
            centerCoordinate={[77.231409, 28.6162]}
          />
          <MapplsGL.UserLocation />
        </MapplsGL.MapView>
      </View>
    );
  }
}
