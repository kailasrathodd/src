import React, {useState, useRef} from 'react';
import {View, TextInput} from 'react-native';

const OtpScreen = () => {
  const [otp, setOtp] = useState(['', '', '', '']);
  const refs = [useRef(), useRef(), useRef(), useRef()];

  const handleChange = (value, index) => {
    const newOtp = [...otp];
    newOtp[index] = value;
    setOtp(newOtp);

    if (value && index < 3) {
      refs[index + 1].current.focus();
    }
  };

  return (
    <View style={{flexDirection: 'row'}}>
      {otp.map((digit, index) => (
        <TextInput
          key={index}
          style={{
            borderWidth: 1,
            borderColor: '#ccc',
            borderRadius: 5,
            width: 50,
            height: 50,
            marginHorizontal: 5,
            textAlign: 'center',
          }}
          keyboardType="numeric"
          maxLength={1}
          value={digit}
          onChangeText={value => handleChange(value, index)}
          ref={refs[index]}
        />
      ))}
    </View>
  );
};

export default OtpScreen;
