import React, {useState, useRef} from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
} from 'react-native';

export default function OTPVerification() {
  const [otp, setOTP] = useState('');
  const refs = useRef([]);

  const handleVerifyOTP = () => {
    if (otp.length !== 4) {
      alert('Please enter a valid OTP');
    } else {
      // Perform OTP verification
      alert('OTP verification successful!');
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Enter the 4-digit OTP</Text>
      <View style={styles.inputContainer}>
        <TextInput
          style={styles.input}
          keyboardType="numeric"
          maxLength={1}
          onChangeText={text => {
            setOTP(text);
            if (text !== '') {
              refs[1].focus();
            }
          }}
          ref={ref => (refs.current[0] = ref)}
        />
        <TextInput
          style={styles.input}
          keyboardType="numeric"
          maxLength={1}
          onChangeText={text => {
            setOTP(otp + text);
            if (text !== '') {
              refs[2].focus();
            }
          }}
          ref={ref => (refs.current[1] = ref)}
        />
        <TextInput
          style={styles.input}
          keyboardType="numeric"
          maxLength={1}
          onChangeText={text => {
            setOTP(otp + text);
            if (text !== '') {
              refs[3].focus();
            }
          }}
          ref={ref => (refs.current[2] = ref)}
        />
        <TextInput
          style={styles.input}
          keyboardType="numeric"
          maxLength={1}
          onChangeText={text => {
            setOTP(otp + text);
            if (text !== '') {
              refs[3].blur();
            }
          }}
          ref={ref => (refs.current[3] = ref)}
        />
      </View>
      <TouchableOpacity style={styles.button} onPress={handleVerifyOTP}>
        <Text style={styles.buttonText}>Verify OTP</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  inputContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 20,
  },
  input: {
    borderWidth: 1,
    borderColor: 'gray',
    width: 60,
    height: 60,
    borderRadius: 10,
    textAlign: 'center',
    fontSize: 24,
  },
  button: {
    backgroundColor: 'blue',
    marginTop: 20,
    borderRadius: 10,
    paddingVertical: 10,
  },
  buttonText: {
    color: 'white',
    textAlign: 'center',
    fontSize: 18,
    fontWeight: 'bold',
  },
});
