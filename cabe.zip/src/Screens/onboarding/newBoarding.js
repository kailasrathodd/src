import React, {useContext, useRef, useState, useEffect, Component} from 'react';
import {
  FlatList,
  Image,
  Text,
  TouchableOpacity,
  View,
  Animated,
  ImageBackground,
} from 'react-native';
import {Button} from 'react-native-elements';
import {connect} from 'react-redux';
import AsyncStorage from '@react-native-async-storage/async-storage';

import theme from '../../theme';
import {
  SCREENWIDTH,
  SCREENHEIGHT,
  getFontSize,
  getResHeight,
  getResWidth,
} from '../../utility/responsive';
import Splash from './Splash';
import Splash1 from './Splash1';
import ViewPagerIndicator from '../../Components/ViewPagerIndicator';

class ImageLoader extends Component {
  state = {
    opacity: new Animated.Value(0),
  };

  onLoad = () => {
    Animated.timing(this.state.opacity, {
      toValue: 1,
      duration: 500,
      useNativeDriver: true,
    }).start();
  };

  render() {
    return (
      <Animated.Image
        onLoad={this.onLoad}
        {...this.props}
        style={[
          {
            opacity: this.state.opacity,
            transform: [
              {
                scale: this.state.opacity.interpolate({
                  inputRange: [0, 1],
                  outputRange: [0.85, 1],
                }),
              },
            ],
          },
          this.props.style,
        ]}
      />
    );
  }
}

export class NewBoarding extends Component {
  constructor(props) {
    super(props);
    this.state = {
      currentIndex: 0,
      isVisible: true,
      opacityView: new Animated.Value(1),
    };
    // this.mylogin();

    this._unsubscribe = this.props.navigation.addListener(
      'didFocus',
      async () => {
        await props.login();
        await props.onBoarding();
      },
    );
  }

  // async mylogin() {
  //   if (this.props.islogin.islogin !== null && this.props.islogin.remember) {
  //     this.props.navigation.navigate('dashboard');
  //     this.setState({firstLunch: false});
  //   } else if (
  //     this.props.islogin.islogin == undefined &&
  //     this.state.firstLunch == true
  //   ) {
  //     this.props.navigation.navigate('onBoarding');
  //   } else if (
  //     this.props.islogin.islogin == undefined &&
  //     this.state.firstLunch == false
  //   ) {
  //     this.props.navigation.navigate('Login');
  //   } else if (this.props.islogin.islogin == true) {
  //     this.props.navigation.navigate('dashboard');
  //     this.setState({firstLunch: false});
  //   } else {
  //     AsyncStorage.removeItem('@islogin');
  //     AsyncStorage.removeItem('@islogin');
  //   }
  // }

  secondCall = () => {
    return <Splash1 />;
  };

  Hide_Splash_Screen = () => {
    this.setState({
      isVisible: false,
    });
  };

  async componentDidMount() {
    var that = this;
    setTimeout(function () {
      that.Hide_Splash_Screen();
    }, 3000);
  }

  // componentWillUnmount() {
  //   this._unsubscribe.remove();
  // }

  onItemsChanges = async ({viewableItems}) => {
    const index = viewableItems[0].index;
    await this.setState({currentIndex: index});
  };

  render() {
    const dataArray = [
      {
        id: '1',
        img: require('../../assets/onBoarding/onb_1.png'),
        color: '#FFFFFF',
        titleColor: '#053C6D',
        desColor: '#000',
        // title: 'title 1',
        des: 'Looking to book a ride ?',
        imgBg: require('../../assets/img/first_bg.png'),
      },
      {
        id: '2',
        img: require('../../assets/onBoarding/onb_1.png'),
        imgBg: require('../../assets/img/first_bg.png'),
        color: '#E77817',
        titleColor: '#FFFFFF',
        desColor: '#000',
        // title: 'title 2',
        des: ' Verified Cars at your Service ',
      },
      {
        id: '3',
        img: require('../../assets/onBoarding/onb_1.png'),
        imgBg: require('../../assets/img/first_bg.png'),
        color: 'grey',
        titleColor: '#FFFFFF',
        desColor: '#000',
        // title: ' title3',
        des: ' You can pay by our secure Payment Gateway, using any of the methods like: UPIs/Wallets / Net Banking & Debit/Credit Cards.',
      },
    ];
    const page = this.state.currentIndex;

    return (
      <View
        style={{
          width: SCREENWIDTH,
          height: SCREENHEIGHT,
          flex: 1,

          position: 'relative',
        }}>
        {this.state.isVisible == true ? (
          <>
            <Splash />
            <Animated.View
              onLoad={this.onLoadView}
              style={[
                {
                  width: '100%',
                  height: '100%',

                  zIndex: 1,
                  backgroundColor: 'white',
                  opacity: this.state.opacityView,
                },
              ]}>
              <View
                style={{
                  width: getResWidth(100),
                  height: getResHeight(100),
                  position: 'absolute',
                  alignSelf: 'center',
                  justifyContent: 'center',
                  alignItems: 'center',
                  alignContent: 'center',
                  bottom: '40%',
                }}>
                <ImageLoader
                  style={{
                    width: getResWidth(150),
                    height: getResHeight(150),
                    backgroundColor: 'transparent',
                    resizeMode: 'contain',
                    alignSelf: 'center',
                  }}
                  resizeMode="contain"
                  source={require('../../assets/img/logo.png')}
                />
              </View>
            </Animated.View>
          </>
        ) : (
          <>
            <View
              style={{
                width: SCREENWIDTH,
                height: SCREENHEIGHT,
                flex: 1,
              }}>
              <FlatList
                ref={node => (this.flatRef = node)}
                horizontal
                pagingEnabled={true}
                showsHorizontalScrollIndicator={false}
                legacyImplementation={false}
                data={dataArray}
                keyExtractor={item => item.id}
                renderItem={({item}) => <OnBordeingRender data={item} />}
                viewabilityConfig={{
                  waitForInteraction: false,
                  itemVisiblePercentThreshold: 1,
                }}
                onViewableItemsChanged={this.onItemsChanges}
              />

              <View
                style={{
                  position: 'absolute',
                  width: '90%',
                  alignSelf: 'center',
                  marginTop: SCREENHEIGHT - 150,
                  width: SCREENWIDTH,
                  height: SCREENHEIGHT,
                }}>
                <View
                  style={{
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                    marginLeft: '3%',
                    marginTop: '22%',
                    zIndex: 0,
                    flex: 1,
                  }}>
                  <ViewPagerIndicator
                    style={{}}
                    numPages={dataArray.length}
                    activeIndex={page}
                    // defaultColor={theme.color.dimLight}
                    defaultColor={page === 2 ? '#356289' : '#f9dfc8'}
                    activeColor={
                      page === 1
                        ? 'white'
                        : page === 2
                        ? 'white'
                        : theme.color.primary
                    }
                  />

                  <Button
                    onPress={() => {
                      this.props.navigation.navigate('SplashScreen');
                    }}
                    type="clear"
                    style={{zIndex: 0}}
                    title={'Skip'}
                    titleStyle={{
                      fontSize: getFontSize(14),
                      fontWeight: '800',
                      // borderWidth: 1,
                      // backgroundColor: 'red',

                      color:
                        page === 1
                          ? 'white'
                          : page === 2
                          ? 'white'
                          : theme.color.primary,
                    }}
                    containerStyle={{
                      marginTop: '1%',
                    }}
                  />
                </View>
              </View>
            </View>
          </>
        )}
      </View>
    );
  }
}

function OnBordeingRender(props) {
  const {data} = props;
  return (
    <View
      style={{
        width: SCREENWIDTH,
        // height: SCREENHEIGHT + 10,
        flex: 1,
      }}>
      <ImageBackground
        source={require('../../assets/img/first_bg.png')}
        resizeMode="cover"
        style={{
          flex: 1,
          width: '100%',
          height: '100%',
          alignItems: 'center',
          justifyContent: 'space-between',
        }}>
        <Image
          style={{
            width: getResWidth(170),
            height: getResWidth(170),
            justifyContent: 'center',
            position: 'absolute',
            resizeMode: 'contain',
            marginTop: '15%',
          }}
          source={require('../../assets/img/logo.png')}
        />
        <Image
          source={data.img}
          style={{
            width: '100%',
            height: '60%',
            resizeMode: 'contain',
            marginTop: '50%',
          }}
        />
        <Text
          style={{
            fontSize: getFontSize(20),
            fontFamily: theme.font.regular,
            color: data.desColor,
            fontFamily: theme.font.bold,
            opacity: 0.57,
            width: '90%',
            fontWeight: '700',
            bottom: 150,
            position: 'absolute',
            justifyContent: 'center',
            alignSelf: 'center',

            alignContent: 'center',
            alignItems: 'center',
          }}>
          {data.des}
        </Text>
      </ImageBackground>
    </View>
  );
}


