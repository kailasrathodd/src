import React, {useState, useEffect, useRef} from 'react';
import {
  Text,
  View,
  TouchableOpacity,
  FlatList,
  Image,
  ActivityIndicator,
  TextInput,
  Modal,
  Pressable,
  Alert,
} from 'react-native';
import MapplsGL from 'mappls-map-react-native';
import Toast from 'react-native-simple-toast';
import {Searchbar} from 'react-native-paper';
import {
  RideUpdateAPI,
  eLocPick,
  getBasicDetailsAPI,
} from '../../features/basicdetails/basicdetail';
import {useDispatch, useSelector} from 'react-redux';
import theme from '../../theme';
import {getFontSize, getResWidth} from '../../utility/responsive';
import setVectorIcon from '../../Components/VectorComponents';
import {resetPin} from '../../features/location/location';
import {debounce} from 'lodash';

export default function PickupSchedule({navigation}, props) {
  const timeoutRef = useRef(0);
  const cameraRef = useRef(null);
  const [query, setQuery] = useState('');
  const [placesList, setPlacesList] = useState([]);
  const [selectedPlace, setSelectedPlace] = useState([]);
  const [progressBar, setProgressBar] = useState(false);
  const [mapFlex, setMapFlex] = useState(1);
  const [mounted, setMounted] = useState(false);
  const rider_id = useSelector(state => state.auth.user?._id);
  const [modalVisible, setModalVisible] = React.useState('');
  const dispatch = useDispatch();
  const [isVerifyLoading, setIsVerifyLoading] = useState(null);
  const [isLoading, setLoading] = useState(null);
  const [isLong, setLong] = useState(null);
  const [isLat, setLat] = useState(null);
  const [eloc, setEloc] = useState(null);
  const [Address, setAddress] = useState(null);
  const coordinate = useSelector(state => state.basicDetail.eLocPick);
  // const basicDetail = useSelector(state => state.basicDetail?.basicDetail);
  const Longitude = coordinate?.longitude;
  const Latitude = coordinate?.latitude;
  const riderUpdate = useSelector(
    state => state.basicDetail?.riderUpdate?.Rider_Data,
  );
  useEffect(() => {
    setMounted(true);
    callAutoSuggest('Mapmy');

    return () => {
      setMounted(false);
      clearTimeout(timeoutRef.current);
    };
  }, []);

  const debouncedCallAutoSuggest = debounce(text => {
    console.log('calling');
    callAutoSuggest(text.trim());
  }, 1000);

  const onTextChange = text => {
    setQuery(text);
    setProgressBar(true);

    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
    }

    timeoutRef.current = setTimeout(() => {
      debouncedCallAutoSuggest(text);
    }, 2000);
  };

  const callAutoSuggest = text => {
    if (text.length > 2) {
      const arr = [];
      MapplsGL.RestApi.autoSuggest({
        query: text,
      })
        .then(data => {
          if (mounted) {
            if (
              data.suggestedLocations !== undefined &&
              data.suggestedLocations.length > 0
            ) {
              for (let i = 0; i < data.suggestedLocations.length; i++) {
                arr.push([
                  data.suggestedLocations[i].placeName,
                  [
                    parseFloat(data.suggestedLocations[i].longitude),
                    parseFloat(data.suggestedLocations[i].latitude),
                  ],
                  data.suggestedLocations[i].placeAddress,
                  data.suggestedLocations[i].mapplsPin,
                  data.suggestedLocations[i],
                ]);
              }
              setPlacesList(arr);
              setProgressBar(false);
              setMapFlex(0);
            } else {
              Toast.show('No suggestions found', Toast.SHORT);
              setProgressBar(false);
            }
          }
        })
        .catch(error => {
          console.log(error.code, error.message);
          setProgressBar(false);
          Toast.show(error.message, Toast.SHORT);
        });
    } else if (text.length <= 2) {
      setPlacesList([]);
      setProgressBar(false);
      setMapFlex(1);
    }
  };
  const navigateToHomeScreen = () => {
    navigation.reset({
      index: 1,
      routes: [{name: 'DirectionSchedule'}],
    });
  };
  const RideUpdate = (Latitude, Longitude) => {
    setLoading(true);
    dispatch(
      RideUpdateAPI({
        pickup_latitude: Latitude,
        pickup_longitude: Longitude,
        rider_id: rider_id,
      }),
    )
      .then(data => {
        if (data.payload.status === 200) {
          dispatch(
            getBasicDetailsAPI({
              rider_id: rider_id,
            }),
          );
          if (riderUpdate && riderUpdate?.pickup_address !== null) {
            setLoading(false);
            navigation.navigate('SearchSchedule');
          } else {
            setLoading(false);
            navigateToHomeScreen();
          }
        }
      })
      .catch(error => {
        setIsVerifyLoading(false);
        console.error(error);
      });
  };

  const renderSeparator = () => {
    return (
      <View
        style={{
          height: 1,
          backgroundColor: '#CED0CE',
          marginLeft: 25,
        }}
      />
    );
  };

  const renderItem =
    placesList.length > 0 ? (
      <>
        {isLoading == true ? (
          <ActivityIndicator
            color={theme.color.primary}
            size={35}
            style={{
              justifyContent: 'center',
              flex: 1,
              alignSelf: 'center',
              alignContent: 'center',
              alignItems: 'center',
              position: 'absolute',
            }}
          />
        ) : (
          <View
            style={{
              flex: 1,
              position: 'absolute',
              top: 70,
              left: 0,
              right: 0,
              backgroundColor: 'white',
              zIndex: 40,
              marginTop: '20%',
            }}>
            <FlatList
              data={placesList}
              ItemSeparatorComponent={renderSeparator}
              keyExtractor={(item, index) => item[0] + index}
              renderItem={({item}) => (
                <TouchableOpacity
                  style={{
                    paddingLeft: 10,
                    paddingBottom: 10,
                    paddingRight: 5,
                  }}
                  onPress={async () => {
                    setLoading(true);
                    const eloc = item[3];
                    setEloc(eloc);
                    const pickup_address = item[0];
                    const pickup_addres = item[2];
                    const newAddress = pickup_address + pickup_addres;
                    setAddress(newAddress);

                    await dispatch(
                      RideUpdateAPI({
                        pickup_address: pickup_address + pickup_addres,
                        rider_id: await rider_id,
                        pickup_details: item[4],
                      }),
                    )
                      .then(data => {
                        if (data.payload.status === 200) {
                          dispatch(eLocPick(eloc))
                            .then(data => {
                              if (data.payload.status === 200) {
                                RideUpdate(
                                  data.payload.data.latitude,
                                  data.payload.data.longitude,
                                );
                              }
                            })
                            .catch(error => {
                              setLoading(false);
                              console.error(error);
                            });
                        }
                      })
                      .catch(error => {
                        setLoading(false);
                        console.error(error);
                      });
                  }}>
                  <View style={{flexDirection: 'row', alignItems: 'center'}}>
                    <View
                      style={{
                        flexDirection: 'column',
                        paddingStart: 10,
                        paddingEnd: 5,
                      }}>
                      <Text
                        style={{
                          fontSize: getFontSize(15),
                          fontWeight: theme.WEIGHT.FONT_WEIGHT_BOLD,
                        }}>
                        {setVectorIcon({
                          type: 'Entypo',
                          name: 'location-pin',
                          size: getFontSize(20),
                          color: '#000',
                        })}
                        {item[0]}
                      </Text>

                      <Text
                        style={{
                          fontSize: getFontSize(11),
                          fontWeight: theme.WEIGHT.FONT_WEIGHT_MEDIUM,
                          marginTop: '2%',
                          marginLeft: '6%',
                        }}>
                        {item[2]}
                      </Text>
                    </View>
                  </View>
                </TouchableOpacity>
              )}
            />
          </View>
        )}
      </>
    ) : null;

  return (
    <View style={{flex: 1, justifyContent: 'center'}}>
      <View
        style={{
          flexDirection: 'row',
          paddingLeft: 5,
          paddingRight: 5,
          justifyContent: 'center',
          alignContent: 'center',
          marginTop: '10%',
          flex: 1,
        }}>
        <Searchbar
          placeholder="Search Here for Schedule "
          onClear={text => searchFilterFunction(text)}
          style={{
            height: 50,
            borderColor: '#009688',
            backgroundColor: '#FFFFFF',
            width: '90%',
            elevation: 20,
            shadowColor: '#e200',
            zIndex: 55,
          }}
          autoFocus={true}
          onChangeText={text => onTextChange(text)}
          value={query || ''}
        />
      </View>
      <ActivityIndicator
        animating={progressBar}
        hidesWhenStopped={true}
        color="blue"
        style={{
          alignSelf: 'flex-end',
          borderRadius: 100,
          padding: 2,
          alignItems: 'flex-end',
          position: 'absolute',
          top: 51,
          right: 65,
          zIndex: 111,
          justifyContent: 'flex-end',
        }}
      />
      {/* <TouchableOpacity
        style={{
          width: '30%',
          alignSelf: 'flex-start',
          marginLeft: '5%',
          borderRadius: 10,
          padding: 2,
          backgroundColor: '#000055',
          position: 'absolute',
          top: 100,
          zIndex: 111,
        }}
        onPress={() => {
          dispatch(resetPin(true));
          navigation.navigate('PickUpOnmap');
        }}>
        <Text
          style={{
            padding: 5,
            fontWeight: 700,
            fontSize: 12,
            color: '#fff',
            alignSelf: 'center',
          }}>
          choose on Map
        </Text>
      </TouchableOpacity> */}
      {renderItem}
    </View>
  );
}
