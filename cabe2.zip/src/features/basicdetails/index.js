import {createSlice} from '@reduxjs/toolkit';

const basicDetail = createSlice({
  name: 'basicDetail',
  initialState: {
    basicDetail: null,

    eLocPick: null,
    eLocDrop: null,
    ProfileUpdate: null,
    getElocPickup: null,
    Profile: null,
    riderUpdate: null,
    razorpayOrderCreate: null,
    rideCancel: null,
  },
  reducers: {
    razorpayOrderCreate: (state, action) => {
      state.razorpayOrderCreate = action.payload;
    },
    basicDetails: (state, action) => {
      state.basicDetail = action.payload;
    },
    setPickAddress: (state, action) => {
      state.basicDetail.pickup_address = action.payload;
    },
    ProfileUpdate: (state, action) => {
      state.ProfileUpdate = action.payload;
    },
    Profile: (state, action) => {
      state.Profile = action.payload;
    },
    getElocPickup: (state, action) => {
      state.getElocPickup = action.payload;
    },
    getElocTotDropAPI: (state, action) => {
      state.getElocTotDropAPI = action.payload;
    },
    eLocDrop: (state, action) => {
      state.eLocDrop = action.payload;
    },
    eLocPick: (state, action) => {
      state.eLocPick = action.payload;
    },
    riderUpdate: (state, action) => {
      state.riderUpdate = action.payload;
    },
    rideCancel: (state, action) => {
      state.rideCancel = action.payload;
    },
  },
});

export const {
  basicDetails,
  eLocPick,
  eLocDrop,
  razorpayOrderCreate,
  ProfileUpdate,
  getElocPickup,
  getElocTotDropAPI,
  riderUpdate,
  Profile,
  rideCancel,
  setPickAddress,
} = basicDetail.actions;

export default basicDetail.reducer;
