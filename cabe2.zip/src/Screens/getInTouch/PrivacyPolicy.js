import React, {useState} from 'react';
import {
  StyleSheet,
  Text,
  View,
  ActivityIndicator,
  SafeAreaView,
} from 'react-native';
import WebView from 'react-native-webview';
// import Header from '../../components/';
import {BASE_URL} from '../../config/constants';
import styles from './styles';
import theme from '../../theme';
import Header from '../../Components/HeaderComp';

const PrivacyPolicy = ({navigation}, props) => {
  const [isLoading, setIsLoading] = useState(true);

  return (
    <SafeAreaView style={{flex: 1}}>
      <Header
        containerStyle={{
          alignSelf: 'center',
          backgroundColor: theme.color.white,
        }}
        title={'Privacy & Policy'}
        backPress={() => {
          navigation.pop();
        }}
        {...props}
      />

      <View style={styles.contentContainer}>
        <WebView
          source={{uri: BASE_URL + '/api/privacy_policy'}}
          onLoadStart={() => setIsLoading(true)}
          onLoadEnd={() => setIsLoading(false)}
        />
        {isLoading && (
          <View style={styles.activityIndicatorContainer}>
            <ActivityIndicator size="large" color="#0000ff" />
          </View>
        )}
      </View>

      {/* <View style={{flex: 1, backgroundColor: theme.color.white}}>
        <View style={{flex: 1, alignItems: 'center', justifyContent: 'center'}}>
          {isLoading && <ActivityIndicator size="large" color="#0000ff" />}
        </View>

        <WebView
          source={{uri: API_URL + '/api/privacy_policy'}}
          onLoad={() => setIsLoading(true)}
          onLoadEnd={() => setIsLoading(false)}
        />
      </View> */}
    </SafeAreaView>
  );
};

export default PrivacyPolicy;
