import {createAsyncThunk} from '@reduxjs/toolkit';
import API from '../../APIs/RepositoryFactory';
import * as sos from './index';

export const sosAPI = createAsyncThunk(
  'sosAPI/sosAPI',
  async (payload, thunkAPI) => {
    try {
      const response = await API.sosRepository.sos(payload);
      //   console.tron.log(response.data.status);
      if (response.data.status == 200) {
        thunkAPI.dispatch(sos.sosNumber(response.data?.data));
      }
      if (response.data.status == 201) {
        thunkAPI.dispatch(sos.sosNumber(response.data?.data));
      }
      return response;
    } catch (error) {
      console.tron.log('sosAPI: ', error);
    }
  },
);
