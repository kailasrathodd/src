import {createSlice} from '@reduxjs/toolkit';

const hub = createSlice({
  name: 'hub',
  initialState: {
    hub: null,
    loading: false,
    error: null,
  },
  reducers: {
    setHub: (state, action) => {
      state.hub = action.payload;
      state.loading = false;
      state.error = null;
    },
  },
});

export const {setHub, loading} = hub.actions;

export default hub.reducer;
