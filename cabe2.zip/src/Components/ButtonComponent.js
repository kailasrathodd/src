import * as React from 'react';
import {
  StyleSheet,
  Image,
  Text,
  Button,
  View,
  Alert,
  TouchableOpacity,
} from 'react-native';

function ButtonComponent({...props}) {
  return (
    <TouchableOpacity {...props} disabled={props.disabled}>
      <View>
        <Text
          style={{
            color: `${props.textColor}`,
            fontSize: props.textFontSize,
            fontWeight: 500,
          }}>
          {props.buttonText}
        </Text>
      </View>
    </TouchableOpacity>
  );
}

ButtonComponent.defaultProps = {
  textColor: '#000',
  textFontSize: 15,
  disabled: false,
};

export default ButtonComponent;
