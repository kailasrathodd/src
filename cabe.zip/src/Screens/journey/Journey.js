import {StyleSheet, Text, View, TouchableOpacity, FlatList} from 'react-native';
import React, {useEffect, useState} from 'react';
import {createMaterialTopTabNavigator} from '@react-navigation/material-top-tabs';
import Header from '../../Components/HeaderComp';
import {getFontSize, getResHeight, getResWidth} from '../../utility/responsive';
import setVectorIcon from '../../Components/VectorComponents';
import {useDispatch, useSelector} from 'react-redux';
import {riderJourneyHistoryAPI} from '../../features/CreateToRide/riderAPI';

const Tab = createMaterialTopTabNavigator();

function Journey({navigation}, props) {
  const dispatch = useDispatch();
  const rider_id = useSelector(state => state.auth.userLog);

  // console.tron.log('rider_id----------', riderJourneyHistory[0].pickup_address);

  useEffect(() => {
    dispatch(riderJourneyHistoryAPI({rider_id: rider_id?._id}));
  }, []);
  return (
    <View
      style={{
        flex: 1,
      }}>
      <Header
        containerStyle={{
          alignSelf: 'center',
          backgroundColor: '#fff',
        }}
        title={'My Journeys'}
        backPress={() => {
          navigation.navigate('HomeScreen');
        }}
        {...props}
      />
      <Tab.Navigator
        initialRouteName="Active Now"
        screenOptions={{
          tabBarPressColor: '#ddd',
          tabBarActiveTintColor: '#008000',
          // tabBarIndicatorStyle: '',
          tabBarIndicatorStyle: {
            backgroundColor: '#5a2ef1',
            height: 4,
            width: '40%',
            marginLeft: '5%',
          },
          tabBarLabelStyle: {
            fontSize: 14,
            color: '#000',

            textTransform: 'capitalize',
          },
          tabBarStyle: {borderColor: '#fff'},
        }}>
        <Tab.Screen
          name="Completed"
          component={SecondRoute}
          options={{tabBarLabel: 'Completed'}}
        />
        <Tab.Screen
          name="Cancelled"
          component={ThirdRoute}
          options={{tabBarLabel: 'Cancelled'}}
        />
        {/* <Tab.Screen
          name="Active"
          component={FirstRoute}
          options={{tabBarLabel: 'Active Now'}}
        /> */}
      </Tab.Navigator>
    </View>
  );
}

function FirstRoute() {
  const riderJourney = useSelector(state => state?.rider?.riderJourneyHistory);
  const riderJourneyHistory = riderJourney?.filter(
    item => item?.status === 'Active',
  );

  const [expandedItem, setExpandedItem] = React.useState(null);

  const toggleExpand = id => {
    if (id === expandedItem) {
      setExpandedItem(null);
    } else {
      setExpandedItem(id);
    }
  };

  const renderItem = ({item}) => {
    const isExpanded = expandedItem === item._id;

    return (
      <View
        style={{
          width: '96%',
          borderRadius: 25,
          marginTop: 10,
          marginBottom: 10,
          backgroundColor: '#fff',
          alignSelf: 'center',
          shadowColor: '#000',
          shadowOffset: {
            width: 0,
            height: 2,
          },
          shadowOpacity: 0.25,
          shadowRadius: 3.84,
          elevation: 5,
        }}>
        <View>
          <View
            style={{
              flexDirection: 'row',

              alignItems: 'center',
              width: '90%',
              height: getResHeight(80),
              alignSelf: 'center',
              justifyContent: 'space-between',

              backgroundColor: '#fff',
            }}>
            <View>
              <View
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  gap: getResWidth(15),
                }}>
                {setVectorIcon({
                  type: 'MaterialIcons',
                  name: 'my-location',
                  color: 'blue',
                  size: getFontSize(25),
                })}
                <Text style={{color: '#000', fontSize: getFontSize(12)}}>
                  {item?.pickup_address?.length > 20
                    ? item?.pickup_address.substring(0, 20) + '...'
                    : item?.pickup_address}
                </Text>
              </View>
              <View
                style={{
                  borderStyle: 'dotted',
                  height: 15,
                  borderLeftWidth: 5,
                  marginLeft: '7%',
                  marginTop: '2%',
                }}
              />
              <View
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  gap: getResWidth(15),
                  marginTop: '2%',
                }}>
                {setVectorIcon({
                  type: 'MaterialIcons',
                  name: 'pin-drop',
                  color: '#008000',
                  size: getFontSize(25),
                })}
                <Text style={{fontSize: getFontSize(12), color: '#000'}}>
                  {item?.drop_address?.length > 22
                    ? item?.drop_address.substring(0, 22) + '...'
                    : item?.drop_address}
                </Text>
              </View>
            </View>

            <View
              style={{
                alignItems: 'center',
                gap: getResWidth(5),
              }}>
              <View
                style={{
                  backgroundColor:
                    item?.status === 'Active'
                      ? '#008000'
                        ? item?.status == 'Active Now'
                        : '#e91414 '
                      : '#000055',
                  // width: '100%',
                  height: getResHeight(28),
                  alignItems: 'center',
                  justifyContent: 'center',
                  padding: 6,
                  borderRadius: 10,
                }}>
                <Text
                  style={{
                    fontSize: getFontSize(15),
                    color: '#fff',
                    fontWeight: 900,
                  }}>
                  {item?.status}
                </Text>
              </View>

              <Text style={{fontSize: getFontSize(15), color: '#000'}}>
                {item?.ride_number}
              </Text>
            </View>
          </View>
          <TouchableOpacity onPress={() => toggleExpand(item._id)}>
            <Text style={{textAlign: 'center', marginBottom: '2%'}}>
              {setVectorIcon({
                type: 'Entypo',
                name: isExpanded ? 'chevron-small-up' : 'chevron-small-down',
                color: '#000',
                size: getFontSize(25),
              })}
            </Text>
          </TouchableOpacity>
        </View>
        {isExpanded && (
          <View
            style={{
              borderTopWidth: 1,
              borderTopColor: '#ddd',
              paddingVertical: getResHeight(10),
              flexDirection: 'row',
              justifyContent: 'space-evenly',
            }}>
            <Text style={{fontSize: getFontSize(15)}}>
              {setVectorIcon({
                type: 'Ionicons',
                name: 'ios-time-outline',
                color: '#a6a6a6',
                size: getFontSize(18),
              })}
              {'  '}
              {Math.floor(item?.actual_estimate_time / 60)}
            </Text>
            <Text style={{fontSize: getFontSize(15)}}>
              {setVectorIcon({
                type: 'Octicons',
                name: 'location',
                color: '#a6a6a6',
                size: getFontSize(18),
              })}
              {'  '}
              {item?.ride_km}
            </Text>
            <Text style={{fontSize: getFontSize(15)}}>
              {setVectorIcon({
                type: 'Ionicons',
                name: 'wallet-outline',
                color: '#a6a6a6',
                size: getFontSize(18),
              })}
              {'  '}
              {setVectorIcon({
                type: 'FontAwesome',
                name: 'rupee',

                size: getFontSize(13),
              })}{' '}
              {parseFloat(item?.ride_amount).toFixed(2)}
              {/* {item?.ride_amount} */}
            </Text>
          </View>
        )}
      </View>
    );
  };
  return (
    <View style={{backgroundColor: '#fff', flex: 1}}>
      <FlatList
        data={riderJourneyHistory}
        renderItem={renderItem}
        keyExtractor={item => item._id}
      />
    </View>
  );
}

const SecondRoute = () => {
  const riderJourney = useSelector(state => state?.rider?.riderJourneyHistory);
  const riderJourneyHistory = riderJourney?.filter(
    item => item?.status === 'completed',
  );

  const [expandedItem, setExpandedItem] = React.useState(null);

  const toggleExpand = id => {
    if (id === expandedItem) {
      setExpandedItem(null);
    } else {
      setExpandedItem(id);
    }
  };

  const renderItem = ({item}) => {
    const isExpanded = expandedItem === item._id;
    return (
      <View
        style={{
          width: '96%',
          borderRadius: 25,
          marginTop: 10,
          marginBottom: 10,
          backgroundColor: '#fff',
          alignSelf: 'center',
          shadowColor: '#000',
          shadowOffset: {
            width: 0,
            height: 2,
          },
          shadowOpacity: 0.25,
          shadowRadius: 3.84,
          elevation: 5,
        }}>
        <View>
          <View
            style={{
              flexDirection: 'row',

              alignItems: 'center',
              width: '90%',
              height: getResHeight(80),
              alignSelf: 'center',
              justifyContent: 'space-between',

              backgroundColor: '#fff',
            }}>
            <View>
              <View
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  gap: getResWidth(15),
                }}>
                {setVectorIcon({
                  type: 'MaterialIcons',
                  name: 'my-location',
                  color: 'blue',
                  size: getFontSize(25),
                })}
                <Text style={{color: '#000', fontSize: getFontSize(12)}}>
                  {item?.pickup_address?.length > 20
                    ? item?.pickup_address.substring(0, 20) + '...'
                    : item?.pickup_address}
                </Text>
              </View>
              <View
                style={{
                  borderStyle: 'dotted',
                  height: 15,
                  borderLeftWidth: 5,
                  marginLeft: '7%',
                  marginTop: '2%',
                }}
              />
              <View
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  gap: getResWidth(15),
                  marginTop: '2%',
                }}>
                {setVectorIcon({
                  type: 'MaterialIcons',
                  name: 'pin-drop',
                  color: '#008000',
                  size: getFontSize(25),
                })}
                <Text style={{fontSize: getFontSize(12), color: '#000'}}>
                  {item?.drop_address?.length > 22
                    ? item?.drop_address.substring(0, 22) + '...'
                    : item?.drop_address}
                </Text>
              </View>
            </View>

            <View
              style={{
                alignItems: 'center',
                gap: getResWidth(5),
              }}>
              <View
                style={{
                  backgroundColor:
                    item?.status == 'completed' ? '#008000' : '#e91414',
                  // width: '100%',
                  height: getResHeight(28),
                  alignItems: 'center',
                  justifyContent: 'center',
                  padding: 6,
                  borderRadius: 10,
                }}>
                <Text
                  style={{
                    fontSize: getFontSize(15),
                    color: '#fff',
                    fontWeight: 900,
                  }}>
                  {item?.status}
                </Text>
              </View>

              <Text style={{fontSize: getFontSize(15), color: '#000'}}>
                {item?.ride_number}
              </Text>
            </View>
          </View>
          <TouchableOpacity onPress={() => toggleExpand(item._id)}>
            <Text style={{textAlign: 'center', marginBottom: '2%'}}>
              {setVectorIcon({
                type: 'Entypo',
                name: isExpanded ? 'chevron-small-up' : 'chevron-small-down',
                color: '#000',
                size: getFontSize(25),
              })}
            </Text>
          </TouchableOpacity>
        </View>

        {isExpanded && (
          <View
            style={{
              borderTopWidth: 1,
              borderTopColor: '#ddd',
              paddingVertical: getResHeight(10),
              flexDirection: 'row',
              justifyContent: 'space-evenly',
            }}>
            <Text style={{fontSize: getFontSize(15)}}>
              {setVectorIcon({
                type: 'Ionicons',
                name: 'ios-time-outline',
                color: '#a6a6a6',
                size: getFontSize(18),
              })}
              {'  '}
              {Math.floor(item?.actual_estimate_time / 60)}
            </Text>
            <Text style={{fontSize: getFontSize(15)}}>
              {setVectorIcon({
                type: 'Octicons',
                name: 'location',
                color: '#a6a6a6',
                size: getFontSize(18),
              })}
              {'  '}
              {item?.ride_km}
            </Text>
            <Text style={{fontSize: getFontSize(15)}}>
              {setVectorIcon({
                type: 'Ionicons',
                name: 'wallet-outline',
                color: '#a6a6a6',
                size: getFontSize(18),
              })}
              {'  '}
              {setVectorIcon({
                type: 'FontAwesome',
                name: 'rupee',

                size: getFontSize(13),
              })}{' '}
              {parseFloat(item?.ride_amount).toFixed(2)}
              {/* {item.ride_amount} */}
            </Text>
          </View>
        )}
      </View>
    );
  };
  return (
    <View style={{backgroundColor: '#fff', flex: 1}}>
      <FlatList
        data={riderJourneyHistory}
        renderItem={renderItem}
        keyExtractor={item => item._id}
      />
    </View>
  );
};
const ThirdRoute = () => {
  const riderJourney = useSelector(state => state?.rider?.riderJourneyHistory);
  const riderJourneyHistory = riderJourney?.filter(
    item => item?.status === 'customer_cancelled',
  );

  const [expandedItem, setExpandedItem] = React.useState(null);

  const toggleExpand = id => {
    if (id === expandedItem) {
      setExpandedItem(null);
    } else {
      setExpandedItem(id);
    }
  };

  const renderItem = ({item}) => {
    const isExpanded = expandedItem === item._id;
    return (
      <View
        style={{
          width: '96%',
          borderRadius: 25,
          marginTop: 10,
          marginBottom: 10,
          backgroundColor: '#fff',
          alignSelf: 'center',
          shadowColor: '#000',
          shadowOffset: {
            width: 0,
            height: 2,
          },
          shadowOpacity: 0.25,
          shadowRadius: 3.84,
          elevation: 5,
        }}>
        <View>
          <View
            style={{
              flexDirection: 'row',

              alignItems: 'center',
              width: '90%',
              height: getResHeight(80),
              alignSelf: 'center',
              justifyContent: 'space-between',

              backgroundColor: '#fff',
            }}>
            <View>
              <View
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  gap: getResWidth(15),
                }}>
                {setVectorIcon({
                  type: 'MaterialIcons',
                  name: 'my-location',
                  color: 'blue',
                  size: getFontSize(25),
                })}
                <Text style={{color: '#000', fontSize: getFontSize(12)}}>
                  {item?.pickup_address?.length > 20
                    ? item?.pickup_address.substring(0, 20) + '...'
                    : item?.pickup_address}
                </Text>
              </View>
              <View
                style={{
                  borderStyle: 'dotted',
                  height: 15,
                  borderLeftWidth: 5,
                  marginLeft: '7%',
                  marginTop: '2%',
                }}
              />
              <View
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  gap: getResWidth(15),
                  marginTop: '2%',
                }}>
                {setVectorIcon({
                  type: 'MaterialIcons',
                  name: 'pin-drop',
                  color: '#008000',
                  size: getFontSize(25),
                })}
                <Text style={{fontSize: getFontSize(12), color: '#000'}}>
                  {item?.drop_address?.length > 22
                    ? item?.drop_address.substring(0, 22) + '...'
                    : item?.drop_address}
                </Text>
              </View>
            </View>

            <View
              style={{
                alignItems: 'center',
                gap: getResWidth(5),
              }}>
              <View
                style={{
                  backgroundColor:
                    item?.status == 'customer_cancelled'
                      ? '#e91414'
                      : '#008000',
                  // width: '100%',
                  height: getResHeight(28),
                  alignItems: 'center',
                  justifyContent: 'center',
                  padding: 6,
                  borderRadius: 10,
                }}>
                <Text
                  style={{
                    fontSize: getFontSize(15),
                    color: '#fff',
                    fontWeight: 900,
                  }}>
                  {/* {item?.status} */}
                  Cancelled
                </Text>
              </View>

              <Text style={{fontSize: getFontSize(15), color: '#000'}}>
                {item?.ride_number}
              </Text>
            </View>
          </View>
          <TouchableOpacity onPress={() => toggleExpand(item._id)}>
            <Text style={{textAlign: 'center', marginBottom: '2%'}}>
              {setVectorIcon({
                type: 'Entypo',
                name: isExpanded ? 'chevron-small-up' : 'chevron-small-down',
                color: '#000',
                size: getFontSize(25),
              })}
            </Text>
          </TouchableOpacity>
        </View>
        {isExpanded && (
          <View
            style={{
              borderTopWidth: 1,
              borderTopColor: '#ddd',
              paddingVertical: getResHeight(10),
              flexDirection: 'row',
              justifyContent: 'space-evenly',
            }}>
            <Text style={{fontSize: getFontSize(15)}}>
              {setVectorIcon({
                type: 'Ionicons',
                name: 'ios-time-outline',
                color: '#a6a6a6',
                size: getFontSize(18),
              })}
              {'  '}
              {Math.floor(item?.actual_estimate_time / 60)}
            </Text>
            <Text style={{fontSize: getFontSize(15)}}>
              {setVectorIcon({
                type: 'Octicons',
                name: 'location',
                color: '#a6a6a6',
                size: getFontSize(18),
              })}
              {'  '}
              {item?.ride_km}
            </Text>
            <Text style={{fontSize: getFontSize(15)}}>
              {setVectorIcon({
                type: 'Ionicons',
                name: 'wallet-outline',
                color: '#a6a6a6',
                size: getFontSize(18),
              })}
              {'  '}
              {setVectorIcon({
                type: 'FontAwesome',
                name: 'rupee',

                size: getFontSize(13),
              })}{' '}
              {parseFloat(item?.ride_amount).toFixed(2)}
              {/* {item?.ride_amount} */}
            </Text>
          </View>
        )}
      </View>
    );
  };
  return (
    <View style={{backgroundColor: '#fff', flex: 1}}>
      <FlatList
        data={riderJourneyHistory}
        renderItem={renderItem}
        keyExtractor={item => item._id}
      />
    </View>
  );
};

export default Journey;
