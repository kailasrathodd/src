import {
  StyleSheet,
  View,
  Text,
  Button,
  Image,
  SafeAreaView,
  ImageBackground,
  TouchableOpacity,
} from 'react-native';
import {createStackNavigator} from '@react-navigation/stack';
import React, {useState} from 'react';
import SplashScreen from './SplashScreen';

const Stack = createStackNavigator();
export default function Splash1({navigation}, props) {
  const [checked, setChecked] = useState('first');
  return (
    <SafeAreaView
      style={{
        flex: 1,
        backgroundColor: 'white',
      }}>
      <ImageBackground
        source={require('../../assets/img/backgraound.png')}
        resizeMode="cover"
        style={{
          flex: 1,
          width: '100%',
          height: '100%',
          alignItems: 'center',
          justifyContent: 'space-between',
        }}>
        <View style={{justifyContent: 'center', alignItems: 'center', flex: 3}}>
          <Image
            source={require('../../assets/img/logo.png')}
            style={{width: 260, height: 150}}
          />
        </View>
      </ImageBackground>
      <TouchableOpacity
        style={{
          width: '100%',
          alignItems: 'center',
          justifyContent: 'center',

          marginBottom: '5%',
        }}
        onPress={() => navigation.navigate(SplashScreen)}>
        <Text
          style={{
            padding: 15,
            backgroundColor: '#000055',
            width: '90%',

            textAlign: 'center',
            fontSize: 15,
            borderRadius: 11,
            color: '#fff',
          }}>
          Get Started
        </Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
}
