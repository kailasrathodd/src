import React from 'react';
import {View, Text} from 'react-native';
import {getFontSize} from '../utility/responsive';
import Header from '../Components/HeaderComp';

export default function Nodata({navigation}) {
  return (
    <View
      style={{
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        padding: 15,
      }}>
      <Header
        containerStyle={{
          width: '100%',
          alignSelf: 'center',
        }}
        title={''}
        backPress={() => {
          navigation.pop();
        }}
      />
      <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
        <Text style={{fontSize: getFontSize(14)}}>Data Not Found</Text>
      </View>
    </View>
  );
}
