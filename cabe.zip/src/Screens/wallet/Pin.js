import {View, Text, TouchableOpacity} from 'react-native';
import React from 'react';
import {TextInputBase} from 'react-native';
import {TextInput} from 'react-native';

export default function Pin({navigation}, props) {
  const [firstValue, setFirstValue] = React.useState('');
  //   const mobileNo = text.mobileValue;
  const [minute, setMinute] = React.useState(2);
  const [second, setSecond] = React.useState(60);
  return (
    <View style={{flex: 1, flexDirection: 'column', top: 40, padding: 20}}>
      <View style={{marginHorizontal: 20, marginTop: 20}}>
        <Text style={{fontSize: 30, color: '#000'}}>Enter Your pin </Text>
        <Text style={{fontSize: 18, marginTop: 10}}>
          Enter Your Pin and start Your Top Up
        </Text>
      </View>

      {/* <View style={{marginHorizontal: 20}}></View> */}
      <View
        style={{
          flexDirection: 'row',
          justifyContent: 'space-around',
          marginHorizontal: 10,
          marginVertical: 10,
        }}>
        <TextInput
          maxLength={1}
          style={{
            borderBottomWidth: 4,
            borderBottomColor: '#000',
            flex: 0.2,
            textAlign: 'center',
            fontSize: 25,
          }}
          value={firstValue}
          onChangeText={setFirstValue}
          keyboardType="numeric"
          autoFocus={true}
          // onChangeText={() => {
          //   onTextChanged(2);
          //   setFirstValue();
          // }}
        />
        <TextInput
          maxLength={1}
          style={{
            borderBottomWidth: 4,
            borderBottomColor: '#000',
            flex: 0.2,
            textAlign: 'center',
            fontSize: 25,
          }}
          keyboardType="numeric"
          // onChangeText={() => {
          //   onTextChanged(3);

          // }}
        />
        <TextInput
          maxLength={1}
          style={{
            borderBottomWidth: 4,
            borderBottomColor: '#000',
            flex: 0.2,
            textAlign: 'center',
            fontSize: 25,
          }}
          keyboardType="numeric"
          // onChangeText={() => {
          //   onTextChanged(4);

          // }}
        />
        <TextInput
          maxLength={1}
          style={{
            borderBottomWidth: 4,
            borderBottomColor: '#000',
            flex: 0.2,
            textAlign: 'center',
            fontSize: 25,
          }}
          keyboardType="numeric"
        />
      </View>
      <View style={{flex: 0.2}}>
        <TouchableOpacity
          style={{
            backgroundColor: 'green',
            borderRadius: 25,
            flex: 1,
            alignItems: 'center',
            justifyContent: 'center',
          }}
          onPress={() => navigation.navigate('UPI')}>
          <View>
            <Text
              style={{
                color: '#fff',
                fontSize: 25,
                fontWeight: 500,
              }}>
              Continue
            </Text>
          </View>
        </TouchableOpacity>
      </View>
    </View>
  );
}
