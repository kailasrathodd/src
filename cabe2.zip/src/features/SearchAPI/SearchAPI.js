// import {createAsyncThunk} from '@reduxjs/toolkit';
// import API from '../../../APIs/RepositoryFactory';
// export const searchParentCategoryAPI = createAsyncThunk(
//   'fetch-sg-user-details',
//   async (payload, thunkAPI) => {
//     try {
//       const response = await API.searchParentCategory();
//       if (response.data.user_detail) {
//         thunkAPI.dispatch(
//           SGAuthAction.setKUUserDetails(response.data.user_detail),
//         );
//       }
//       return response.data;
//     } catch (error) {
//       console.tron.log('fetch-sg-user-details Error: ', error);
//     }
//   },
// );
