import React, {useState} from 'react';
import {
  View,
  StyleSheet,
  Image,
  TouchableOpacity,
  StatusBar,
  Alert,
} from 'react-native';
import {
  useTheme,
  Avatar,
  Title,
  Caption,
  Paragraph,
  Drawer,
  Text,
} from 'react-native-paper';
import {DrawerContentScrollView, DrawerItem} from '@react-navigation/drawer';
import {useDispatch, useSelector} from 'react-redux';
import IconA from 'react-native-vector-icons/FontAwesome';
import Icon1 from 'react-native-vector-icons/Ionicons';
import IconP from 'react-native-vector-icons/Ionicons';
import HomeIcon from 'react-native-vector-icons/MaterialCommunityIcons';
import Icon3 from 'react-native-vector-icons/MaterialIcons';

import Sos from '../Screens/Sos';
import AddAddress from '../Screens/Address/AddAddress';
import Home from './home';
import MyProfile from '../Screens/profile/MyProfile';
import {getFontSize} from '../utility/responsive';
import AwesomeAlert from 'react-native-awesome-alerts';
import AsyncStorage from '@react-native-async-storage/async-storage';
// import {logout} from '../redux/feature/asyncReducer';

import {
  logout,
  onBoarding,
  userDetail,
  userLog,
} from '../features/auth/authAPI';
import Journey from '../Screens/journey/Journey';
import SplashScreen from '../Screens/onboarding/SplashScreen';
import Auth from './auth';
import rootReducer, {resetState, resetStore} from '../features';
import {riderLogoutAPI} from '../features/basicdetails/basicdetail';
import GetInTouchStack from '../Screens/getInTouch/GetInTouchStack';
import setVectorIcon from '../Components/VectorComponents';

function DrawerContent({navigation}, props) {
  const dispatch = useDispatch();
  // const navigation = useNavigation();
  const user_id = useSelector(state => state.auth.user?._id);
  const basicDetail = useSelector(state => state.basicDetail.basicDetail);
  const [showAlert, setShowAlert] = useState(false);

  const hideAlert = async () => {
    setShowAlert(false);
  };
  const Logout = async () => {
    dispatch(resetStore());
    await AsyncStorage.removeItem('userToken');
    navigation.navigate(Auth);
    riderLogoutAPI(user_id);
    await navigation.navigate(SplashScreen);
    setShowAlert(false);
  };
  const handleLogout = async () => {
    await AsyncStorage.removeItem('loginDetails').then(() => {
      dispatch(onBoarding(true));
    });

    // console.log('Log Out success');

    // await AsyncStorage.removeItem(root);
    // await AsyncStorage.getAllKeys().then(keys =>
    //   AsyncStorage.multiRemove(keys),
    // );

    // dispatch(logout('null'));

    Alert.alert('Alert Title', 'My Alert Msg', [
      {
        text: 'Cancel',
        onPress: () => console.log('Cancel Pressed'),
        style: 'cancel',
      },
      {
        text: 'OK',
        onPress: async () => {
          await AsyncStorage.removeItem('loginDetails').then(() => {
            dispatch(onBoarding(true));
          });
          AsyncStorage.removeItem('root');
          AsyncStorage.getAllKeys().then(keys =>
            AsyncStorage.multiRemove(keys),
          );
          AsyncStorage.clear(), navigation.navigate('Auth');
        },
      },
    ]);
  };
  return (
    <DrawerContentScrollView
      {...props}
      style={{backgroundColor: '#000055', flex: 1}}>
      <View style={{flex: 1}}>
        <View style={styles.userInfoSection}>
          <View
            style={{
              justifyContent: 'center',
              alignItems: 'center',
            }}>
            <TouchableOpacity
              style={{
                width: 100,
                height: 100,
                borderRadius: 555,

                justifyContent: 'center',
                alignSelf: 'center',
                alignItems: 'center',
              }}
              onPress={() => navigation.navigate(MyProfile)}>
              {basicDetail && basicDetail?.photo !== 'null' ? (
                <Avatar.Image
                  resizeMode="contain"
                  size={120}
                  source={{uri: basicDetail?.profile_image}}
                  // onError={({currentTarget}) => {
                  //   currentTarget.onerror = null; // prevents looping
                  //   currentTarget.source = require('../assets/img/avatar.png');
                  // }}
                  style={{
                    // backgroundColor: 'transparent',
                    alignSelf: 'center',
                    justifyContent: 'center',
                    alignContent: 'center',
                    alignItems: 'center',
                    padding: 10,

                    backgroundColor: 'gray',
                  }}
                />
              ) : (
                <Avatar.Image
                  resizeMode="contain"
                  size={120}
                  source={require('../assets/img/avatar.png')}
                  style={{
                    backgroundColor: 'transparent',
                    alignSelf: 'center',
                    justifyContent: 'center',
                    alignContent: 'center',
                    alignItems: 'center',
                  }}
                />
              )}
            </TouchableOpacity>

            <View
              style={{
                flexDirection: 'column',
                alignItems: 'center',
              }}>
              <Title
                style={{
                  fontSize: 16,
                  marginTop: '5%',
                  fontWeight: 'bold',

                  color: '#fff',
                }}>
                {basicDetail?.first_name} {basicDetail?.last_name}
              </Title>
              <View>
                <HomeIcon
                  name="star"
                  color="yellow"
                  size={25}
                  style={{marginLeft: '2%'}}>
                  {' '}
                  <Text style={{color: '#fff', fontWeight: 900, fontSize: 18}}>
                    4.5
                  </Text>
                </HomeIcon>
              </View>
              <View
                style={{
                  fontSize: 14,
                  color: '#fff',
                  lineHeight: 14,
                  flexDirection: 'row',
                  paddingHorizontal: 30,
                  paddingTop: 10,
                  backgroundColor: '#b0f2a4',
                  borderRadius: 10,
                }}>
                <Text style={{marginRight: 5}}>Total</Text>
                <Text style={{fontWeight: 900, color: '#000'}}>CO</Text>
                <Text
                  style={{
                    lineHeight: 30,
                    marginRight: 3,
                    fontWeight: 900,
                    color: '#000',
                  }}>
                  2
                </Text>
                <Text style={{marginRight: 3}}>Saved </Text>
                <Text style={{fontWeight: 900, color: '#000'}}>3.6KG</Text>
              </View>
            </View>
          </View>
        </View>
        <Drawer.Section style={styles.drawerSection}>
          <AwesomeAlert
            show={showAlert}
            showProgress={false}
            title="Logout"
            message="Are you sure? You want to logout?"
            closeOnTouchOutside={true}
            closeOnHardwareBackPress={false}
            showCancelButton={true}
            showConfirmButton={true}
            cancelText="No, cancel"
            confirmText="Yes, logout"
            confirmButtonColor="#000055"
            onCancelPressed={hideAlert}
            onConfirmPressed={Logout}
          />

          <DrawerItem
            icon={({focused, size}) => (
              <HomeIcon
                name="home-circle-outline"
                color={focused ? '#7cc' : '#000055'}
                size={32}
                style={{marginLeft: '2%'}}
              />
            )}
            label={({focused, size}) => (
              <Text
                style={{
                  color: '#000055',
                  fontSize: getFontSize(15),
                  fontWeight: 'bold',
                  textAlign: 'left',
                  alignSelf: 'flex-start',
                  textAlign: 'left',
                  alignSelf: 'flex-start',
                }}>
                Home
              </Text>
            )}
            onPress={() => {
              navigation.navigate(Home);
            }}
          />
          <DrawerItem
            icon={({focused, size}) => (
              <IconP
                name="md-person-circle-outline"
                color={focused ? '#7cc' : '#000055'}
                size={32}
                style={{marginLeft: '2%'}}
              />
            )}
            label={({focused, size}) => (
              <Text
                style={{
                  color: '#000055',
                  fontSize: getFontSize(15),
                  fontWeight: 'bold',
                  textAlign: 'left',
                  alignSelf: 'flex-start',
                  marginLeft: '1%',
                }}>
                My Profile
              </Text>
            )}
            onPress={() => {
              navigation.navigate(MyProfile);
            }}
          />
          <DrawerItem
            icon={({focused, size}) => (
              <IconP
                name="md-navigate-circle-outline"
                size={32}
                color={focused ? '#7cc' : '#000055'}
                style={{marginLeft: '2%'}}
              />
            )}
            label={({focused, size}) => (
              <Text
                style={{
                  color: '#000055',
                  fontSize: getFontSize(15),
                  fontWeight: 'bold',
                  textAlign: 'left',
                  alignSelf: 'flex-start',
                }}>
                Address
              </Text>
            )}
            onPress={() => {
              navigation.navigate(AddAddress);
            }}
          />
          <DrawerItem
            icon={({focused, size}) => (
              <Icon1
                name="car"
                color={focused ? '#7cc' : '#000'}
                size={25}
                style={{marginLeft: '2%'}}
              />
            )}
            label={({focused, size}) => (
              <Text
                style={{
                  color: '#000055',
                  fontSize: getFontSize(15),
                  fontWeight: 'bold',
                  textAlign: 'left',
                  alignSelf: 'flex-start',
                  marginLeft: '4%',
                }}>
                My Journeys
              </Text>
            )}
            onPress={() => {
              navigation.navigate(Journey);
            }}
          />
          {/* <DrawerItem
            icon={({focused, size}) => (
              <IconP
                name="md-arrow-redo-circle-outline"
                color={focused ? '#7cc' : '#000055'}
                size={35}
                style={{marginLeft: '2%'}}
              />
            )}
            label={({focused, size}) => (
              <Text
                style={{
                  color: '#000055',
                  fontSize: getFontSize(15),
                  fontWeight: 'bold',
                  textAlign: 'left',
                  alignSelf: 'flex-start',
                  marginLeft: '-2%',
                }}>
                Referral
              </Text>
            )}
            onPress={() => {
              navigation.navigate(Sos);
            }}
          /> */}
          <DrawerItem
            icon={({focused, size}) => (
              <Icon3
                name="local-offer"
                color={focused ? '#7cc' : '#000055'}
                size={25}
                style={{marginLeft: '2%'}}
              />
            )}
            label={({focused, size}) => (
              <Text
                style={{
                  color: '#000055',
                  fontSize: getFontSize(15),
                  fontWeight: 'bold',
                  textAlign: 'left',
                  alignSelf: 'flex-start',
                  marginLeft: '4%',
                }}>
                Promo Code
              </Text>
            )}
            onPress={() => {
              // navigation.navigate(PromoCode);
              navigation.navigate('Promo_Code');
            }}
          />
          <DrawerItem
            icon={({focused, size}) => (
              <Icon1
                name="notifications-circle-outline"
                color={focused ? '#7cc' : '#000'}
                size={32}
                style={{marginLeft: '2%'}}
              />
            )}
            label={({focused, size}) => (
              <Text
                style={{
                  color: '#000055',
                  fontSize: getFontSize(15),
                  fontWeight: 'bold',
                  textAlign: 'left',
                  alignSelf: 'flex-start',
                  marginLeft: '1%',
                }}>
                Notifications
              </Text>
            )}
            onPress={() => {
              navigation.navigate('Notifications');
            }}
          />
          <DrawerItem
            icon={({focused, size}) => (
              <Image
                source={require('../assets/img/finger.png')}
                style={{width: 25, height: 25, marginLeft: '1%'}}
              />
            )}
            label={({focused, size}) => (
              <Text
                style={{
                  color: '#000055',
                  fontSize: getFontSize(15),
                  fontWeight: 'bold',
                  textAlign: 'left',
                  alignSelf: 'flex-start',
                  marginLeft: '4%',
                }}>
                Get in Touch
              </Text>
            )}
            onPress={() => {
              navigation.navigate(GetInTouchStack);
            }}
          />
          <DrawerItem
            icon={({focused, size}) => (
              <Image
                source={require('../assets/img/sos.png')}
                style={{
                  width: 27,
                  height: 27,
                  marginLeft: '2%',
                }}
              />
            )}
            label={({focused, size}) => (
              <Text
                style={{
                  color: '#000055',
                  fontSize: getFontSize(15),
                  fontWeight: 'bold',
                  textAlign: 'left',
                  alignSelf: 'flex-start',
                  marginLeft: '3%',
                }}>
                Emergency SOS
              </Text>
            )}
            onPress={() => {
              navigation.navigate(Sos);
            }}
          />
          <DrawerItem
            icon={({focused, size}) => (
              <IconA
                name="sign-out"
                color={focused ? '#7cc' : '#000055'}
                size={25}
                style={{marginLeft: '2%'}}
              />
            )}
            label={({focused, size}) => (
              <Text
                style={{
                  color: '#000055',
                  fontSize: getFontSize(15),
                  fontWeight: 'bold',
                  textAlign: 'left',
                  alignSelf: 'flex-start',
                  marginLeft: '4%',
                }}>
                Log Out
              </Text>
            )}
            onPress={() => {
              // handleLogout();

              setShowAlert(true);
            }}
          />
        </Drawer.Section>
      </View>
    </DrawerContentScrollView>
  );
}

export default DrawerContent;

const styles = StyleSheet.create({
  drawerContent: {
    flex: 1,
    padding: 0,
  },
  userInfoSection: {
    padding: 20,
    backgroundColor: '#000055',
    justifyContent: 'center',
    alignItems: 'center',
    borderTopRightRadius: 15,
  },
  title: {
    fontSize: 16,
    marginTop: 3,
    fontWeight: 'bold',
    color: '#fff',
  },
  caption: {
    fontSize: 14,
    color: '#fff',
    lineHeight: 14,
    color: '#fff',
    flexDirection: 'row',
    paddingHorizontal: 20,
    paddingTop: 10,
    backgroundColor: '#b0f2a4',
    borderRadius: 10,
  },
  row: {
    marginTop: 20,
    flexDirection: 'row',
    alignItems: 'center',
  },
  section: {
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: 15,
  },
  paragraph: {
    fontWeight: 'bold',
    marginRight: 3,
  },
  drawerSection: {
    marginTop: 15,
    backgroundColor: '#f4f4f4',
  },

  preference: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 12,
    paddingHorizontal: 16,
    backgroundColor: '#f4f4f4',
  },
});
