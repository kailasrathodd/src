/* eslint-disable react-native/no-inline-styles */
/* eslint-disable no-unused-vars */
import React, {useEffect, useState} from 'react';
import {
  Image,
  Text,
  Linking,
  SafeAreaView,
  View,
  Alert,
  TouchableOpacity,
  Share,
} from 'react-native';
import BottomSheet from 'react-native-simple-bottom-sheet';
import setVectorIcon from '../../Components/VectorComponents';
import {getFontSize, getResHeight, getResWidth} from '../../utility/responsive';
import {useDispatch, useSelector} from 'react-redux';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import {getRideDetailAPI} from '../../features/CreateToRide/riderAPI';
import GetDirectionAPP from '../../Components/GetDirectionAPP';

import theme from '../../theme';

function DriverReached({navigation}, props) {
  const dispatch = useDispatch();

  const getDriver = useSelector(state => state?.rider?.getDriver);
  const Createride = useSelector(state => state.rider?.CreateRide);
  const rider = useSelector(state => state?.rider?.GetRideDetail);
  const panelRef = React.useRef(null);
  const [durData, setDurData] = useState([]);

  const handleData = data => {
    setDurData(data);
  };
  useEffect(() => {
    const interval = setInterval(() => {
      if (Createride !== null) {
        dispatch(getRideDetailAPI(Createride?._id));
      }
      if (rider) {
        switch (rider.status) {
          case 'started':
            navigation.navigate('TripDestination');
            break;
          case 'accepted':
            navigation.navigate('ShowDriver');
            break;
          // case 'arrived':
          //   navigation.navigate('DriverReached');
          //   break;
          case 'timeout':
            navigation.navigate('HomeScreen');
            break;
          // case 'rejected':
          //   navigation.navigate('HomeScreen');
          //   break;
          case 'customer_cancelled':
            navigation.navigate('HomeScreen');
            break;
          case 'ended':
            navigation.navigate('EndtoRider');
            break;
          case 'completed':
            navigation.navigate('RateDriver');
            break;
        }
      }
    }, 15000);

    return () => clearInterval(interval);
  }, [rider, dispatch, Createride, navigation]);
  const onShare = async () => {
    try {
      const result = await Share.share({
        message:
          'CAB-EEZ Infra Tech Pvt. Limited (Brand Name: “Cab-E”) is a Green-Tech Urban Mobility Marketplace and we provide,an in-house built, Mobile-based Platform.',
      });
      if (result.action === Share.sharedAction) {
        if (result.activityType) {
          // shared with activity type of result.activityType
        } else {
          // shared
        }
      } else if (result.action === Share.dismissedAction) {
        // dismissed
      }
    } catch (error) {
      Alert.alert(error.message);
    }
  };
  return (
    <SafeAreaView style={{flex: 1}}>
      <GetDirectionAPP {...props} onData={handleData} />
      <BottomSheet ref={ref => (panelRef.current = ref)} wrapperStyle={{}}>
        <View style={{flex: 1}}>
          <View
            style={{
              flexDirection: 'row',
              gap: getResWidth(20),
            }}>
            <View>
              <Image
                source={require('../../assets/img/avater.jpg')}
                style={{
                  width: getResHeight(70),
                  height: getResHeight(70),
                  resizeMode: 'contain',
                  borderRadius: 100,
                  borderWidth: 1.2,
                  borderColor: '#000',
                }}
              />

              <Text
                style={{
                  textAlign: 'center',
                  borderRadius: 4,
                  marginTop: '5%',
                }}>
                <Icon name="star" color="#F5C000" /> 4.5
              </Text>
            </View>

            <View style={{}}>
              <Text
                style={{
                  fontSize: 16,
                  color: '#000055',
                  fontWeight: 'bold',
                  marginTop: '3%',
                }}>
                {getDriver?.driver_first_name?.toUpperCase() || 'Driver Name'}
              </Text>
              <Text
                style={{
                  fontSize: getFontSize(15),
                  color: '#000055',
                  fontWeight: 500,
                  marginTop: '5%',
                }}>
                <Text
                  style={{
                    fontSize: getFontSize(15),
                    color: '#000055',
                    fontWeight: 700,
                  }}>
                  {getDriver?.driver_last_name?.toUpperCase() || 'MH01CC1234'}
                  {'   '}-{'   '}
                </Text>
                {getDriver?.vehicle_name?.toUpperCase() || 'EV City'}
              </Text>
            </View>
          </View>

          <View
            style={{
              flexDirection: 'row',
              borderWidth: 1,
              borderColor: '#000',
              borderRadius: 5,
              justifyContent: 'space-evenly',
              padding: 10,
              width: '100%',
              marginVertical: getResHeight(25),
            }}>
            <Text
              style={{
                fontSize: getFontSize(20),
                color: '#000055',
                fontWeight: 700,
                padding: 5,
                fontfamily: theme.font.bold,
                alignSelf: 'center',
              }}>
              OTP
            </Text>
            <View
              style={{
                height: '100%',
                backgroundColor: '#000',

                width: 1,
              }}
            />
            <Text
              style={{
                fontSize: getFontSize(20),

                color: '#000055',
                fontWeight: 700,
                padding: 5,

                fontfamily: theme.font.bold,
                alignSelf: 'center',
              }}>
              {getDriver?.otp || 5022}
            </Text>
          </View>
          <View
            style={{
              flexDirection: 'row',
              justifyContent: 'space-between',
              alignItems: 'center',
              marginBottom: 15,
              paddingHorizontal: 25,
            }}>
            <TouchableOpacity title="Share" onPress={onShare}>
              <Text
                style={{
                  fontSize: getFontSize(18),
                  fontWeight: 500,
                  color: '#000',
                  fontfamily: theme.font.bold,
                }}>
                {setVectorIcon({
                  type: 'Fontisto',
                  name: 'share',
                  size: getFontSize(18),
                  fontWeight: 700,

                  color: '#000',
                })}{' '}
                Share
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => Linking.openURL('tel:+919867834130')}
              style={{
                alignItems: 'center',
                justifyContent: 'center',
              }}>
              <Text
                style={{
                  fontSize: getFontSize(18),
                  fontWeight: 500,
                  color: '#000',
                  fontfamily: theme.font.bold,
                }}>
                {setVectorIcon({
                  type: 'Ionicons',
                  name: 'ios-call',
                  size: getFontSize(20),
                  color: '#000',
                })}{' '}
                Call
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </BottomSheet>
    </SafeAreaView>
  );
}
export default DriverReached;
