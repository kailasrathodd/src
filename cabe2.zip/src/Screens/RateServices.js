import React, {useState} from 'react';
import {useDispatch, useSelector} from 'react-redux';
import {
  StyleSheet,
  TouchableOpacity,
  Text,
  View,
  ScrollView,
  FlatList,
} from 'react-native';
import {Avatar} from 'react-native-paper';
import BottomSheet from 'react-native-simple-bottom-sheet';
import {Rating} from 'react-native-ratings';
import {getFontSize} from '../utility/responsive';
import LiveLoc from '../Map/LiveLoc';
import {CreateRide, GetRideDetail} from '../features/CreateToRide';

const RateServices = ({navigation}) => {
  const [selectedStars, setSelectedStars] = useState(0);

  const dispatch = useDispatch();
  const driverDetails = useSelector(state => state?.rider?.getDriver);

  function ratingCompleted(rating) {
    console.log('Rating is: ' + rating);
  }

  const fillColor = rating => {
    setSelectedStars(rating);
  };

  const renderItem = ({item}) => {
    return (
      <View style={{flex: 1}}>
        <View style={{padding: 4, backgroundColor: '#fff'}}>
          <Text
            style={{
              fontSize: 15,
              textAlign: 'left',
              color: '#000',
              fontWeight: 'bold',
              fontWeight: '600',
            }}>
            {item.label}
          </Text>
        </View>
        <View style={{padding: 4, backgroundColor: '#fff'}}>
          <Rating
            imageSize={25}
            fractions
            jumpValue={0.5}
            onFinishRating={ratingCompleted}
            style={{
              // paddingVertical: 5,
              alignContent: 'flex-start',
              alignSelf: 'flex-start',
              // margin: 4,
            }}
          />
        </View>
      </View>
    );
  };

  return (
    <View style={{flex: 1}}>
      <LiveLoc />

      <BottomSheet
        isOpen
        innerContentStyle={{flex: 1}}
        sliderMaxHeight={960}
        height={'100%'}>
        <ScrollView>
          <View>
            <View
              style={{
                borderBottomWidth: 1,
                borderColor: '#ddd',
              }}>
              <Text
                style={{
                  fontSize: 25,
                  textAlign: 'center',
                  color: '#000',
                  fontWeight: 'bold',
                  fontWeight: '600',
                  bottom: 4,
                }}>
                Rate Service
              </Text>
            </View>

            <View
              style={{
                width: '80%',
                marginVertical: 20,
              }}>
              <FlatList
                data={[
                  {id: '1', label: 'Was Your Ride Comfortable?'},
                  {id: '2', label: 'Was the Car Clean and Hygienic ?'},
                  {id: '3', label: 'Was the Cab Manager Courteous ?'},
                  {id: '4', label: 'Did you feel safe during the Trip?'},
                  {id: '5', label: 'Are Our Services a Value for Money?'},
                  {id: '6', label: 'Was it easy to get a Cab?'},
                ]}
                keyExtractor={item => item.id}
                renderItem={renderItem}
              />
            </View>
          </View>
          <View
            style={{
              flexDirection: 'row',
              justifyContent: 'space-evenly',
              padding: 5,
            }}>
            <TouchableOpacity
              style={{
                backgroundColor: 'red',

                borderRadius: 10,

                width: '45%',

                justifyContent: 'center',
                height: 50,
              }}
              onPress={() => {
                dispatch(GetRideDetail(null));
                dispatch(CreateRide(null));
                navigation.navigate('HomeScreen');
              }}>
              <Text
                style={{
                  color: '#fff',

                  alignItems: 'center',
                  textAlign: 'center',
                }}>
                Cancel
              </Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={{
                backgroundColor: '#000055',
                alignItems: 'center',
                borderRadius: 10,
                width: '45%',
                padding: 5,
                height: 50,
                justifyContent: 'center',
              }}
              onPress={() => {
                dispatch(GetRideDetail(null));
                dispatch(CreateRide(null));
                navigation.navigate('HomeScreen');
              }}>
              <Text
                style={{
                  color: '#fff',

                  alignItems: 'center',
                  textAlign: 'center',
                }}>
                Submit
              </Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </BottomSheet>
    </View>
  );
};

export default RateServices;
