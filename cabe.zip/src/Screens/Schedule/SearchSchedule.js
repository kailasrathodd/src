import React, {useState} from 'react';
import {View, Text, TouchableOpacity, StyleSheet} from 'react-native';
import {useDispatch, useSelector} from 'react-redux';
import Header from '../../Components/HeaderComp';
import MapplsPlacePicker from '../Map/MapplsPlacePicker';
import {
  RideUpdateAPI,
  eLocPick,
  getBasicDetailsAPI,
} from '../../features/basicdetails/basicdetail';
import MapplsUIWidgets from 'mappls-search-widgets-react-native';
import setVectorIcon from '../../Components/VectorComponents';
import {resetPin, typeLocation} from '../../features/location/location';
import {getFontSize} from '../../utility/responsive';

const SearchSchedule = ({navigation}) => {
  const dispatch = useDispatch();
  const rider_id = useSelector(state => state.auth.user?._id);

  const [location, setLocation] = useState({
    placeName: '',
    placeAddress: '',
    mapplsPin: '',
  });

  const riderUpdate = useSelector(
    state => state.basicDetail?.riderUpdate?.Rider_Data,
  );

  async function searchLoc() {
    try {
      const res = await MapplsUIWidgets.searchWidget({
        toolbarColor: '#ffffff',
        bridge: true,
      });
      setLocation(res?.eLocation);

      const {mapplsPin} = location;
      dispatch(eLocPick(mapplsPin))
        .then(data => {
          if (data.payload.status === 200) {
            rideUpdate(data.payload.data.latitude, data.payload.data.longitude);
            dispatch(
              RideUpdateAPI({
                pickup_latitude: data.payload.data.latitude,
                pickup_longitude: data.payload.data.longitude,
                rider_id: rider_id,
                pickup_address: getAddress(),
                pickup_details: location,
              }),
            );
          }
        })
        .catch(error => {
          console.error(error);
        });

      console.log(res);
    } catch (e) {
      console.log(e);
    }
  }

  const rideUpdate = (latitude, longitude) => {
    dispatch(
      RideUpdateAPI({
        pickup_latitude: latitude,
        pickup_longitude: longitude,
        rider_id: rider_id,
        pickup_address: getAddress(),
        pickup_details: location,
      }),
    )
      .then(data => {
        if (data.payload.status === 200) {
          dispatch(
            getBasicDetailsAPI({
              rider_id: rider_id,
            }),
          );

          if (riderUpdate && riderUpdate?.pickup_address !== null) {
            navigation.navigate('SearchSchedule');
          } else {
            navigateToHomeScreen();
          }
        }
      })
      .catch(error => {
        console.error(error);
      });
  };

  const getAddress = () => {
    return `${location.placeName} ${location.placeAddress}`;
  };

  return (
    <View style={styles.container}>
      <View style={{width: '100%', height: '100%'}}>
        <MapplsPlacePicker />
      </View>

      <View style={styles.headerContainer}>
        <Header
          containerStyle={styles.header}
          title={''}
          backPress={() => {
            navigation.navigate('HomeScreen');
          }}
          // {...this.props}
        />
      </View>

      <View style={styles.locationContainer}>
        <View style={styles.locationBox}>
          <Text style={styles.locationLabel}>
            {setVectorIcon({
              type: 'Entypo',
              name: 'controller-record',
              size: getFontSize(15),
              color: '#000',
            })}{' '}
            Pickup Location
          </Text>
          <View style={styles.locationInputContainer}>
            <TouchableOpacity
              style={styles.locationInput}
              onPress={() => {
                dispatch(resetPin(true));
                dispatch(typeLocation('PickUp'));
                searchLoc();
              }}>
              <Text style={styles.locationContainer}>
                {riderUpdate?.pickup_address || 'Enter Your Pickup Location'}
              </Text>
            </TouchableOpacity>
          </View>
        </View>

        <View style={styles.locationBox}>
          <Text style={styles.locationLabel}>
            {setVectorIcon({
              type: 'Entypo',
              name: 'controller-record',
              size: getFontSize(15),
              color: '#000',
            })}{' '}
            Drop Location
          </Text>
          <View style={styles.locationInputContainer}>
            <TouchableOpacity
              style={styles.locationInput}
              onPress={() => {
                dispatch(resetPin(true));
                dispatch(typeLocation('Drop'));
                navigation.navigate('DropSchedule');
              }}>
              <Text style={styles.locationContainer}>
                Enter Your Drop Location
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    position: 'relative',
    height: '100%',
  },
  headerContainer: {
    zIndex: 1,
    position: 'absolute',
    width: '100%',
    paddingHorizontal: 20,
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  header: {
    width: '100%',
    alignSelf: 'center',
  },
  locationContainer: {
    paddingHorizontal: 20,
    paddingVertical: 20,
    backgroundColor: '#fFf',
    borderRadius: 20,
    width: '90%',
    margin: 20,
    top: '10%',
    zIndex: 1,
    position: 'absolute',
  },
  locationBox: {
    color: '#ddd',
    backgroundColor: '#fff',
    justifyContent: 'space-between',
  },
  locationLabel: {
    fontSize: getFontSize(14),
    fontWeight: '600',
    color: '#ddd',
    paddingLeft: 1,
    borderRadius: 50,
    backgroundColor: '#fff',
    flexDirection: 'row',
    justifyContent: 'center',
    margin: 1,
  },
  locationInputContainer: {
    borderColor: '#ddd',
    borderBottomWidth: 0.21,
    width: '100%',
    textAlign: 'left',
    fontSize: getFontSize(14),
    padding: 10,
  },
  locationInput: {
    color: '#000',
    opacity: 0.51,
    width: '100%',
  },
});

export default SearchSchedule;
