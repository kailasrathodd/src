import React, {useState, useEffect} from 'react';
import {View, TextInput} from 'react-native';
import Geolocation from '@react-native-community/geolocation';

const LocationInput = () => {
  const [currentLocation, setCurrentLocation] = useState(null);

  useEffect(() => {
    // Get the current location
    Geolocation.getCurrentPosition(
      position => {
        const {latitude, longitude} = position.coords;
        setCurrentLocation(`${latitude}, ${longitude}`);
      },
      error => console.log(error),
      {enableHighAccuracy: true, timeout: 20000, maximumAge: 1000},
    );
  }, []);

  return (
    <View>
      <TextInput
        value={currentLocation}
        onChangeText={setCurrentLocation}
        placeholder="Enter your location"
      />
    </View>
  );
};

export default LocationInput;
