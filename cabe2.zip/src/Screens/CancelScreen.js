import {
  StyleSheet,
  Text,
  View,
  Button,
  Image,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Pressable,
  Modal,
  Alert,
} from 'react-native';
import {Checkbox} from 'react-native-paper';
import React from 'react';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import Icon2 from 'react-native-vector-icons/Ionicons';

function CancelScreen() {
  const [checked, setChecked] = React.useState(false);
  const [checked2, setChecked2] = React.useState(false);
  const [checked3, setChecked3] = React.useState(false);
  const [checked4, setChecked4] = React.useState(false);
  const [checked5, setChecked5] = React.useState(false);
  const [value, onChangeText] = React.useState('');
  const [show, setShow] = React.useState(false);
  const [showBtn, setShowBtn] = React.useState(false);

  if (
    checked4 == true ||
    checked2 == true ||
    checked3 == true ||
    checked == true
  ) {
    setShowBtn(true);
  }

  function setChecked5fun() {
    setChecked5(!checked5);
    setShow(!show);
    if (
      checked4 == true ||
      checked2 == true ||
      checked3 == true ||
      checked == true
    ) {
      setChecked4(false);
      setChecked2(false);
      setChecked3(false);
      setChecked(false);
    }
  }

  const [modalVisible, setModalVisible] = React.useState(false);
  return (
    <>
      <Modal
        animationType="slide"
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => {
          Alert.alert('Modal has been closed.');
          setModalVisible(!modalVisible);
        }}>
        <View style={styles.centeredView}>
          <View style={styles.modalView}>
            <Image
              style={{width: '60%', height: '60%'}}
              source={require('../../src/assets/img/sad.png')}
            />
            <Text style={styles.modalText}>
              We are so sad About your cancellation
            </Text>
            <Text style={styles.modalText}>
              We Will Continue to improve our service & satisfy you on the next
              trip
            </Text>
            <Pressable
              style={[styles.button, styles.buttonClose]}
              onPress={() => setModalVisible(!modalVisible)}>
              <Text style={styles.textStyle}>Ok</Text>
            </Pressable>
          </View>
        </View>
      </Modal>

      <View
        style={{
          opacity: !modalVisible ? 1 : 0.5,
          backgroundColor: !modalVisible ? '#fff' : '#000000f0',
        }}>
        <View
          style={{
            // backgroundColor: modalVisible ? 'red' : '#000',

            justifyContent: 'center',
            alignItems: 'center',
            padding: 10,
            margin: 10,
          }}>
          <Text style={{fontSize: 20}}>
            Please select the Reasons for cancellation
          </Text>
        </View>
        <View style={styles.maincancelsection}>
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              gap: 15,
            }}>
            <Checkbox
              color="red"
              status={checked ? 'checked' : 'unchecked'}
              onPress={() => {
                setChecked(!checked);
              }}
            />
            <Text style={styles.textforcancel}>Waiting for long time</Text>
          </View>
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              gap: 15,
            }}>
            <Checkbox
              color="red"
              status={checked2 ? 'checked' : 'unchecked'}
              onPress={() => {
                setChecked2(!checked2);
              }}
            />
            <Text style={styles.textforcancel}>Waiting for long time</Text>
          </View>
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              gap: 15,
            }}>
            <Checkbox
              status={checked3 ? 'checked' : 'unchecked'}
              color="red"
              onPress={() => {
                setChecked3(!checked3);
              }}
            />
            <Text style={styles.textforcancel}>Waiting for long time</Text>
          </View>
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              gap: 15,
            }}>
            <Checkbox
              color="red"
              status={checked4 ? 'checked' : 'unchecked'}
              onPress={() => {
                setChecked4(!checked4);
              }}
            />
            <Text style={styles.textforcancel}>Waiting for long time</Text>
          </View>
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              gap: 15,
            }}>
            <Checkbox
              color="red"
              status={checked5 ? 'checked' : 'unchecked'}
              onPress={() => {
                setChecked5fun();
              }}
            />
            <Text style={styles.textforcancel}>Other Reasons </Text>
          </View>
          <View>
            {show ? (
              <View
                style={{
                  margin: 12,
                  backgroundColor: '#ddd',
                  borderRadius: 20,
                }}>
                <TextInput
                  style={{
                    backgroundColor: '#fff',
                    margin: 2,
                    borderRadius: 20,
                  }}
                  editable
                  multiline
                  numberOfLines={4}
                  maxLength={40}
                  onChangeText={text => onChangeText(text)}
                  value={value}
                />
              </View>
            ) : null}
          </View>
        </View>
        <View>
          <Pressable
            disabled={showBtn == true ? true : false}
            onPress={() => setModalVisible(true)}
            style={{
              alignItems: 'center',
              width: '100%',
              margin: 10,
              justifyContent: 'center',
            }}>
            <Text
              style={{
                backgroundColor: '#000055',
                width: '90%',
                padding: 20,
                textAlign: 'center',
                fontSize: 25,
                padding: 10,
                borderRadius: 20,
                color: '#fff',
              }}>
              Submit
            </Text>
          </Pressable>
        </View>
      </View>
    </>
  );
}

export default CancelScreen;

const styles = StyleSheet.create({
  textforcancel: {
    fontSize: 18,
  },
  maincancelsection: {
    padding: 20,
  },
  centeredView: {
    flex: 1,
    width: '100%',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 22,
  },
  modalView: {
    margin: 20,
    backgroundColor: 'white',
    borderRadius: 20,
    padding: 35,
    width: '90%',
    height: 400,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  button: {
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 10,
    width: 200,
    elevation: 2,
  },
  buttonOpen: {
    backgroundColor: '#F194FF',
  },
  buttonClose: {
    backgroundColor: '#000055',
  },
  textStyle: {
    color: 'white',
    fontSize: 20,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  modalText: {
    fontSize: 18,
    color: '#000',
    fontWeight: 800,
    marginBottom: 15,
    textAlign: 'center',
  },
});
