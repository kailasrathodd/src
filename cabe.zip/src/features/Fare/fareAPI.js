import {createAsyncThunk} from '@reduxjs/toolkit';
import API from '../../APIs/RepositoryFactory';
import * as fare from './index';

export const fareAPI = createAsyncThunk(
  'fareAPI/fareAPI',
  async (payload, thunkAPI) => {
    try {
      const response = await API.fareRepository.fareAPI(payload);
      console.tron.log(response.data.status);
      if (response.data.status == 200) {
        thunkAPI.dispatch(fare.ridefare(response.data));
      }
      return response.data;
    } catch (error) {
      console.tron.log('eLocDrop: ', error);
    }
  },
);
