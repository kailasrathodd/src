import React, {useState, useEffect} from 'react';
import {Platform, View, PermissionsAndroid} from 'react-native';
import MapplsGL from 'mappls-map-react-native';
import RNAndroidLocationEnabler from 'react-native-android-location-enabler';
import {Button, Icon} from 'react-native-elements';
import * as Permissions from 'react-native-permissions';
import {
  updateLocation,
  AddressPin,
  CurrentLocation,
} from '../../features/location/location';
import {connect} from 'react-redux';
import {DEFAULT_CENTER_COORDINATE} from '../../utils';
import {useDispatch, useSelector} from 'react-redux';
const LiveLocation = ({updateLocation, navigation}, props) => {
  const [gpsState, setGpsState] = useState(false);
  const dispatch = useDispatch();
  const [location, setLocation] = useState([]);
  const [latitude, setLatitude] = useState(null);
  const [longitude, setLongitude] = useState(null);
  const [markerLat, setMarkerLat] = useState('');
  const [markerLng, setMarkerLng] = useState('');
  const [label, setLabel] = useState('');
  const basicDetail = useSelector(state => state?.location?.CurrentLocation);
  const [clusterData, setClusterData] = useState({
    type: 'FeatureCollection',
    features: [
      {
        type: 'Feature',
        properties: {
          id: 1,
          title: 'M 2.3 - 1 km SSE of Magas Arriba, Puerto Rico',
        },
        geometry: {
          type: 'Point',
          coordinates: [72.84683679, 19.20037098],
        },
      },
      {
        type: 'Feature',
        properties: {
          id: 2,
          title: 'M 2.3 - 1 km SSE of Magas Arriba, Puerto Rico',
        },
        geometry: {
          type: 'Point',
          coordinates: [72.846158319, 19.209555037098],
        },
      },
      {
        type: 'Feature',
        properties: {
          id: 3,
          title: 'M 2.3 - 1 km SSE of Magas Arriba, Puerto Rico',
        },
        geometry: {
          type: 'Point',
          coordinates: [72.843158319, 19.20555037098],
        },
      },
    ],
  });

  useEffect(() => {
    MapplsGL.locationManager.start();

    return () => {
      MapplsGL.locationManager.stop();
    };
  }, []);

  const onUpdate = location => {
    const {latitude, longitude, accuracy} = location.coords;
    setLatitude(latitude);
    setLongitude(longitude);
    updateLocation({latitude, longitude});
    revGeoCodeApi(latitude, longitude);
    // console.log('latitude=============>', latitude, longitude);
    dispatch(CurrentLocation({latitude, longitude}));
    camera.zoomTo(12, 1000);
    camera.flyTo([longitude, latitude]);
  };

  const requestLocationPermission = async () => {
    if (Platform.OS === 'ios') {
      const {status} = await Permissions.request(
        Permissions.PERMISSIONS.IOS.LOCATION_WHEN_IN_USE,
      );
      return status;
    } else {
      const granted = await PermissionsAndroid.request(
        PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
        {
          title: 'Location Permission',
          message: 'CabeApp needs access to your location.',
          buttonNeutral: 'Ask Me Later',
          buttonNegative: 'Cancel',
          buttonPositive: 'OK',
        },
      );
      if (granted === PermissionsAndroid.RESULTS.GRANTED) {
        return 'granted';
      } else {
        return 'denied';
      }
    }
  };

  const onMarkerClick = e => {
    const f = e.features;
    console.log(JSON.stringify(f));
    camera.setCamera();

    if (!f.properties.cluster) {
      console.log('marker click ' + JSON.stringify(f));
      console.log('markerID: ' + f.properties.id);
    } else {
      console.log(f);
      camera.setCamera({
        zoomLevel: 10,
        animationDuration: 1000,
        centerCoordinate: [
          f.geometry.coordinates[0],
          f.geometry.coordinates[1],
        ],
      });
    }
  };

  const revGeoCodeApi = (lat, lng) => {
    MapplsGL.RestApi.reverseGeocode({latitude: lat, longitude: lng})
      .then(data => {
        data.results[0].formatted_address,
          dispatch(CurrentLocation({latitude, longitude, location}));
        setLabel(data.results[0].formatted_address);
      })
      .catch(error => {
        console.tron.log('fail: ' + error.message);
      });
  };

  const onPressLocationButton = () => {
    requestLocationPermission().then(status => {
      if (status === 'granted') {
        camera.zoomTo(15);
      } else {
        camera.zoomTo(18);
      }
    });
  };

  const onPress = event => {
    const {geometry, properties} = event;
    let longitude = geometry.coordinates[0];
    let latitude = geometry.coordinates[1];
    setLocation([longitude, latitude]);
    dispatch(CurrentLocation([longitude, latitude]));

    setMarkerLat(parseFloat(latitude));
    setMarkerLng(parseFloat(longitude));

    try {
      revGeoCodeApi(latitude, longitude);
    } catch (e) {}
  };

  const onFloatingButtonClick = () => {
    if (Platform.OS === 'android') {
      RNAndroidLocationEnabler.promptForEnableLocationIfNeeded({
        interval: 1000,
        fastInterval: 5000,
      })
        .then(data => {
          setGpsState(true);
        })
        .catch(err => {
          console.log('Please enable gps.');
        });
    } else {
      setGpsState(true);
    }
  };

  const handle = () => {
    const pick_up_latitude = latitude;
    const pick_up_longitude = longitude;
    const rider_id = '64144639e23c000031001e47';

    fetch('http://192.168.0.22:8000/api/riderNearbyFindDriverLocation', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({pick_up_latitude, pick_up_longitude, rider_id}),
    })
      .then(response => response.json())
      .then(data => console.log(data))
      .catch(error => setError(error));
  };

  const markerComponent =
    markerLat !== '' && markerLng !== '' ? (
      <MapplsGL.PointAnnotation
        id="markerId"
        title="Marker"
        coordinate={[markerLng, markerLat]}>
        <MapplsGL.Callout title={label} />
      </MapplsGL.PointAnnotation>
    ) : null;

  return (
    <View style={{flex: 1}}>
      <MapplsGL.MapView
        ref={r => (this.map = r)}
        style={{flex: 1}}
        onPress={event => {
          onPress(event);
        }}>
        <MapplsGL.Camera
          ref={c => (camera = c)}
          zoomLevel={13}
          animationMode="flyTo"
          centerCoordinate={DEFAULT_CENTER_COORDINATE}
        />
        {gpsState && (
          <MapplsGL.UserLocation
            animated={true}
            visible={true}
            onUpdate={location => onUpdate(location)}
          />
        )}
        <MapplsGL.ShapeSource
          id="earthquakes"
          shape={clusterData}
          onPress={e => onMarkerClick(e)}>
          <MapplsGL.CircleLayer
            id="clusteredPoints"
            belowLayerID="pointCount"
            filter={['has', 'point_count']}
            style={layerStyles.clusteredPoints}
          />
          <MapplsGL.SymbolLayer
            id="singlePoint"
            filter={['!', ['has', 'point_count']]}
            style={layerStyles.singlePoint}
          />
        </MapplsGL.ShapeSource>
      </MapplsGL.MapView>
      <View
        style={{
          width: 50,
          height: 50,
          backgroundColor: 'transparent',
          position: 'absolute',
          top: '80%',
          left: '80%',
          zIndex: 10,
        }}>
        {/* <Button
          icon={<Icon name="my-location" size={35} color="white" />}
          onPress={() => {
            onFloatingButtonClick();
            onPressLocationButton();
            // handle();
          }}
        /> */}
      </View>
    </View>
  );
};

const mapDispatchToProps = {
  updateLocation,
  AddressPin,
};

export default connect(null, mapDispatchToProps)(LiveLocation);

const layerStyles = {
  singlePoint: {
    iconAllowOverlap: true,
    iconSize: 0.05,
    iconAnchor: 'bottom',
    iconPitchAlignment: 'map',
  },

  clusteredPoints: {
    circlePitchAlignment: 'map',

    circleColor: [
      'step',
      ['get', 'point_count'],
      '#51bbd6',
      100,
      '#f1f075',
      750,
      '#f28cb1',
    ],

    circleRadius: ['step', ['get', 'point_count'], 20, 100, 30, 750, 40],

    circleOpacity: 0.84,
    circleStrokeWidth: 2,
    circleStrokeColor: 'white',
  },

  clusterCount: {
    textField: '{point_count}',
    textSize: 12,
    textPitchAlignment: 'map',
  },
};
