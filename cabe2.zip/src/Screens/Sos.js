import ButtonComponent from '../Components/ButtonComponent';
import Header from '../Components/HeaderComp';

import React, {useEffect, useState} from 'react';
import {
  Button,
  View,
  TextInput,
  Text,
  StyleSheet,
  SafeAreaView,
  Alert,
} from 'react-native';
import {ActivityIndicator} from 'react-native';
import {getResHeight} from '../utility/responsive';
import {useDispatch, useSelector} from 'react-redux';
import {sosAPI} from '../features/sos/sosAPI';
import theme from '../theme';

function Sos({navigation}, props) {
  const dispatch = useDispatch();
  const rider_id = useSelector(state => state.auth.user?._id);
  const sos = useSelector(state => state.sos?.sos);
  const [addState, setAddState] = useState(false);
  const [isSelected, setSelection] = useState(false);
  const [mobileValidError, setMobileValidError] = useState('');
  const [disableButton, setDisableButton] = useState(true);
  const [isVerifyLoading, setIsVerifyLoading] = useState(null);
  const [emergency_no_1, setEmergency_no_1] = useState(
    (sos && sos?.emergency_no_2) || '',
  );
  const [emergency_no_2, setEmergency_no_2] = useState(
    (sos && sos?.emergency_no_2) || '',
  );
  const [emergency_no_3, setEmergency_no_3] = useState(
    (sos && sos?.emergency_no_3) || '',
  );
  console.log(sos?.emergency_no_3);
  const handleAdd = () => {
    setAddState(true);
  };
  useEffect(() => {
    dispatch(sosAPI({rider_id: rider_id}));
  }, []);
  const handleSubmit = () => {
    setIsVerifyLoading(true);

    const payload = {
      rider_id: rider_id,
      emergency_no_1: emergency_no_1,
      emergency_no_2: emergency_no_2,
      emergency_no_3: emergency_no_3,
    };

    dispatch(sosAPI(payload))
      .then(data => {
        if (data.payload.status === 200) {
          navigation.navigate('HomeScreen');
          setIsVerifyLoading(false);
          Alert.alert('SOS Details Updated');
        }
      })
      .catch(error => {
        setIsVerifyLoading(false);
        console.error(error);
        Alert.alert('Something went wrong. Please try again.');
      });
  };

  const handleValidMobile = val => {
    let reg = /^[0]?[6789]\d{9}$/;
    setDisableButton(false);
    setSelection(false);

    if (val.length === 0) {
      setMobileValidError('Mobile Number must be entered!');
    } else if (val.length < 10) {
      setMobileValidError('Mobile Number must be 10 digits!');
    } else if (val.length === 10 && reg.test(val) === false) {
      setMobileValidError('Invalid Mobile Number!');
    } else if (reg.test(val) === true) {
      setMobileValidError('');
    }
  };

  return (
    <SafeAreaView style={{flex: 1, backgroundColor: '#fff'}}>
      <Header
        containerStyle={{
          alignSelf: 'center',
          backgroundColor: '#fff',
        }}
        title={'SOS'}
        backPress={() => {
          navigation.navigate('Home');
        }}
        {...props}
      />

      <Text style={styles.textLabel}>Emergency Number 1</Text>
      <TextInput
        placeholder={sos?.emergency_no_1 || 'Number'}
        style={styles.textFeild}
        text={emergency_no_1}
        keyboardType="numeric"
        maxLength={10}
        onChangeText={text => {
          setEmergency_no_1(text);
          handleValidMobile(text);
        }}
        editable={addState}
        selectTextOnFocus={false}
      />

      <Text style={styles.textLabel}>Emergency Number 2</Text>
      <TextInput
        placeholder={sos?.emergency_no_3 || 'Number'}
        style={styles.textFeild}
        text={emergency_no_2}
        keyboardType="numeric"
        maxLength={10}
        onChangeText={text => {
          setEmergency_no_2(text);
          handleValidMobile(text);
        }}
        editable={addState}
        selectTextOnFocus={false}
      />

      <Text style={styles.textLabel}>Emergency Number 3</Text>
      <TextInput
        placeholder={sos?.emergency_no_3 || 'Number'}
        style={styles.textFeild}
        text={emergency_no_3}
        keyboardType="numeric"
        maxLength={10}
        onChangeText={text => {
          setEmergency_no_3(text);
          handleValidMobile(text);
        }}
        editable={addState}
        selectTextOnFocus={false}
      />

      {mobileValidError ? (
        <Text
          style={{
            color: '#f00',
            justifyContent: 'flex-start',
            paddingLeft: 10,
            marginTop: '5%',
          }}>
          {mobileValidError}
        </Text>
      ) : null}

      {isVerifyLoading ? (
        <ActivityIndicator color={theme.color.primary} size={35} />
      ) : (
        <>
          {addState ? (
            <ButtonComponent
              buttonText="SAVE"
              textColor="#ffffff"
              textFontSize={20}
              style={{
                backgroundColor: disableButton ? '#ddd' : '#000055',
                width: '90%',
                alignItems: 'center',
                alignSelf: 'center',
                height: getResHeight(40),
                justifyContent: 'center',
                borderRadius: 25,
                marginTop: '38%',
              }}
              disabled={disableButton}
              onPress={() => {
                handleSubmit();
                setAddState(false);
              }}
            />
          ) : (
            <ButtonComponent
              buttonText="EDIT"
              textColor="#ffffff"
              textFontSize={20}
              style={styles.startButton}
              onPress={() => {
                handleAdd();
              }}
            />
          )}
        </>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  textLabel: {
    fontSize: 20,
    fontWeight: '500',
    color: '#000',
    width: '90%',
    marginTop: '4%',
    alignSelf: 'center',
  },
  textFeild: {
    borderColor: '#000',
    height: getResHeight(50),
    borderWidth: 1,
    fontSize: 20,
    width: '90%',
    paddingLeft: 20,
    marginTop: '3%',
    borderRadius: 10,
    marginBottom: '3%',
    alignSelf: 'center',
  },
  startButton: {
    backgroundColor: '#000052',
    width: '90%',
    alignItems: 'center',
    alignSelf: 'center',
    height: getResHeight(40),
    justifyContent: 'center',
    borderRadius: 25,
    marginTop: '38%',
  },
});

export default Sos;
