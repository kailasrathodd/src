import axios from 'axios';
import {
  BASE_URL,
  APP_BASE_URL,
  HEADERS_MAPPLE,
  MapplsGL_URL,
  Image_Header,
  UAT_URL,
  HEADERS,
} from '../config/constants';
import {gettoken} from '../config/session';
import {store} from '../store';

//-------------------------- APP Repository ------------------------------------//

export const RepositoryAuth = axios.create({
  baseURL: UAT_URL,
});
export const Repository = axios.create({
  baseURL: BASE_URL,
  // headers: HEADERS,
});
export const M_Repository = axios.create({
  baseURL: UAT_URL,
});
export const Image_Repository = axios.create({
  baseURL: BASE_URL,
  headers: Image_Header,
});
export const Mapple_Repository = axios.create({
  baseURL: MapplsGL_URL,
  headers: HEADERS_MAPPLE,
});
export const SecureRepository = axios.create({
  baseURL: BASE_URL,
  headers: {
    'community-name': 'cabe',
    authorization: '',
  },
});

SecureRepository.interceptors.request.use(
  async config => {
    const token = gettoken();

    if (token) {
      config.headers.authorization = `Bearer ${token}`;
    } else {
      delete SecureRepository.defaults.authorization.common.Authorization;
    }
    return config;
  },

  error => Promise.reject(error),
);

export const DeleteRepository = axios.create({
  baseURL: BASE_URL,
  headers: {
    'community-name': 'cabe',
    authorization: '',
  },
});
//-------------------------- APP Fetch Method Repository ------------------------------------//
export const Fetch_Repository = async (url, data, method = 'POST') => {
  const result = await fetch(`${BASE_URL + url}`, {
    method: method,
    body: data,
    headers: {
      'community-name': 'cabe',
      accept: 'application/json, text/plain, */*',
      // 'content-type': 'application/json',
    },
    redirect: 'follow',
  });
  const res = await result.json();
  return res;
};

//-------------------------- cabe Repository ------------------------------------//
export const APP_Repository = axios.create({
  baseURL: APP_BASE_URL,
});

export const CABE_SecureRepository = axios.create({
  baseURL: APP_BASE_URL,
  headers: {
    AuthorizationToken: '',
  },
});

//-------------------------- cabe Secure Repository ------------------------------------//

CABE_SecureRepository.interceptors.request.use(
  async config => {
    const token = gettoken();

    if (token) {
      config.headers.AuthorizationToken = `${token}`;
    } else {
      delete CABE_SecureRepository.defaults.AuthorizationToken.common
        .Authorization;
    }
    return config;
  },

  error => Promise.reject(error),
);
DeleteRepository.interceptors.request.use(
  async config => {
    const token = gettoken();
    if (token) {
      config.headers.authorization = `Bearer ${token}`;
    } else {
      delete DeleteRepository.defaults.authorization.common.authorization;
    }
    return config;
  },
  error => Promise.reject(error),
);

// =---------------------------------CG Clone---------------------------------------
export const getuserToken = () => {
  try {
    let redxData = store.getState().auth;
    return `${redxData.token}`;
  } catch (error) {
    console.tron.log('error', error);
  }
  return '';
};

export const authToken = () => {
  return axios.create({
    baseURL: BASE_URL,
  });
};
