import React, {useEffect, useState} from 'react';
import {
  StyleSheet,
  Text,
  View,
  Image,
  Modal,
  Pressable,
  Share,
  Linking,
  ScrollView,
} from 'react-native';
import {Avatar} from 'react-native-paper';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import {TouchableOpacity} from 'react-native-gesture-handler';
import {useSelector, useDispatch} from 'react-redux';
import BottomSheet from 'react-native-simple-bottom-sheet';

import {getRideDetailAPI} from '../features/CreateToRide/riderAPI';
import GetDirectionAPP from '../Components/GetDirectionAPP';

const TripDestination = ({navigation}) => {
  const [modalVisible, setModalVisible] = useState(false);
  const dispatch = useDispatch();
  const getDriver = useSelector(state => state?.rider?.getDriver);
  const rider = useSelector(state => state?.rider?.GetRideDetail);
  const Createride = useSelector(state => state.rider?.CreateRide);

  useEffect(() => {
    const interval = setInterval(() => {
      if (Createride) {
        dispatch(getRideDetailAPI(Createride?._id));
      }

      if (rider) {
        switch (rider.status) {
          case 'customer_cancelled':
            navigation.navigate('HomeScreen');
            break;
          case 'ended':
            navigation.navigate('EndtoRider');
            break;
          case 'completed':
            navigation.navigate('RateDriver');
            break;
        }
      }
    }, 5000);

    return () => clearInterval(interval);
  }, [rider, Createride, dispatch, navigation]);

  const dialCall = number => {
    const phoneNumber =
      Platform.OS === 'android' ? `tel:${number}` : `telprompt:${number}`;
    Linking.openURL(phoneNumber);
  };

  const onShare = async () => {
    try {
      await Share.share({
        message:
          'React Native | A framework for building native apps using React',
      });
    } catch (error) {
      console.error('Error sharing:', error.message);
    }
  };

  return (
    <>
      <Modal
        animationType="slide"
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => setModalVisible(false)}>
        <View style={styles.centeredView}>
          <View style={styles.modalView}>
            <Image
              style={{width: '60%', height: '60%'}}
              source={require('../../src/assets/img/sad.png')}
            />
            <Text style={styles.modalText}>
              We are so sad About your cancellation
            </Text>
            <Text style={styles.modalText}>
              We Will Continue to improve our service & satisfy you on the next
              trip
            </Text>
            <Pressable
              style={[styles.button, styles.buttonClose]}
              onPress={() => setModalVisible(false)}>
              <Text style={styles.textStyle}>Ok</Text>
            </Pressable>
          </View>
        </View>
      </Modal>

      <View>
        <View style={{width: '100%', height: '100%'}}>
          <GetDirectionAPP />
        </View>
        <View style={{flex: 1, zIndex: 55}}>
          <BottomSheet isOpen innerContentStyle={{height: '100%'}}>
            {onScrollEndDrag => (
              <ScrollView onScrollEndDrag={onScrollEndDrag}>
                <View>
                  <View style={styles.model_section}>
                    <View
                      style={{
                        flexDirection: 'row',
                        justifyContent: 'space-between',
                        width: '100%',
                      }}>
                      <View style={{marginHorizontal: 18}}>
                        <Avatar.Image
                          size={65}
                          source={require('../assets/img/avater.jpg')}
                        />
                        <TouchableOpacity style={{justifyContent: 'center'}}>
                          <Text
                            style={{
                              textAlign: 'center',
                              backgroundColor: '#fff',
                              borderRadius: 4,
                            }}>
                            <Icon name="star" color="#F5C000" /> 4.5
                          </Text>
                        </TouchableOpacity>
                      </View>
                      <View
                        style={{
                          flexDirection: 'row',
                          justifyContent: 'space-evenly',
                          backgroundColor: '#fff',
                          width: '80%',
                        }}>
                        <View style={{marginTop: '2%', width: '50%'}}>
                          <Text style={styles.driverName}>
                            {`${
                              getDriver?.driver_first_name || 'Driver Name'
                            } ${
                              getDriver?.driver_last_name || ''
                            }`.toUpperCase()}
                          </Text>
                          <Text style={styles.vehicleDetails}>
                            {getDriver?.vehicle_name?.toUpperCase() ||
                              'EV City'}
                          </Text>
                          <Text style={styles.vehicleDetails}>
                            {getDriver?.drive_car_no?.toUpperCase() ||
                              '_ _ _ _'}
                          </Text>
                        </View>
                        <View
                          style={{
                            justifyContent: 'center',
                            alignContent: 'center',
                            width: '50%',
                          }}>
                          <Text style={styles.estFareText}>Est. Fare</Text>
                          <Text style={styles.estFareAmount}>{`₹ ${
                            rider?.ride_amount || '_ _ _ _'
                          }`}</Text>
                        </View>
                      </View>
                    </View>
                  </View>
                </View>
                <View
                  style={{
                    flexDirection: 'row',
                    bottom: 10,
                    justifyContent: 'space-evenly',
                    width: '100%',
                  }}>
                  <TouchableOpacity
                    style={styles.shareButton}
                    onPress={onShare}>
                    <Image
                      source={require('../assets/img/Share.png')}
                      style={styles.shareIcon}
                    />
                    <Text style={styles.shareText}>Share</Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    style={styles.callButton}
                    onPress={() => dialCall(getDriver?.driver_phone)}>
                    <Image
                      source={require('../assets/img/Call.png')}
                      style={styles.callIcon}
                    />
                    <Text style={styles.callText}>Call</Text>
                  </TouchableOpacity>
                </View>
              </ScrollView>
            )}
          </BottomSheet>
        </View>
      </View>
    </>
  );
};

const styles = StyleSheet.create({
  centeredView: {
    flex: 1,
    width: '100%',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 22,
  },
  modalView: {
    margin: 20,
    backgroundColor: 'white',
    borderRadius: 20,
    padding: 35,
    width: '90%',
    height: 400,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  button: {
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 10,
    width: 200,
    elevation: 2,
  },
  buttonClose: {
    backgroundColor: '#000055',
  },
  textStyle: {
    color: 'white',
    fontSize: 20,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  modalText: {
    fontSize: 18,
    color: '#000',
    fontWeight: '800',
    marginBottom: 15,
    textAlign: 'center',
  },
  model_section: {
    borderBottomWidth: 1,
    borderColor: '#ddd',
    marginBottom: 10,
    paddingBottom: 20,
    flexDirection: 'row',
    bottom: 10,
    marginTop: '5%',
    justifyContent: 'space-between',
  },
  driverName: {
    fontSize: 13,
    textAlign: 'left',
    color: '#000',
    fontWeight: 'bold',
  },
  vehicleDetails: {
    fontSize: 13,
    textAlign: 'left',
    color: '#000',
    fontWeight: 'bold',
  },
  estFareText: {
    fontSize: 13,
    textAlign: 'center',
    color: '#000',
    fontWeight: 'bold',
    padding: 5,
  },
  estFareAmount: {
    fontSize: 13,
    textAlign: 'center',
    color: '#000',
    fontWeight: 'bold',
  },
  shareButton: {
    borderRadius: 15,
    borderWidth: 2,
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    padding: 6,
    borderColor: '#000',
    width: 111,
    marginRight: '10%',
    alignSelf: 'flex-start',
  },
  callButton: {
    borderRadius: 15,
    borderWidth: 2,
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    padding: 6,
    borderColor: 'red',
    width: 111,
    marginLeft: '10%',
    alignSelf: 'flex-end',
  },
  shareIcon: {
    width: 20,
    height: 20,
    marginRight: 5,
  },
  callIcon: {
    width: 25,
    height: 20,
    marginRight: 5,
  },
  shareText: {
    fontSize: 13,
    color: '#000',
    fontWeight: 'bold',
  },
  callText: {
    fontSize: 13,
    color: '#000',
    fontWeight: 'bold',
  },
});

export default TripDestination;
