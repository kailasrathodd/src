import React, {useState} from 'react';
import {View, Text, TextInput, FlatList, TouchableOpacity} from 'react-native';

const data = [
  {id: 1, name: 'Apple'},
  {id: 2, name: 'Banana'},
  {id: 3, name: 'Cherry'},
  {id: 4, name: 'Date'},
  {id: 5, name: 'Elderberry'},
  {id: 6, name: 'Fig'},
  {id: 7, name: 'Grape'},
  {id: 8, name: 'Honeydew'},
  {id: 9, name: 'Kiwi'},
  {id: 10, name: 'Lemon'},
];

const SearchAndSelect = () => {
  const [searchTerm1, setSearchTerm1] = useState('');
  const [searchTerm2, setSearchTerm2] = useState('');
  const [selectedItems, setSelectedItems] = useState([]);
  const [filteredData, setFilteredData] = useState(data);

  const handleSearch1 = text => {
    setSearchTerm1(text);
    setFilteredData(
      data.filter(
        item =>
          item.name.toLowerCase().includes(text.toLowerCase()) &&
          item.name.toLowerCase().includes(searchTerm2.toLowerCase()),
      ),
    );
  };

  const handleSearch2 = text => {
    setSearchTerm2(text);
    setFilteredData(
      data.filter(
        item =>
          item.name.toLowerCase().includes(searchTerm1.toLowerCase()) &&
          item.name.toLowerCase().includes(text.toLowerCase()),
      ),
    );
  };

  const renderItem = ({item}) => {
    const isSelected = selectedItems.find(
      selectedItem => selectedItem.id === item.id,
    );
    return (
      <TouchableOpacity onPress={() => handleItemPress(item)}>
        <View style={{backgroundColor: isSelected ? 'gray' : 'white'}}>
          <Text style={{padding: 10}}>{item.name}</Text>
        </View>
      </TouchableOpacity>
    );
  };

  const handleItemPress = item => {
    const isSelected = selectedItems.find(
      selectedItem => selectedItem.id === item.id,
    );
    if (isSelected) {
      setSelectedItems(
        selectedItems.filter(selectedItem => selectedItem.id !== item.id),
      );
    } else {
      setSelectedItems([...selectedItems, item]);
    }
  };

  const handleSelect = () => {
    // Perform some action with the selected items
    console.log(selectedItems);
  };

  return (
    <View>
      <TextInput
        style={{height: 40, borderColor: 'gray', borderWidth: 1}}
        onChangeText={handleSearch1}
        value={searchTerm1}
        placeholder={searchTerm1 || 'Search term 1'}
      />
      <TextInput
        style={{height: 40, borderColor: 'gray', borderWidth: 1}}
        onChangeText={handleSearch2}
        value={searchTerm2}
        placeholder={searchTerm2 || 'Search term 2'}
      />

      <FlatList
        data={filteredData}
        renderItem={renderItem}
        keyExtractor={item => item.id.toString()}
      />
      <TouchableOpacity
        style={{
          backgroundColor: 'lightblue',
          padding: 10,
          alignItems: 'center',
          margin: 10,
        }}
        onPress={handleSelect}>
        <Text>Select</Text>
      </TouchableOpacity>
    </View>
  );
};

export default SearchAndSelect;
