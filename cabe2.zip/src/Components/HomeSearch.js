import React, {useState} from 'react';
import {Searchbar, Button} from 'react-native-paper';
import {StyleSheet, View, Text, Pressable, TextInput} from 'react-native';

import AntDesign from 'react-native-vector-icons/AntDesign';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import Entypo from 'react-native-vector-icons/Entypo';
import {useNavigation} from '@react-navigation/native';
import {SafeAreaView} from 'react-native-safe-area-context';
import {TouchableOpacity} from 'react-native-gesture-handler';

function HomeSearch({screenName}) {
  const navigation = useNavigation();
  const [Show, setShow] = useState(false);
  const [TextInput1, setTextInput1] = useState();
  const [TextInput2, setTextInput12] = useState();
  const goToSearch = () => {
    navigation.navigate('DestinationSearch');
  };
  const [showButton, setShowButton] = useState(true);

  const handleSubmit = val => {
    if (val.length === 0) {
      setShowButton(true);
    } else {
      setShowButton(false);
    }
  };

  return (
    <>
      <View style={styles.container}>
        <View style={styles.innercontent}>
          <View>
            <Text style={styles.Pickup}>PICKUP LOCATION</Text>
            <TextInput
              style={{color: '#000', paddingVertical: 10, fontSize: 18}}
              placeholder=" API like the solutions here or add a custom route "
              value={TextInput1}
              onChangeText={value => {
                setTextInput1(value);
                handleSubmit(value);
              }}
            />
          </View>
          <View>
            <Text style={styles.Drop}>ENTER DROP LOCATION</Text>
            <TextInput
              name="SearchDrop"
              style={{color: '#000', paddingVertical: 10, fontSize: 18}}
              placeholder=" API like the solutions here or add a custom route "
            />
          </View>
        </View>
      </View>
      {/* {Show ? ( */}
      <View style={{position: 'absolute', bottom: 0, width: '100%'}}>
        <TouchableOpacity
          style={{
            width: '100%',
            alignItems: 'center',
            margin: 10,
            justifyContent: 'center',
          }}
          onPress={() => navigation.navigate("")}
          disabled={showButton == true ? true : false}>
          <Text
            style={{
              backgroundColor: '#000055',
              width: '90%',
              padding: 20,
              textAlign: 'center',
              fontSize: 25,
              paddingVertical: 20,
              borderRadius: 20,
              color: '#fff',
            }}>
            Done
          </Text>
        </TouchableOpacity>
      </View>
      {/* ) : null} */}
    </>
  );
}

export default HomeSearch;

const styles = StyleSheet.create({
  inputBox: {
    backgroundColor: '#e7e7e7',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },

  innercontent: {
    paddingHorizontal: 40,
    paddingVertical: 20,
    backgroundColor: '#fff',
    borderRadius: 20,
    width: '90%',
    margin: 20,
  },

  container: {},

  inputText: {
    fontSize: 20,
    fontWeight: '600',
    color: '#000',
  },

  Pickup: {
    fontSize: 18,
    fontWeight: '600',
    color: '#ddd',
    // borderColor: '#e7e7e7',
    paddingLeft: 1,
    borderRadius: 50,
    backgroundColor: '#fff',
    flexDirection: 'row',
    justifyContent: 'center',
    margin: 1,
  },

  Drop: {
    color: '#ddd',
    fontSize: 18,
    fontWeight: '600',
    borderColor: '#e7e7e7',
    paddingLeft: 1,
    backgroundColor: '#fff',
    borderRadius: 50,
    flexDirection: 'row',
    justifyContent: 'center',
    margin: 1,
  },

  row: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 20,
    borderBottomWidth: 1,
    borderColor: '#dbdbdb',
  },
  iconContainer: {
    backgroundColor: '#b3b3b3',
    padding: 10,
    borderRadius: 25,
  },
  destinationText: {
    marginLeft: 10,
    fontWeight: '500',
    fontSize: 16,
  },
});
