import {createAsyncThunk} from '@reduxjs/toolkit';
import API from '../../APIs/RepositoryFactory';
import {setHub} from './index';

export const chargingHubAPI = createAsyncThunk(
  'chargingHubAPI/chargingHubAPI',
  async (payload, thunkAPI) => {
    try {
      const response = await API.hubRepository.chargingHub(payload);
      if (response) {
        thunkAPI.dispatch(setHub(response.data.data));
      }
      return response.data.data;
    } catch (error) {
      console.tron.log('Error: ', error);
    }
  },
);
