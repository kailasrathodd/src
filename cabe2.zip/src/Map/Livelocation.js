import React, {useState} from 'react';
import {StyleSheet, Alert, View, Button} from 'react-native';
// import  from 'mapmyindia-restapi-react-native-beta';
import MapplsGL from 'mappls-map-react-native';
import {DEFAULT_CENTER_COORDINATE} from '../utils/index';

MapplsGL.setMapSDKKey('57ed4a46a04bb48819af047eede68cee'); //place your mapsdkKey
MapplsGL.setRestAPIKey('fa00fe4ec72020f44813576d13d6cd41'); //your restApiKey
MapplsGL.setAtlasClientId(
  '33OkryzDZsJ5zN81E9FCF9vruFDY_8wEJySBHTVN2YroM6YVpgCRG8GjfY_w_wHLGWA24P-wObVzK2I7yH0AtQ==',
); //your atlasClientId key
MapplsGL.setAtlasClientSecret(
  'lrFxI-iSEg_7x4WFo74p0-leBomnlnqQTpyHrd7f--g-2lk3ZpOOZwBvabvkCEVBSC1yny1ymG7pZN0FkXFrzi8og6fFRBF7',
); //your atlasClientSecret key
// MapplsGL.setAtlasGrantType('client_credentials');
export default function Livelocation() {
  const [userLocation, setUserLocation] = useState(null);

  const getUserLocation = async () => {
    navigator.geolocation.getCurrentPosition(
      position => {
        setUserLocation({
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
        });
      },
      error => alert(error.message),
      {enableHighAccuracy: true, timeout: 20000, maximumAge: 1000},
    );
  };

  return (
    <View style={styles.container}>
      {/* <MapmyIndiaMapView
        style={{flex: 1}}
        zoomLevel={12}
        userLocationButtonVisible={true}
        userLocation={userLocation}
      /> */}

      <MapplsGL.MapView style={{flex: 1}}>
        <MapplsGL.Camera
          ref={c => (this.camera = c)}
          zoomLevel={4}
          centerCoordinate={DEFAULT_CENTER_COORDINATE}
        />

        <MapplsGL.PointAnnotation
          id="myAnnotation"
          coordinate={[72.8777, 19.076]}
          title="My Annotation"
          description="This is my point annotation"
        />
      </MapplsGL.MapView>
      <Button
        title="My Location"
        // onPress={getUserLocation}

        onPress={() => Alert.alert('check your live location.')}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
