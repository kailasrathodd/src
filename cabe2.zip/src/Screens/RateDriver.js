import React, {useState} from 'react';
import {useDispatch, useSelector} from 'react-redux';
import {
  StyleSheet,
  TouchableOpacity,
  Text,
  View,
  Image,
  ScrollView,
} from 'react-native';
import {Avatar} from 'react-native-paper';
import BottomSheet from 'react-native-simple-bottom-sheet';
import {Rating} from 'react-native-ratings';
import {getFontSize} from '../utility/responsive';
import LiveLoc from '../Map/LiveLoc';
import {CreateRide, GetRideDetail} from '../features/CreateToRide';
import theme from '../theme';

const RateDriver = ({navigation}) => {
  const [selectedStars, setSelectedStars] = useState(0);
  const dispatch = useDispatch();
  const driverDetails = useSelector(state => state?.rider?.getDriver);

  const ratingCompleted = rating => {
    console.log('Rating is: ' + rating);
  };

  const fillColor = rating => {
    setSelectedStars(rating);
  };

  const handleCancel = () => {
    dispatch(GetRideDetail(null));
    dispatch(CreateRide(null));
    navigation.navigate('HomeScreen');
  };

  const handleDone = () => {
    dispatch(GetRideDetail(null));
    dispatch(CreateRide(null));
    navigation.navigate('RateServices');
  };

  return (
    <View style={{height: '100%'}}>
      <View style={{width: '100%', height: '100%'}}>
        <LiveLoc />
      </View>
      <View style={{height: '100%', flex: 1}}>
        <BottomSheet
          isOpen
          innerContentStyle={{height: '100%'}}
          sliderMaxHeight={460}
          height={'100%'}>
          {onScrollEndDrag => (
            <ScrollView onScrollEndDrag={onScrollEndDrag}>
              <View>
                <View
                  style={{
                    marginBottom: 10,
                    borderBottomWidth: 1,
                    borderColor: '#ddd',
                  }}>
                  <Text
                    style={{
                      fontSize: 25,
                      textAlign: 'center',
                      color: '#000',
                      fontWeight: 'bold',
                      marginBottom: 10,
                    }}>
                    Rate Driver
                  </Text>
                </View>
                <View
                  style={{
                    flexDirection: 'row',
                    width: '100%',
                    justifyContent: 'space-between',
                  }}>
                  <View style={{width: '30%', backgroundColor: '#fff'}}>
                    <Image
                      style={{width: 80, height: 80, borderRadius: 100}}
                      source={require('../../src/assets/img/Profile.png')}
                    />
                  </View>
                  <View
                    style={{
                      justifyContent: 'center',
                      width: '70%',
                      backgroundColor: '#fff',
                    }}>
                    <Text
                      style={{
                        fontSize: getFontSize(15),

                        color: '#000',
                        fontWeight: 'bold',
                        width: '100%',
                      }}>
                      {driverDetails?.driver_first_name?.toUpperCase() ||
                        'Driver Name'}{' '}
                      {driverDetails?.driver_last_name?.toUpperCase()}
                    </Text>
                    <Text
                      style={{
                        fontSize: getFontSize(20),
                        textAlign: 'left',
                        color: '#000',
                        fontWeight: 'bold',
                      }}>
                      {driverDetails?.drive_car_no?.toUpperCase() ||
                        '_ _ _ _ _'}
                    </Text>
                  </View>
                </View>
                <View
                  style={{
                    marginBottom: 8,
                    alignItems: 'center',
                  }}>
                  <Text
                    style={{
                      fontSize: getFontSize(22),
                      textAlign: 'center',
                      color: '#000',
                      fontWeight: '600',
                      marginTop: '2%',
                    }}>
                    How is your driver
                  </Text>
                  <Text
                    style={{
                      textAlign: 'center',
                      color: '#000',
                      fontWeight: '500',
                      marginTop: '2%',
                      fontSize: getFontSize(12),
                    }}>
                    Please rate your driver ...
                  </Text>
                  <View
                    style={{
                      flexDirection: 'row',
                      justifyContent: 'center',
                      alignItems: 'center',
                      marginBottom: 10,
                      width: '100%',
                    }}>
                    <Rating
                      // imageSize={38}
                      ratingCount={5}
                      fractions
                      jumpValue={0.5}
                      onFinishRating={ratingCompleted}
                      style={{
                        padding: 10,
                        width: '100%',
                        justifyContent: 'center',
                      }}
                    />
                  </View>
                </View>
                <View
                  style={{
                    flexDirection: 'row',

                    bottom: '2%',
                    justifyContent: 'space-between',
                  }}>
                  <TouchableOpacity
                    style={{
                      backgroundColor: 'red',

                      borderRadius: 10,

                      width: '45%',

                      justifyContent: 'center',
                      height: 50,
                    }}
                    onPress={handleCancel}>
                    <Text
                      style={{
                        color: '#fff',

                        alignItems: 'center',
                        textAlign: 'center',
                      }}>
                      Cancel
                    </Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    style={{
                      backgroundColor: '#000055',
                      alignItems: 'center',
                      borderRadius: 10,
                      width: '45%',
                      padding: 5,
                      height: 50,
                      justifyContent: 'center',
                    }}
                    onPress={handleDone}>
                    <Text
                      style={{
                        color: '#fff',

                        alignItems: 'center',
                        textAlign: 'center',
                      }}>
                      Submit
                    </Text>
                  </TouchableOpacity>
                </View>
              </View>
            </ScrollView>
          )}
        </BottomSheet>
      </View>
    </View>
  );
};

export default RateDriver;
