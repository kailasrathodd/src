/* eslint-disable react-native/no-inline-styles */
import {
  StyleSheet,
  Text,
  View,
  Image,
  ScrollView,
  TouchableOpacity,
} from 'react-native';
import React from 'react';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import Icon2 from 'react-native-vector-icons/Ionicons';

function JourneyDetails() {
  return (
    <>
      <View
        style={{
          alignItems: 'center',
        }}>
        <Image
          style={{
            borderRadius: 15,
            margin: 20,
          }}
          source={require('../../src/assets/img/cab.png')}
        />

        <Text style={{fontSize: 20, color: '#000'}}>EV City</Text>
      </View>
      <View
        style={{
          borderBottomWidth: 1,
          marginHorizontal: 20,
          paddingBottom: 15,
          flexDirection: 'row',
          justifyContent: 'space-evenly',
          marginVertical: 30,
        }}>
        <View
          stye={{
            justifyContent: 'center',
            alignItems: 'center',
            textAlign: 'center',
          }}>
          <Text style={styles.FontEditing}>Fare</Text>
          <Text style={styles.FontEditing}>Rs 555.00</Text>
        </View>
        <View
          style={{
            borderLeftWidth: 1,
            borderRightWidth: 1,
            paddingHorizontal: 20,
          }}>
          <Text style={styles.FontEditing}>Distance</Text>
          <Text style={styles.FontEditing}>23.23KM</Text>
        </View>
        <View>
          <Text style={styles.FontEditing}>Duration</Text>
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              padding: 10,
            }}>
            <View style={{flex: 1, height: 1, backgroundColor: '#000'}} />
          </View>
        </View>
      </View>
      <ScrollView>
        <View>
          <View>
            <View style={styles.confirmBook}>
              <Text style={styles.Maintitle}>Booking Date</Text>
              <Text style={styles.Subtitle}> Wallet</Text>
              <View
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  padding: 10,
                }}>
                <View style={{flex: 1, height: 1, backgroundColor: '#ddd'}} />
              </View>
            </View>
            <View style={styles.confirmBook}>
              <Text style={styles.Maintitle}>Booking Time</Text>
              <Text style={styles.Subtitle}> Wallet</Text>
              <View
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  padding: 10,
                }}>
                <View style={{flex: 1, height: 1, backgroundColor: '#ddd'}} />
              </View>
            </View>
            <View style={styles.confirmBook}>
              <Text style={styles.Maintitle}>Payment Mode</Text>
              <Text style={styles.Subtitle}> Wallet</Text>
              <View
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  padding: 10,
                }}>
                <View style={{flex: 1, height: 1, backgroundColor: '#ddd'}} />
              </View>
            </View>
            <View style={styles.confirmBook}>
              <Text style={styles.Maintitle}>Pick Up </Text>
              <Text style={styles.Subtitle}> M2J Fitness Center</Text>
              <View
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  padding: 10,
                }}>
                <View style={{flex: 1, height: 1, backgroundColor: '#ddd'}} />
              </View>
            </View>
            <View style={styles.confirmBook}>
              <Text style={styles.Maintitle}>Drop off Location</Text>
              <Text style={styles.Subtitle}> Mokash Plaza</Text>
              <View
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  padding: 10,
                }}>
                <View style={{flex: 1, height: 1, backgroundColor: '#ddd'}} />
              </View>
            </View>

            <View style={styles.cab_manager}>
              <View>
                <Text style={styles.Maintitle}>Cab Manager</Text>
                <Text style={styles.Subtitle}> Tata Tigor EV</Text>
                <Text style={styles.Subtitle}> MH02</Text>
              </View>
              <View>
                <View
                  style={{
                    position: 'absolute',
                    left: 60,
                    justifyContent: 'center',
                    gap: 15,
                    flexDirection: 'row',
                  }}>
                  <TouchableOpacity>
                    <Icon2
                      style={{
                        fontSize: 30,
                        alignItems: 'center',
                        color: '#000',
                      }}
                      name="md-call"
                    />
                    <Text
                      style={{fontSize: 20, fontWeight: 800, color: '#000'}}>
                      Call
                    </Text>
                  </TouchableOpacity>
                  <TouchableOpacity>
                    <Icon2
                      style={{
                        fontSize: 30,
                        color: '#000',
                      }}
                      name="chatbubble-ellipses-outline"
                    />
                    <Text
                      style={{fontSize: 20, fontWeight: 800, color: '#000'}}>
                      Chat
                    </Text>
                  </TouchableOpacity>
                </View>
              </View>
              <View
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  padding: 10,
                }}>
                <View style={{flex: 1, height: 1, backgroundColor: '#ddd'}} />
              </View>
            </View>
          </View>
        </View>
      </ScrollView>
      <View>
        <TouchableOpacity
          style={{
            alignItems: 'center',
            width: '100%',
            margin: 10,
            justifyContent: 'center',
          }}>
          <Text
            style={{
              backgroundColor: '#000055',
              width: '70%',
              textAlign: 'center',
              fontSize: 20,
              padding: 10,

              borderRadius: 50,
              color: '#fff',
            }}>
            Confirm
          </Text>
        </TouchableOpacity>
      </View>
    </>
  );
}

export default JourneyDetails;

const styles = StyleSheet.create({
  FontEditing: {
    fontSize: 20,
    color: '#000',
    fontWeight: 800,
    justifyContent: 'center',
    alignItems: 'center',
    textAlign: 'center',
  },
  cab_manager: {
    flex: 1,

    justifyContent: 'space-between',
    flexDirection: 'row',
    paddingBottom: 2,
    paddingHorizontal: 20,
    paddingTop: 5,
  },
  confirmBook: {
    paddingBottom: 2,
    paddingHorizontal: 20,
    paddingTop: 5,
  },
  Subtitle: {
    marginTop: 2,
    color: '#000',
  },

  Maintitle: {
    fontSize: 20,
    color: '#000',
    fontWeight: 'bold',

    // margin: 10,
  },
});
