import {M_Repository, Repository} from './Repository';

const reviewQuestions = 'reviewQuestions';

export default {
  reviewQuestions(payload) {
    return Repository.post(transformRoute(reviewQuestions), payload);
  },
};

const transformRoute = route => {
  return `/api/${route}`;
};
