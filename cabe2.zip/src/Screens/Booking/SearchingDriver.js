/* eslint-disable react-native/no-inline-styles */
/* eslint-disable react-hooks/exhaustive-deps */
import {View} from 'react-native';
import React, {useEffect} from 'react';
import {SafeAreaView} from 'react-native';
import ButtonSlide from '../../Components/ButtonSlide';
import {
  getDriverAPI,
  getRideDetailAPI,
} from '../../features/CreateToRide/riderAPI';
import {useDispatch, useSelector} from 'react-redux';
import {ride_id} from '../../features/CreateToRide';
import Retry from '../../Components/Retry';
import MapLive from '../Map/MapLive';

const SearchingDriver = React.memo(({navigation}) => {
  const dispatch = useDispatch();
  const Createride = useSelector(state => state.rider?.CreateRide);
  const rider = useSelector(state => state?.rider?.GetRideDetail);

  useEffect(() => {
    const interval = setInterval(() => {
      if (Createride !== null) {
        dispatch(getRideDetailAPI(Createride?._id));
        dispatch(getDriverAPI({ride_id: rider?._id}));
        dispatch(getDriverAPI(Createride?._id));
        dispatch(ride_id(Createride?._id));
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [rider, dispatch, Createride]);

  useEffect(() => {
    dispatch(getDriverAPI({ride_id: Createride?._id}));
    dispatch(getDriverAPI(Createride?._id));
    dispatch(getRideDetailAPI(Createride?._id));
    dispatch(ride_id(Createride?._id));
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      if (rider) {
        dispatch(getRideDetailAPI(Createride?._id));
        switch (rider.status) {
          case 'accepted':
            dispatch(getDriverAPI({ride_id: Createride?._id}));
            navigation.navigate('ShowDriver');
            break;
          case 'arrived':
            navigation.navigate('ShowDriver');
            break;
          case 'started':
            navigation.navigate('TripDestination');
            break;
          case 'timeout':
            navigation.navigate('HomeScreen');
            break;
          // case 'rejected':
          //   navigation.navigate('HomeScreen');
          // break;
          case 'customer_cancelled':
            navigation.navigate('HomeScreen');
            break;
          case 'ended':
            navigation.navigate('EndtoRider');
            break;
          case 'completed':
            navigation.navigate('RateDriver');
            break;
        }
      }
    }, 1500);

    return () => clearInterval(interval);
  }, [rider, dispatch]);

  return (
    <SafeAreaView style={{flex: 1, backgroundColor: '#fff'}}>
      <View
        style={{
          width: '100%',
          height: '100%',
          position: 'absolute',
        }}>
        {/* <LiveLoacation /> */}
        <MapLive />
      </View>
      <View
        style={{
          width: '100%',
          alignItems: 'center',
          justifyContent: 'space-evenly',
          flexDirection: 'row',
          marginTop: '5%',
        }}>
        <View
          style={{
            width: '90%',
            padding: 15,
            backgroundColor: '#fff',
            shadowColor: '#000',
            marginTop: '10%',
            borderRadius: 15,
            shadowOffset: {
              width: 0,
              height: 12,
            },
            shadowOpacity: 0.58,
            shadowRadius: 16.0,

            elevation: 24,
          }}>
          {/* <Text
            style={{
              fontSize: getFontSize(16),
              fontWeight: '900',
              justifyContent: 'center',
              alignSelf: 'center',
            }}
          >
            Searching for Driver
          </Text> */}
          <Retry />
        </View>
      </View>
      <ButtonSlide />
    </SafeAreaView>
  );
});

export default SearchingDriver;
