import React from 'react';

import SearchingDriver from './SearchingDriver';
import ShowDriver from './ShowDriver';
import RateDriver from '../RateDriver';
import HomeScreen from '../HomePage/homeScreen';
import TripDestination from '../TripDestination';
import JourneyDetails from '../JourneyDetails';
import EndtoRider from '../EndRider';
import DriverReached from './DriverReached';

function RideStatus({status}) {
  // if (props && props.driverStatus == true) {
  switch (status) {
    case 'requested':
      return <SearchingDriver />;
    case 'accepted':
      return <ShowDriver />;
    case 'arrived':
      return <DriverReached />;
    case 'started':
      return <TripDestination />;
    case 'ended':
      return <EndtoRider />;
    case 'completed':
      return <RateDriver />;
    case 'timeout':
      return <HomeScreen />;
    case 'customer_cancelled':
      return <HomeScreen />;
    case 'admin_cancelled':
      return <JourneyDetails />;
    default:
      return <HomeScreen />;
  }
}

export default RideStatus;
