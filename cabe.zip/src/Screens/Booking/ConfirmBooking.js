/* eslint-disable no-dupe-keys */
/* eslint-disable react-native/no-inline-styles */
/* eslint-disable no-shadow */
import {View, Text, Image, StatusBar, Alert} from 'react-native';
import React, {useState} from 'react';
import {ScrollView, TouchableOpacity} from 'react-native-gesture-handler';
import Header from '../../Components/HeaderComp';
import {useDispatch, useSelector} from 'react-redux';
import {getFontSize, getResWidth} from '../../utility/responsive';
import {CreaterideAPI} from '../../features/CreateToRide/riderAPI';
import {Dropdown} from 'react-native-element-dropdown';
import {ActivityIndicator} from 'react-native';
import theme from '../../theme';
import {payment} from '../../features/CreateToRide';
const data = [
  {label: 'Cash', value: 'Cash'},
  {label: 'Online', value: 'Online'},
];
export default function ConfirmBooking({navigation}) {
  const dispatch = useDispatch();
  const fare = useSelector(state => state.fare?.fare?.Fare_data);
  const basicDetail = useSelector(state => state.basicDetail.basicDetail);

  const rider_id = useSelector(state => state.auth.user?._id);
  const pick_up_latitude = basicDetail?.pickup_latitude;
  const pick_up_longitude = basicDetail?.pickup_longitude;
  const drop_off_latitude = basicDetail?.drop_latitude;
  const drop_off_longitude = basicDetail?.drop_longitude;
  const ride_amount = fare?.ride_amount;
  // var ride_amount = parseFloat(newNumbertoFloat).toFixed(2);
  const [payment_type, setPaymode] = useState(null);
  const [isFocus, setIsFocus] = useState(false);
  const [isVerifyLoading, setIsVerifyLoading] = useState(null);

  const handleSendBook = () => {
    setIsVerifyLoading(true);
    if (!payment_type) {
      Alert.alert('Please select a payment mode');
      return;
    }
    const payload = {
      pick_up_latitude: pick_up_latitude,
      pick_up_longitude: pick_up_longitude,
      drop_off_latitude: drop_off_latitude,
      drop_off_longitude: drop_off_longitude,
      pick_up_address: basicDetail && basicDetail.pickup_address,
      drop_off_address: basicDetail && basicDetail.drop_address,
      rider_id: rider_id,
      car_category: 'ev city',
      ride_km: fare && fare?.ride_km,
      estimate_time: fare && fare?.estimate_time,
      ride_amount: ride_amount || '_ _ _ _',
      category_id: (fare && fare?.category_id) || '64253eb230580000a30026a2',
      ride_type: 'book_now',
      payment_type: payment_type || 'Cash',
      Sub_Total: (fare && fare?.Sub_Total) || '562',
      Base_Fare: (fare && fare?.Base_Fare) || '102',
      KM_Fare: (fare && fare?.KM_Fare) || '52',
      Minutes_Fare: (fare && fare?.Minutes_Fare) || '52',
      Trip_Fare: (fare && fare?.Trip_Fare) || '562',
      Tax_Fare: (fare && fare?.Tax_Fare) || '562',

      SGST_Fare: (fare && fare?.SGST_6_Percentage) || '6',

      CGST_Fare: (fare && fare?.CGST_6_Percentage) || '6',
      SGST: (fare && fare?.SGST) || '6',
      CGST: (fare && fare?.CGST) || '6',
    };

    dispatch(CreaterideAPI(payload))
      .then(data => {
        if (data.payload.status === 200) {
          dispatch(payment(payment_type));
          navigation.navigate('SearchingDriver');
          setIsVerifyLoading(false);
        }
      })
      .catch(error => {
        setIsVerifyLoading(false);
        console.error(error);
        Alert.alert('something went wrong please try again');
      });
  };
  const isButtonDisabled = !payment_type;
  return (
    <View
      style={{
        position: 'relative',
        // height: '100%',
        width: '100%',
        height: '100%',
      }}>
      <Header
        containerStyle={{
          width: '100%',
          alignSelf: 'center',
        }}
        title={'Confirm Booking'}
        backPress={() => {
          navigation.pop();
        }}
      />
      <StatusBar backgroundColor="#000055" barStyle="light-content" />
      <ScrollView
        showsVerticalScrollIndicator={false}
        showsHorizontalScrollIndicator={false}
        style={{
          flex: 1,
          width: '100%',
          height: '100%',
          alignSelf: 'center',
        }}>
        <View
          style={{
            width: '100%',
            height: 150,

            alignItems: 'center',

            // shadowColor: '#171717',
            shadowOffset: {width: -4, height: 4},
            // shadowOpacity: 0.2,
            // shadowRadius: 3,
            marginVertical: 20,
          }}>
          <View
            style={{
              width: '90%',
              borderRadius: 15,
              backgroundColor: '#fff',
              flexDirection: 'row',
              justifyContent: 'space-evenly',
              shadowColor: '#000',
              shadowOffset: {
                width: 0,
                height: 6,
              },
              shadowOpacity: 0.7,
              shadowRadius: 7.49,

              elevation: 20,
            }}>
            <View
              style={{
                backgroundColor: '#8743FF',
                margin: 20,
                // zIndex: -1,
                alignItems: 'center',
                borderRadius: 15,
                height: 110,
                width: 100,
                position: 'relative',
                shadowColor: '#000',
                shadowOffset: {
                  width: 0,
                  height: 6,
                },
                shadowOpacity: 0.37,
                shadowRadius: 7.49,

                elevation: 12,
              }}>
              <Image
                resizeMode="contain"
                style={{
                  alignItems: 'center',

                  height: 90,
                  width: 80,
                  position: 'relative',
                  marginTop: '10%',
                }}
                source={require('../../assets/img/car-3d-01.png')}
              />
            </View>
            <View>
              <Text
                style={{
                  alignItems: 'center',
                  top: 60,
                  fontSize: 20,
                  fontWeight: 800,
                }}>
                {basicDetail.booking_Vehical}
              </Text>
            </View>
          </View>
        </View>

        <View>
          <View style={{paddingHorizontal: getResWidth(15)}}>
            <View style={{}}>
              <Text
                style={{
                  fontWeight: 700,
                  fontSize: getFontSize(15),
                  color: '#000',
                }}>
                Pick Up Location
              </Text>
              {basicDetail ? (
                <Text
                  style={{
                    color: '#000',
                    opacity: 0.51,
                    width: '100%',
                    marginTop: '3%',
                    fontSize: getFontSize(14),
                  }}>
                  {basicDetail?.pickup_address}
                </Text>
              ) : (
                <Text
                  style={{
                    color: '#000',
                    opacity: 0.51,
                    width: '100%',
                    marginTop: '3%',
                    fontSize: getFontSize(14),
                  }}>
                  {basicDetail?.pickup_address}
                </Text>
              )}

              <View
                style={{
                  borderWidth: 0.9,
                  borderColor: '#000',
                  opacity: 0.4,
                  marginTop: '3%',
                }}
              />
            </View>
            <View style={{marginTop: '3%'}}>
              <Text
                style={{
                  fontWeight: 700,
                  fontSize: getFontSize(15),

                  color: '#000',
                }}>
                Drop off Location
              </Text>
              {basicDetail !== '' ? (
                <Text
                  style={{
                    color: '#000',
                    opacity: 0.51,
                    width: '100%',
                    marginTop: '3%',
                    fontSize: getFontSize(14),
                  }}>
                  {basicDetail?.drop_address}
                </Text>
              ) : (
                <Text
                  style={{
                    color: '#000',
                    opacity: 0.51,
                    width: '100%',
                    color: '#000',
                    marginTop: '3%',
                    fontSize: getFontSize(14),
                  }}>
                  Drop Address
                </Text>
              )}

              <View
                style={{
                  borderWidth: 0.9,
                  borderColor: '#000',
                  opacity: 0.4,
                  marginTop: '3%',
                }}
              />
            </View>

            {/* <View
              style={{}}>
              <Text
                style={{
                 fontWeight: 700,
                  fontSize: getFontSize(15),
                  // margin: 10,
                }}>
                Booking Mode
              </Text>
              <View style={{flexDirection: 'row'}}>
                <RadioButton.Item
                  value="first"
                  label="Now"
                  status={checked === 'first' ? 'checked' : 'unchecked'}
                  onPress={() => setChecked('first')}
                />
                <RadioButton.Item
                  value="second"
                  label="Scheduled"
                  status={checked === 'second' ? 'checked' : 'unchecked'}
                  onPress={() => setChecked('second')}
                />
              </View>
              <View
                style={{
                  borderWidth: 0.9,
                  borderColor: '#ddd',
                  opacity: 0.4,
                  marginTop: '8%',
                }}
              />
            </View> */}

            <View style={{marginTop: '5%'}}>
              <Text
                style={[
                  {
                    fontWeight: 700,
                    fontSize: getFontSize(16),
                    color: '#000',
                  },
                  isFocus && {color: 'blue'},
                ]}>
                Payment Mode
              </Text>
              <Dropdown
                style={[
                  {
                    height: 40,
                    paddingHorizontal: 8,
                    padding: 1,
                  },
                  isFocus && {borderColor: 'blue'},
                ]}
                placeholderStyle={{
                  fontSize: getFontSize(15),
                }}
                selectedTextStyle={{
                  fontSize: getFontSize(15),
                  width: '100%',
                  marginLeft: '-2.5%',
                }}
                iconStyle={{
                  width: 20,
                  height: 20,
                }}
                data={data}
                maxHeight={150}
                labelField="label"
                valueField="value"
                placeholder={!isFocus ? 'Select Payment Mode' : '...'}
                value={payment_type}
                onFocus={() => setIsFocus(true)}
                onBlur={() => setIsFocus(false)}
                onChange={item => {
                  setPaymode(item.value);
                  setIsFocus(false);
                }}
              />
            </View>
            <View
              style={{
                borderWidth: 0.9,
                borderColor: '#000',
                opacity: 0.4,
                // marginTop: '3%',
              }}
            />

            <View style={{marginTop: '5%'}}>
              <Text
                style={{
                  fontWeight: 700,
                  fontSize: getFontSize(15),
                  color: '#000',
                }}>
                Estimated Fare
              </Text>
              <Text
                style={{
                  marginTop: '3%',
                }}>
                {Math.round(ride_amount) || '_____'}
              </Text>
              <View
                style={{
                  borderWidth: 0.9,
                  borderColor: '#000',
                  opacity: 0.4,
                  marginTop: '3%',
                }}
              />
            </View>

            <View
              style={{
                width: '100%',

                alignItems: 'center',

                // shadowColor: '#171717',
                shadowOffset: {width: -4, height: 4},
                // shadowOpacity: 0.2,
                // shadowRadius: 3,
                marginVertical: 20,
              }}>
              <View
                style={{
                  width: '100%',
                  borderRadius: 15,
                  backgroundColor: '#fff',
                  flexDirection: 'row',
                  justifyContent: 'space-evenly',
                  shadowColor: '#000',
                  shadowOffset: {
                    width: 0,
                    height: 6,
                  },
                  shadowOpacity: 0.7,
                  shadowRadius: 7.49,

                  elevation: 20,
                }}>
                <View style={{flex: 1, padding: getResWidth(20)}}>
                  <View style={{marginTop: '2%'}}>
                    <Text
                      style={{
                        textAlign: 'justify',
                        lineHeight: 20,
                        color: 'red',
                        fontWeight: 700,
                        fontSize: getFontSize(15),
                        marginTop: '3%',
                      }}>
                      Note :
                    </Text>
                    <Text
                      style={{
                        textAlign: 'justify',
                        lineHeight: 20,
                        color: 'red',
                        fontWeight: 500,
                        fontSize: getFontSize(11),
                        marginTop: '3%',
                      }}>
                      * This Is Only An Estimated Fare, The Final Fare Might
                      Change Depending On The Traffic Conditions. The Final Fare
                      Will Show Only When The Ride Ends
                    </Text>
                    <Text
                      style={{
                        textAlign: 'justify',
                        lineHeight: 20,
                        color: 'red',
                        fontWeight: 500,
                        fontSize: getFontSize(11),
                        marginTop: '3%',
                      }}>
                      * Toll Charges Are Not Included In The Estimated Fare. The
                      Cab Manager Will Enter The Toll Charges In The Final Fare
                      Only When A Toll Comes In Your Route.
                    </Text>
                    <Text
                      style={{
                        textAlign: 'justify',
                        lineHeight: 20,
                        color: 'red',
                        fontWeight: 500,
                        fontSize: getFontSize(11),
                        marginTop: '3%',
                      }}>
                      * Night Time Charges Will Be At 1.5X
                    </Text>
                  </View>
                  <View style={{marginTop: '5%'}}>
                    <Text
                      style={{
                        fontWeight: '500',
                        lineHeight: 20,
                        color: '#000',
                      }}>
                      Enjoy!
                    </Text>
                    <Text
                      style={{
                        width: '100%',
                        lineHeight: 20,
                        fontWeight: '500',
                        color: '#000',
                      }}>
                      Zero Surge | Zero Technology Usage Coat | Zero
                      Cancellations & Waiting Charges
                    </Text>
                  </View>
                </View>
              </View>
            </View>
          </View>
        </View>

        <TouchableOpacity
          style={{
            marginVertical: 5,
            paddingVertical: 5,
            bottom: 10,
            borderRadius: getResWidth(12),
            backgroundColor: isButtonDisabled ? '#ddd' : '#000055',
            justifyContent: 'center',
            textAlign: 'center',
            width: '90%',
            alignSelf: 'center',
          }}
          onPress={handleSendBook}
          disabled={isButtonDisabled}>
          {isVerifyLoading === true ? (
            <ActivityIndicator color={theme.color.extraLight} size={35} />
          ) : (
            <Text
              style={{
                width: '95%',
                textAlign: 'center',
                fontSize: 18,
                fontWeight: '500',

                padding: 5,
                color: '#fff',
              }}>
              Book
            </Text>
          )}
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
}
