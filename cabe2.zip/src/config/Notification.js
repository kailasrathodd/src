import messaging from '@react-native-firebase/messaging';
import {useEffect} from 'react';
import {Alert, Linking} from 'react-native';

export async function requestUserPermission() {
  useEffect(() => {
    const unsubscribe = messaging().onMessage(async remoteMessage => {
      Alert.alert('A new FCM message arrived!', JSON.stringify(remoteMessage));
    });

    return unsubscribe;
  }, []);
  const authStatus = await messaging().requestPermission();
  const enabled =
    authStatus === messaging.AuthorizationStatus.AUTHORIZED ||
    authStatus === messaging.AuthorizationStatus.PROVISIONAL;

  if (enabled) {
    return await getFCMToken();
  } else {
    const openSetting = () => {
      Linking.openSettings().catch(() => {
        Alert.alert('Unable to open settings');
      });
    };
    Alert.alert(
      'E-App',
      'Turn on Notification Services to allow E-App Services.',
      [
        {text: 'Go to Settings', onPress: openSetting},
        {
          text: "Don't allow Notification",
          onPress: () => {},
        },
      ],
    );
  }
}

async function getFCMToken() {
  try {
    const FCMToken = await messaging().getToken();
    console.log('FCMToken', FCMToken);
    return FCMToken;
  } catch (erro) {
    console.log('FCM Token error', erro?.message);
    return null;
  }
}

// import messaging from '@react-native-firebase/messaging';
// import {Alert, Linking} from 'react-native';
// import {addFireTokenAPI} from '../reducers/GoldAlerts/AlertAPI';
// import {store} from '../store';

// export async function requestUserPermission() {
//   const authStatus = await messaging().requestPermission();
//   const enabled =
//     authStatus === messaging.AuthorizationStatus.AUTHORIZED ||
//     authStatus === messaging.AuthorizationStatus.PROVISIONAL;

//   if (enabled) {
//     console.log('Authorization status:', authStatus);
//     getFCMToken();
//   } else {
//     const openSetting = () => {
//       Linking.openSettings().catch(() => {
//         Alert.alert('Unable to open settings');
//       });
//     };
//     Alert.alert(
//       'kailas',
//       'Turn on Notification Services to allow kailas Services.',
//       [
//         {text: 'Go to Settings', onPress: openSetting},
//         {
//           text: "Don't allow Notification",
//           onPress: () => {},
//         },
//       ],
//     );
//   }
// }

// async function getFCMToken() {
//   try {
//     const FCMToken = await messaging().getToken();
//     console.log('FCM Token genrated', FCMToken);
//     await store.dispatch(addFireTokenAPI(FCMToken));
//     return FCMToken;
//   } catch (erro) {
//     console.log('FCM Token error', erro?.message);
//     return null;
//   }
// }
