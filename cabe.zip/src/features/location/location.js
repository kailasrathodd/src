import {createSlice} from '@reduxjs/toolkit';

const location = createSlice({
  name: 'location',
  initialState: {
    latitude: null,
    longitude: null,
    AddressPin: null,
    myDuration: null,
    myDistance: null,
    myLocation: null,
    pickUpLocation: '',
    dropeLoc: null,
    dropLocation: '',
    pickUpeLoc: null,
    AddressPinPickUP: null,
    AddressPinDrop: null,
    RideUpdate: null,
    CurrentLocation: null,
    resetPin: null,
    typeLocation: null,
  },
  reducers: {
    updateLocation: (state, action) => {
      state.latitude = action.payload.latitude;
      state.longitude = action.payload.longitude;
    },
    AddressPin: (state, action) => {
      state.AddressPin = action.payload;
    },
    CurrentLocation: (state, action) => {
      state.CurrentLocation = action.payload;
    },
    AddressPinPickUP: (state, action) => {
      state.AddressPinPickUP = action.payload;
    },
    resetPin: (state, action) => {
      state.resetPin = true;
      // state.AddressPinPickUP = null;
      state.AddressPinDrop = null;
    },
    AddressPinDrop: (state, action) => {
      state.AddressPinDrop = action.payload;
    },
    PickUpLocation(state, {payload}) {
      state.pickUpLocation = payload;
    },
    PickUpeLoc(state, {payload}) {
      state.pickUpeLoc = payload;
    },
    DropeLoc(state, {payload}) {
      state.dropeLoc = payload;
    },
    DropLocation(state, {payload}) {
      state.dropLocation = payload;
    },

    MyRouteCreate: (state, action) => {
      state.pickUpLocation = action.payload;
      state.dropLocation = action.payload;
    },
    myLocation: (state, action) => {
      state.myLocation = action.payload;
    },
    myDistance: (state, action) => {
      state.myDistance = action.payload;
    },
    myDuration: (state, action) => {
      state.myDuration = action.payload;
    },
    RideUpdateAPI: (state, action) => {
      state.RideUpdate = action.payload;
    },
    typeLocation: (state, action) => {
      state.typeLocation = action.payload;
    },
    getDriveLoc: (state, action) => {
      state.getDriveLoc = action.payload;
    },
  },
});

export const {
  PickUpLocation,
  myDistance,
  myDuration,
  PickUpeLoc,
  updateLocation,
  DropLocation,
  MyRouteCreate,
  myLocation,
  DropeLoc,
  AddressPin,
  AddressPinPickUP,
  AddressPinDrop,
  RideUpdateAPI,
  typeLocation,
  resetPin,
  CurrentLocation,
} = location.actions;

export default location.reducer;
