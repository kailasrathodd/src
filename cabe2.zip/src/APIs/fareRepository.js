import {Repository} from './Repository';

const fareAPI = 'riderGetFareDetailsForRequest';

export default {
  fareAPI(payload) {
    return Repository.post(transformRoute(fareAPI), payload);
  },
};
const transformRoute = route => {
  return `/api/${route}`;
};
