import {View, Text} from 'react-native';
import React from 'react';

export const MapmyIndia11 = MapplsGL.setMapSDKKey(
  '57ed4a46a04bb48819af047eede68cee',
); //place your mapsdkKey
MapplsGL.setRestAPIKey('fa00fe4ec72020f44813576d13d6cd41'); //your restApiKey
MapplsGL.setAtlasClientId(
  '33OkryzDZsJ5zN81E9FCF9vruFDY_8wEJySBHTVN2YroM6YVpgCRG8GjfY_w_wHLGWA24P-wObVzK2I7yH0AtQ==',
); //your atlasClientId key
MapplsGL.setAtlasClientSecret(
  'lrFxI-iSEg_7x4WFo74p0-leBomnlnqQTpyHrd7f--g-2lk3ZpOOZwBvabvkCEVBSC1yny1ymG7pZN0FkXFrzi8og6fFRBF7',
); //your atlasClientSecret key
// MapplsGL.setAtlasGrantType('client_credentials');;
