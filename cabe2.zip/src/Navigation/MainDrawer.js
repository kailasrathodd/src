import * as React from 'react';
import {createDrawerNavigator} from '@react-navigation/drawer';
import DrawerContent from './DrawerContent';
import Home from './home';
import MyProfile from '../Screens/profile/MyProfile';

import PromoCode from '../Screens/wallet/PromoCode';
import Sos from '../Screens/Sos';
import AddAddress from '../Screens/Address/AddAddress';
import HomePage from '../Screens/HomePage/HomePage';
import HomeScreen from '../Screens/HomePage/homeScreen';
import RegisterEmail from '../Screens/profile/RegisterEmail';
import GetInTouchStack from '../Screens/getInTouch/GetInTouchStack';
const Drawer = createDrawerNavigator();

function MainDrawer() {
  return (
    <Drawer.Navigator
      initialRouteName="Home"
      drawerContent={props => <DrawerContent {...props} />}
      screenOptions={{
        headerShown: false,
        headerTransparent: false,
        headerStyle: {
          backgroundColor: '', //Set Header color
        },

        headerTintColor: '#000',
      }}>
      <Drawer.Screen
        name="Home"
        options={{headerShown: false}}
        component={Home}
      />
      <Drawer.Screen name="HomeScreen" component={HomeScreen} />
      <Drawer.Screen name="RegisterEmail" component={RegisterEmail} />
      <Drawer.Screen name="MyProfile" component={MyProfile} />
      <Drawer.Screen name="HomePage" component={HomePage} />
      <Drawer.Screen name="AddAddress" component={AddAddress} />
      <Drawer.Screen name="Sos" component={Sos} />
      <Drawer.Screen name="PromoCode" component={PromoCode} />
      <Drawer.Screen name="GetInTouchStack" component={GetInTouchStack} />
    </Drawer.Navigator>
  );
}

export default MainDrawer;
