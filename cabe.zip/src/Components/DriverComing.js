import React, {useState, useEffect} from 'react';
import {View, Text, TouchableOpacity, Alert} from 'react-native';
import theme from '../theme';
import {getFontSize} from '../utility/responsive';
import {useSelector, useDispatch} from 'react-redux';

const DriverComing = () => {
  const getArrived_time = useSelector(state => state?.rider?.getArrived_time);
  const rider = useSelector(state => state?.rider?.GetRideDetail);
  const sec = getArrived_time;
  const [countdown, setCountdown] = useState(sec);

  useEffect(() => {
    let interval;
    if (countdown > 0) {
      interval = setInterval(() => {
        setCountdown(countdown - 1);
      }, 1000);
    }
    return () => {
      clearInterval(interval);
    };
  }, [countdown]);

  const handleResendOTP = () => {
    setCountdown(600);
  };

  const countdownTextStyle = {
    color: theme.color.grey2,
    fontSize: getFontSize(16),
    fontWeight: '900',
    justifyContent: 'center',
    alignSelf: 'center',
  };

  const greenDotStyle = {
    color: theme.color.GREEN_DOT,
    fontSize: getFontSize(16),
    fontWeight: '900',
    justifyContent: 'center',
    alignSelf: 'center',
    borderRadius: 105,
    textAlign: 'center',
  };

  const retryTextStyle = {
    color: theme.color.grey2,
    fontSize: getFontSize(18),
    fontWeight: '900',
    justifyContent: 'center',
    alignSelf: 'center',
  };

  const tryAgainTextStyle = {
    color: theme.color.primary,
    fontWeight: '900',
    fontSize: getFontSize(15),
    marginTop: '2%',
  };

  return (
    <View style={{marginTop: '2%'}}>
      {rider?.status === 'accepted' && (
        <>
          {countdown > 0 ? (
            <Text style={countdownTextStyle}>
              Driver is Arriving in{' '}
              <Text style={greenDotStyle}>
                {Math.floor(countdown / 60)
                  .toString()
                  .padStart(2, '0')}
                :
                {Math.floor(countdown % 60)
                  .toString()
                  .padStart(2, '0')}{' '}
                Minutes
              </Text>
            </Text>
          ) : (
            <Text style={retryTextStyle}>
              Driver has Arriving in{'  '}
              <TouchableOpacity onPress={handleResendOTP}>
                <Text style={tryAgainTextStyle}>Refresh</Text>
              </TouchableOpacity>
            </Text>
          )}
        </>
      )}
      {rider?.status === 'arrived' && (
        <Text
          style={{
            color: theme.color.GREEN_DOT,
            fontSize: getFontSize(17),
            fontWeight: '900',
            justifyContent: 'center',
            alignSelf: 'center',
          }}>
          Driver has Arrived
        </Text>
      )}
      {rider?.status === 'started' && (
        <Text
          style={{
            color: theme.color.GREEN_DOT,
            fontSize: getFontSize(17),
            fontWeight: '900',
            justifyContent: 'center',
            alignSelf: 'center',
          }}>
          Start your Journey
        </Text>
      )}
    </View>
  );
};

export default DriverComing;
