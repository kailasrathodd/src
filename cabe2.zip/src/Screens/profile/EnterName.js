import React, {useState} from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  SafeAreaView,
  ActivityIndicator,
  Alert,
} from 'react-native';
import {useDispatch, useSelector} from 'react-redux';
import {getFontSize} from '../../utility/responsive';
import {TextInput} from 'react-native-paper';
import {
  ProfileAPI,
  getBasicDetailsAPI,
} from '../../features/basicdetails/basicdetail';
import HomeScreen from '../HomePage/homeScreen';

export default function EnterName({navigation}) {
  const [firstName, setFirstName] = useState('');
  const [isValidName, setIsValidName] = useState(true);
  const [isLoading, setIsLoading] = useState(false);

  const validateName = name => {
    return name.length >= 3;
  };

  const rider_id = useSelector(state => state.auth.user);
  const dispatch = useDispatch();

  const navigateToHomeScreen = () => {
    navigation.reset({
      index: 0,
      routes: [{name: 'MainDrawer' || 'HomeScreen'}],
    });
  };

  const handleNameChange = value => {
    setFirstName(value);
    setIsValidName(validateName(value));
  };

  const basicDetail = async () => {
    if (isValidName) {
      setIsLoading(true);
      const payload = {
        rider_id: rider_id._id,
      };

      dispatch(getBasicDetailsAPI(payload))
        .then(data => {
          if (data.payload.status === 200) {
            const loggedIn = true;
            if (loggedIn) {
              if (rider_id._id === rider_id._id) {
                navigation.navigate('HomeScreen');
                navigation.navigate('MainDrawer');
              } else {
                navigateToHomeScreen();
              }
            }
            setIsLoading(false);
          }
        })
        .catch(error => {
          setIsLoading(false);
          console.error(error);
          Alert.alert('Something went wrong. Please try again.');
        });
    }
  };

  const onContinuePressed = async () => {
    if (isValidName) {
      setIsLoading(true);
      const payload = {
        first_name: firstName,
        _id: rider_id && rider_id._id,
        phone_number: rider_id && rider_id.phone_number,
      };

      dispatch(ProfileAPI(payload))
        .then(data => {
          if (data.payload.status === 200) {
            basicDetail();
            setIsLoading(false);
          }
        })
        .catch(error => {
          setIsLoading(false);
          console.error(error);
          Alert.alert('Something went wrong. Please try again.');
        });
    }
  };

  return (
    <SafeAreaView style={{backgroundColor: '#fff', flex: 1}}>
      <View
        style={{
          width: '100%',
          alignItems: 'center',
          alignSelf: 'center',
          marginLeft: '10%',
          marginTop: '10%',
        }}>
        <Text
          style={{
            width: '100%',
            color: '#000',
            fontWeight: '700',
            marginTop: '5%',
            fontSize: getFontSize(25),
          }}>
          Enter Your Name
        </Text>
      </View>
      <View
        style={{
          width: '90%',
          justifyContent: 'center',
          alignContent: 'center',
          alignSelf: 'center',
          marginTop: '35%',
        }}>
        <TextInput
          autoCorrect={false}
          keyboardAppearance="default"
          onChangeText={handleNameChange}
          value={firstName}
          label="Enter Your Name"
          style={{
            width: '95%',
            fontSize: 15,
            fontWeight: '300',
            backgroundColor: '#ffffff',
            textAlign: 'auto',
            borderColor: isValidName ? '#dddddd' : 'red',
            borderBottomWidth: isValidName ? 0 : 1,
            alignSelf: 'center',
          }}
          onFocus={() => setIsValidName(true)}
        />
        {!isValidName && (
          <Text style={{color: 'red', marginLeft: '5%'}}>
            Enter a valid name
          </Text>
        )}
      </View>

      <TouchableOpacity
        style={{
          width: '100%',
          alignItems: 'center',
          justifyContent: 'center',
          position: 'absolute',
          bottom: '5%',
        }}
        onPress={onContinuePressed}
        disabled={!isValidName || isLoading}>
        {isLoading ? (
          <ActivityIndicator color="#000055" />
        ) : (
          <Text
            style={{
              backgroundColor: isValidName ? '#000055' : '#dddddd',
              width: '95%',
              textAlign: 'center',
              fontSize: 14,
              borderRadius: 12,
              padding: 10,
              color: isValidName ? '#fff' : '#777',
            }}>
            Continue
          </Text>
        )}
      </TouchableOpacity>
    </SafeAreaView>
  );
}
