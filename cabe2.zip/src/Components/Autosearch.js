import React, {useState, useEffect, useRef} from 'react';
import {
  Text,
  View,
  TouchableOpacity,
  FlatList,
  Image,
  ActivityIndicator,
  TextInput,
  Modal,
  Pressable,
  Alert,
} from 'react-native';
import MapplsGL from 'mappls-map-react-native';
import {point} from '@turf/helpers';
import Toast from 'react-native-simple-toast';
import {Searchbar} from 'react-native-paper';
import {
  RideUpdateAPI,
  eLocPick,
  getBasicDetailsAPI,
  getElocTotPickUpAPI,
} from '../features/basicdetails/basicdetail';
import {useDispatch, useSelector} from 'react-redux';
import theme from '../theme';
import {getFontSize, getResWidth} from '../utility/responsive';
// import piRideUpdateAPI} from '../features/location/location';

const styles = {
  icon: {
    // iconImage: exampleIcon,
    iconAllowOverlap: true,
    iconSize: 0.2,
    iconAnchor: 'bottom',
  },
};

export default function Autosearch({navigation}, props) {
  const timeoutRef = useRef(0);
  const cameraRef = useRef(null);
  const [query, setQuery] = useState('');
  const [placesList, setPlacesList] = useState([]);
  const [selectedPlace, setSelectedPlace] = useState([]);
  const [progressBar, setProgressBar] = useState(false);
  const [mapFlex, setMapFlex] = useState(1);
  const [mounted, setMounted] = useState(false);
  const rider_id = useSelector(state => state.auth.user?._id);
  const [modalVisible, setModalVisible] = React.useState('');
  const dispatch = useDispatch();
  const [isVerifyLoading, setIsVerifyLoading] = useState(null);
  const [eloc, setEloc] = useState(null);
  const [Address, setAddress] = useState(null);
  useEffect(() => {
    setMounted(true);
    callAutoSuggest('Mapmy');

    return () => {
      setMounted(false);
      clearTimeout(timeoutRef.current);
    };
  }, []);

  const callAutoSuggest = text => {
    if (text.length > 2) {
      const arr = [];
      MapplsGL.RestApi.autoSuggest({
        query: text,
      })
        .then(data => {
          // console.tron.log('Data', data);
          if (mounted) {
            console.log(data.suggestedLocations[0]);
            if (
              data.suggestedLocations !== undefined &&
              data.suggestedLocations.length > 0
            ) {
              for (let i = 0; i < data.suggestedLocations.length; i++) {
                arr.push([
                  data.suggestedLocations[i].placeName,
                  [
                    parseFloat(data.suggestedLocations[i].longitude),
                    parseFloat(data.suggestedLocations[i].latitude),
                  ],
                  data.suggestedLocations[i].placeAddress,
                  data.suggestedLocations[i].mapplsPin,
                  data.suggestedLocations[i],
                ]);
              }
              setPlacesList(arr);
              setProgressBar(false);
              setMapFlex(0);
            } else {
              Toast.show('No suggestions found', Toast.SHORT);
              setProgressBar(false);
            }
          }
        })
        .catch(error => {
          console.log(error.code, error.message);
          setProgressBar(false);
          Toast.show(error.message, Toast.SHORT);
        });
    } else if (text.length <= 2) {
      setPlacesList([]);
      setProgressBar(false);
      setMapFlex(1);
    }
  };

  const onTextChange = text => {
    setQuery(text);
    setProgressBar(true);

    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
    }

    timeoutRef.current = setTimeout(() => {
      console.log('calling');
      callAutoSuggest(text.trim());
    }, 2000);
  };

  const onPress = location => {
    cameraRef.current.setCamera({
      centerCoordinate: location,
      zoomLevel: 11,
      animationDuration: 500,
    });
    console.log([location[0], location[1]]);
    setSelectedPlace([location[0], location[1]]);
    setPlacesList([]);
    setMapFlex(1);
  };

  const renderSeparator = () => {
    return (
      <View
        style={{
          height: 1,
          backgroundColor: '#CED0CE',
          marginLeft: 25,
        }}
      />
    );
  };

  const renderItem =
    placesList.length > 0 ? (
      <View
        style={{
          flex: 1,
          position: 'absolute',
          top: 70,
          left: 0,
          right: 0,
          backgroundColor: 'white',
          zIndex: 40,
        }}>
        <FlatList
          data={placesList}
          ItemSeparatorComponent={renderSeparator}
          keyExtractor={(item, index) => item[0] + index}
          renderItem={({item}) => (
            <TouchableOpacity
              style={{paddingLeft: 10, paddingBottom: 10, paddingRight: 5}}
              onPress={async () => {
                const eloc = item[3];
                setEloc(eloc);
                // dispatch(PickUpeLoc(eloc));
                const pickup_address = item[0];
                const pickup_addres = item[2];
                const newAddress = pickup_address + pickup_addres;
                setAddress(newAddress);

                dispatch(
                  RideUpdateAPI({
                    pickup_address: pickup_address + pickup_addres,
                    rider_id: await rider_id,
                    pickup_details: item[4],
                    pickup_Eloc: await eloc,
                  }),
                );

                setModalVisible(!modalVisible);
              }}>
              <View style={{flexDirection: 'row', alignItems: 'center'}}>
                <View
                  style={{
                    flexDirection: 'column',
                    paddingStart: 10,
                    paddingEnd: 5,
                  }}>
                  <Text style={{fontSize: 16}}>{item[0]}</Text>
                  <Text style={{color: 'grey', marginRight: '5%'}}>
                    {item[2]}
                  </Text>
                </View>
              </View>
            </TouchableOpacity>
          )}
        />
      </View>
    ) : null;

  const marker =
    selectedPlace.length > 0 ? (
      <MapplsGL.ShapeSource
        id="symbolLocationSource"
        shape={point([selectedPlace[0], selectedPlace[1]])}>
        <MapplsGL.SymbolLayer id="symbolLocationSymbols" style={styles.icon} />
      </MapplsGL.ShapeSource>
    ) : null;

  return (
    <View style={{flex: 1, justifyContent: 'center'}}>
      <View
        style={{
          flexDirection: 'row',
          paddingLeft: 5,
          paddingRight: 5,
          justifyContent: 'center',
          alignContent: 'center',
        }}>
        <Searchbar
          placeholder="Search Here"
          onClear={text => searchFilterFunction(text)}
          style={{
            height: 50,

            borderColor: '#009688',
            backgroundColor: '#FFFFFF',
            width: '90%',
            elevation: 20,
            shadowColor: '#e200',
            // marginBottom: '15%',
            zIndex: 55,
          }}
          autoFocus={true}
          onChangeText={text => onTextChange(text)}
          value={query || ''}
          // onChange={item => {
          //   onTextChange(item);
          //   setIsFocus(true);
          // }}
        />
        <ActivityIndicator
          animating={progressBar}
          hidesWhenStopped={true}
          color="blue"
          style={{zIndex: 22}}
        />
      </View>
      <Modal
        animationType="slide"
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => {
          setModalVisible(!modalVisible);
        }}>
        <View
          style={{
            flex: 1,
            backgroundColor: theme.color.BACKGROUND,
            justifyContent: 'center',
            alignItems: 'center',
          }}>
          <View
            style={{
              width: '85%',

              borderRadius: 10,
              flex: 1,
              maxHeight: 200,
            }}>
            <View
              style={{
                margin: 10,
                backgroundColor: 'white',
                borderRadius: getResWidth(20),
                padding: 35,
                alignItems: 'center',
                shadowColor: '#000',
                shadowOffset: {
                  width: 0,
                  height: 2,
                },
                shadowOpacity: 0.25,
                shadowRadius: 4,
                elevation: 5,
              }}>
              <Text
                style={{
                  marginVertical: 15,
                  textAlign: 'justify',
                  lineHeight: 22,
                  fontSize: getFontSize(20),
                  fontWeight: 'bold',
                  color: '#000',
                }}>
                Address
              </Text>
              <Text
                style={{
                  marginVertical: 15,
                  textAlign: 'justify',
                  lineHeight: 22,
                  fontSize: getFontSize(15),
                  fontWeight: 'bold',
                  color: '#000',
                }}>
                {/* {Address} */}

                {Address.length > 80
                  ? Address.substring(0, 80) + '...'
                  : Address}
              </Text>
              {isVerifyLoading == true ? (
                <ActivityIndicator color={theme.color.primary} size={35} />
              ) : (
                <Pressable
                  style={{
                    backgroundColor: '#008000',
                    justifyContent: 'center',
                    alignItems: 'center',
                    borderRadius: getResWidth(20),
                    height: 40,
                    width: 270,
                    marginTop: '10%',
                  }}
                  onPress={async () => {
                    setIsVerifyLoading(true);

                    try {
                      const response = await dispatch(
                        getBasicDetailsAPI({
                          rider_id: rider_id,
                        }),
                        dispatch(getElocTotPickUpAPI(eloc)),
                        dispatch(eLocPick(eloc)),
                      );

                      if (response) {
                        setModalVisible(false);
                        navigation.navigate('HomePage');
                      }
                    } catch (error) {
                      Alert.alert('please Try again');
                    }
                    // navigation.navigate('HomePage');

                    setModalVisible(false);
                    setIsVerifyLoading(false);
                  }}>
                  <Text
                    style={{
                      color: 'white',
                      fontWeight: 'bold',
                      textAlign: 'center',
                    }}>
                    OK
                  </Text>
                </Pressable>
              )}
            </View>
          </View>
        </View>
      </Modal>
      {renderItem}

      <MapplsGL.MapView style={{flex: 1}}>
        <MapplsGL.Camera
          zoomLevel={4}
          animationMode="moveTo"
          ref={cameraRef}
          centerCoordinate={[78.6569, 22.9734]}
        />
        {marker}
      </MapplsGL.MapView>
    </View>
  );
}
