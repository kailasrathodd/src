import AsyncStorage from '@react-native-async-storage/async-storage';
import {store} from '../store';
import {} from '../features/auth/authAPI';

export const setUserSession = async props => {
  try {
    await AsyncStorage.setItem('session', props.toString());
  } catch (erro) {
    // console.tron.log('Something want wrong on session');
    await AsyncStorage.setItem('session', props);
  }
};

export const getUserSession = async () => {
  try {
    let loggedIn = await AsyncStorage.getItem('session');
    if (typeof loggedIn == 'string') {
      loggedIn = loggedIn == 'true';
    }
    return loggedIn;
  } catch (erro) {
    console.tron.log('Something want wrong on session');
    return false;
  }
};

export const gettoken = () => {
  if (store.getState().auth.mappleToken.accessToken) {
    return store.getState().auth.mappleToken.accessToken;
  } else {
    return null;
  }
};
export const getTokenFromSession = async () => {
  try {
    return await AsyncStorage.getItem('sessionToken');
  } catch (error) {
    console.error(error);
    return null;
  }
};
export const removeSession = async () => {
  try {
    const res = await store.dispatch({
      persist: root,
    });

    if (res.payload) {
      await AsyncStorage.removeItem('session');
      store.dispatch({type: 'RESET_STORE'});
    }
  } catch (error) {
    console.tron.log(error);
  }
};
