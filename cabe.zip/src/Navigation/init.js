import {createStackNavigator} from '@react-navigation/stack';
import {NavigationContainer, StackActions} from '@react-navigation/native';
import Auth from './auth';
import MainDrawer from './MainDrawer';
import {useSelector} from 'react-redux';

const Stack = createStackNavigator();

function InitialScreen() {
  const {loggedIn} = useSelector(state => state.auth);

  return (
    <NavigationContainer>
      <Stack.Navigator
        initialRouteName={loggedIn == true ? 'MainDrawer' : 'Auth'}
        screenOptions={{headerShown: false}}>
        <Stack.Screen name="Auth" component={Auth} />
        <Stack.Screen name="MainDrawer" component={MainDrawer} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

export default InitialScreen;
export const backAction = StackActions.pop();
