import React, {useEffect, useState} from 'react';
import {View, StyleSheet, ActivityIndicator} from 'react-native';
import MapplsGL from 'mappls-map-react-native';
import Polyline from 'mappls-polyline';
import {point} from '@turf/helpers';
import {useSelector} from 'react-redux';
import MyContext from '../utility/MyContext';
import exampleIcon from '../assets/img/cab-e-car.png';
import circle from '../assets/img/circle.png';

const styles = {
  icon: {
    iconImage: exampleIcon,
    iconAllowOverlap: true,
    iconSize: 0.05,
    iconAnchor: 'bottom',
  },
  circle: {
    iconImage: circle,
    iconAllowOverlap: true,
    iconSize: 0.3,
    iconAnchor: 'bottom',
  },
};

const layerStyles = {
  route: {
    lineColor: 'red',
    lineCap: 'round',
    lineJoin: 'round',
    lineWidth: 3,
    lineGradient: [
      'interpolate',
      ['linear'],
      ['line-progress'],
      0,
      ' #000',
      1,
      ' #000',
    ],
  },
};

const DriverRoute = () => {
  // Destructure props
  const basicDetail = useSelector(state => state.basicDetail?.basicDetail);
  const DriverLoc = useSelector(state => state.rider?.getDriverLoc);

  // State variables
  const [distance, setDistance] = useState('');
  const [duration, setDuration] = useState('');
  const [route, setRoute] = useState(null);
  const [center, setCenter] = useState([72.8482, 19.203767]);
  const [markerSourceCoordinates, setMarkerSourceCoordinates] = useState([]);
  const [markerDestCoordinates, setMarkerDestCoordinates] = useState([]);

  // Helper functions
  const formatDistance = distance => {
    if (distance / 1000 < 1) {
      return distance + 'M.';
    }
    const dis = (distance / 1000).toFixed(2);
    return dis + 'Km.';
  };

  const formatDuration = duration => {
    const min = parseInt(duration / 60);
    return min;
  };

  useEffect(() => {
    const sourceCoordinates = `${basicDetail.pickup_longitude},${basicDetail.pickup_latitude}`;
    const destinationCoordinates = `${DriverLoc?.longitude},${DriverLoc?.latitude}`;

    // Call API to get route information
    const callApi = async setProfile => {
      try {
        const data = await MapplsGL.RestApi.direction({
          origin: sourceCoordinates,
          destination: destinationCoordinates,
          profile: setProfile,
          overview: MapplsGL.RestApi.DirectionsCriteria.OVERVIEW_FULL,
          geometries: 'polyline6',
          alternatives: true,
          steps: true,
          traffic: true,
        });

        const routeGeoJSON = Polyline.toGeoJSON(data.routes[0].geometry, 6);
        setDistance(formatDistance(data.routes[0].distance));
        setDuration(formatDuration(data.routes[0].duration));
        setRoute(routeGeoJSON);
        setCenter(routeGeoJSON.coordinates[0]);
      } catch (error) {
        console.tron.log(error);
        // Handle error here (e.g., display an error message)
      }
    };

    if (basicDetail) {
      callApi('driving');
      setMarkerSourceCoordinates([
        basicDetail.pickup_longitude,
        basicDetail.pickup_latitude,
      ]);
      setMarkerDestCoordinates([DriverLoc?.longitude, DriverLoc?.latitude]);
    }
  }, [DriverLoc?.latitude, DriverLoc?.longitude, basicDetail]);

  if (!route) {
    return (
      <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
        <ActivityIndicator animating={true} />
      </View>
    );
  }

  return (
    <MyContext.Provider value={{distance, duration}}>
      <View style={{flex: 1}}>
        <MapplsGL.MapView style={{flex: 1}}>
          <MapplsGL.Camera zoomLevel={12} centerCoordinate={center} />

          {basicDetail?.drop_address !== '' &&
            basicDetail?.pickup_address !== '' &&
            route && (
              <>
                <MapplsGL.ShapeSource
                  key="symbolLocationSource"
                  id="symbolLocationSource"
                  shape={point(markerDestCoordinates)}>
                  <MapplsGL.SymbolLayer
                    key="symbolLocationSymbols"
                    id="symbolLocationSymbols"
                    minZoomLevel={1}
                    style={styles.icon}
                  />
                </MapplsGL.ShapeSource>

                <MapplsGL.ShapeSource
                  key="routeSource"
                  id="routeSource"
                  shape={route}>
                  <MapplsGL.LineLayer
                    key="routeFill"
                    id="routeFill"
                    style={layerStyles.route}
                  />
                </MapplsGL.ShapeSource>

                <MapplsGL.ShapeSource
                  key="symbolLocationSource2"
                  id="symbolLocationSource2"
                  shape={point(markerSourceCoordinates)}>
                  <MapplsGL.SymbolLayer
                    key="symbolLocationSymbols2"
                    id="symbolLocationSymbols2"
                    minZoomLevel={1}
                    style={styles.circle}
                  />
                </MapplsGL.ShapeSource>
              </>
            )}
        </MapplsGL.MapView>
      </View>
    </MyContext.Provider>
  );
};

const style = StyleSheet.create({
  buttons: {justifyContent: 'center', alignItems: 'center', flex: 1},
  text: {fontWeight: 'bold'},
});

export default DriverRoute;
