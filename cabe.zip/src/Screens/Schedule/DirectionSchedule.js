import {View, Text, Alert, TouchableOpacity} from 'react-native';
import setVectorIcon from '../../Components/VectorComponents';
import {getFontSize} from '../../utility/responsive';
import {useDispatch, useSelector} from 'react-redux';

import React, {useEffect, useState} from 'react';
import {getBasicDetailsAPI} from '../../features/basicdetails/basicdetail';
import {store} from '../../store';
import Header from '../../Components/HeaderComp';
import GetDirectionAPP from '../../Components/GetDirectionAPP';
import {ActivityIndicator} from 'react-native';
import LiveLoacation from '../Map/liveLoacation';
import {fareAPI} from '../../features/Fare/fareAPI';
import theme from '../../theme';
import {resetPin, typeLocation} from '../../features/location/location';
export default function DirectionSchedule({navigation}, props) {
  const dispatch = useDispatch();
  const model = useSelector(state => state.rider.categoryVehical);
  console.tron.log('response.data.status', model[2]._id);
  const user_id = useSelector(state => state.auth.user?._id);
  const [durData, setDurData] = useState([]);
  const distance = durData.distance;
  const dist = distance?.slice(0, -3);
  const duration = durData.duration;
  const loggedIn = store.getState().auth.loggedIn;
  const basicDetail = useSelector(
    state => state.basicDetail?.riderUpdate?.Rider_Data,
  );

  const [isVerifyLoading, setIsVerifyLoading] = useState(null);
  const coordinate = useSelector(state => state.basicDetail?.getElocPickup);

  const rider_id = useSelector(state => state.auth.user?._id);
  // console.log(
  //   'riderUpdate',

  //   basicDetail.pickup_latitude,
  // );
  const pick_up_latitude = basicDetail.pickup_latitude;
  const pick_up_longitude = basicDetail.pickup_longitude;
  const drop_off_latitude = basicDetail?.drop_latitude;
  const drop_off_longitude = basicDetail?.drop_longitude;

  useEffect(() => {
    dispatch(
      getBasicDetailsAPI({
        rider_id: basicDetail && basicDetail?.rider_id,
      }),
    );
  }, []);
  const handleSend = () => {
    setIsVerifyLoading(true);

    const payload = {
      category_id: model[2]?._id,
      pick_up_latitude: pick_up_latitude,
      pick_up_longitude: pick_up_longitude,
      drop_off_latitude: drop_off_latitude,
      drop_off_longitude: drop_off_longitude,

      rider_id: rider_id,
      pick_up_address: basicDetail.pickup_address,
      drop_off_address: basicDetail.drop_address,
    };

    dispatch(fareAPI(payload))
      .then(data => {
        if (data.payload.status === 200) {
          navigation.navigate('Schedule');

          setIsVerifyLoading(false);
        }
        if (data.payload.status === 201) {
          Alert.alert('Kilometers must be less than 100 km');

          setIsVerifyLoading(false);
        }
      })
      .catch(error => {
        setIsVerifyLoading(false);
        console.error(error);
        Alert.alert('something went wrong please try again');
      });
  };

  const handleData = data => {
    setDurData(data);
  };
  return (
    <View
      style={{
        position: 'relative',
        height: '100%',
      }}>
      {(basicDetail && basicDetail?.pickup_latitude) !== '' ||
      null ||
      (basicDetail && basicDetail?.drop_address) == '' ? (
        <View
          style={{
            width: '100%',
            height: '100%',
          }}>
          <GetDirectionAPP {...props} onData={handleData} />
        </View>
      ) : (
        <View
          style={{
            width: '100%',
            height: '100%',
          }}>
          <LiveLoacation />
        </View>
      )}

      <View
        style={{
          zIndex: 1,
          position: 'absolute',
          width: '100%',
          paddingHorizontal: 20,
          flexDirection: 'row',
          // top: '3.8%',
          justifyContent: 'space-between',
        }}>
        <Header
          containerStyle={{
            width: '100%',
            alignSelf: 'center',
          }}
          title={''}
          backPress={() => {
            navigation.navigate('HomeScreen');
          }}
          {...this.props}
        />

        <View
          style={{
            height: 60,
            width: 60,
            alignItems: 'center',
            justifyContent: 'center',
          }}>
          <View style={{justifyContent: 'center', alignItems: 'center'}}>
            <TouchableOpacity>
              {setVectorIcon({
                type: 'Ionicons',
                name: 'notifications',
                size: getFontSize(25),
                color: '#000',
              })}
            </TouchableOpacity>
          </View>
        </View>
      </View>

      <View
        style={{
          paddingHorizontal: 40,
          paddingVertical: 20,
          backgroundColor: '#fff',
          borderRadius: 20,
          width: '90%',
          margin: 20,
          top: '10%',
          zIndex: 1,
          position: 'absolute',
        }}>
        <View>
          <Text
            style={{
              fontSize: getFontSize(14),
              fontWeight: '600',
              color: '#ddd',
              paddingLeft: 1,
              borderRadius: 50,
              backgroundColor: '#fff',
              flexDirection: 'row',
              justifyContent: 'center',
              margin: 1,
            }}>
            {setVectorIcon({
              type: 'Entypo',
              name: 'controller-record',
              size: getFontSize(15),
              color: '#000',
            })}{' '}
            Pickup Location
          </Text>
          <TouchableOpacity
            style={{
              borderColor: '#ddd',
              borderBottomWidth: 0.21,
              width: '100%',
              textAlign: 'left',
              fontSize: getFontSize(14),
              padding: 10,
            }}
            onPress={() => {
              dispatch(resetPin(true));
              dispatch(typeLocation('PickUp'));
              navigation.navigate('PickupSchedule');
            }}>
            {basicDetail &&
            basicDetail?.pickup_address &&
            (basicDetail && basicDetail?.drop_latitude) !== '' ? (
              <Text
                style={{
                  color: '#000',
                  opacity: 0.51,
                  width: '100%',
                }}>
                {basicDetail?.pickup_address}
              </Text>
            ) : (
              <Text
                style={{
                  color: '#000',
                  opacity: 0.51,
                  width: '100%',
                }}>
                Enter Your Pickup Location
              </Text>
            )}
          </TouchableOpacity>
        </View>
        <View>
          <Text
            style={{
              fontSize: getFontSize(14),
              fontWeight: '600',
              color: '#ddd',
              paddingLeft: 1,
              borderRadius: 50,
              backgroundColor: '#fff',
              flexDirection: 'row',
              justifyContent: 'center',
              margin: 1,
            }}>
            {setVectorIcon({
              type: 'Entypo',
              name: 'controller-record',
              size: getFontSize(15),
              color: '#000',
            })}{' '}
            Drop Location
          </Text>
          <TouchableOpacity
            style={{
              borderColor: '#ddd',
              borderBottomWidth: 0.21,
              width: '100%',
              textAlign: 'left',
              fontSize: getFontSize(14),
              // borderRadius: 12,
              padding: 10,
            }}
            onPress={() => {
              dispatch(resetPin(true));
              dispatch(typeLocation('Drop'));
              navigation.navigate('DropSchedule');
            }}>
            {basicDetail &&
            basicDetail?.drop_address &&
            (basicDetail && basicDetail?.drop_latitude) !== '' ? (
              <Text
                style={{
                  color: '#000',
                  opacity: 0.51,
                  width: '100%',
                }}>
                {basicDetail?.drop_address}
              </Text>
            ) : (
              <Text
                style={{
                  color: '#000',
                  opacity: 0.51,
                  width: '100%',
                }}>
                {basicDetail?.drop_address}
              </Text>
            )}
          </TouchableOpacity>
        </View>
      </View>
      {/* <TouchableHighlight
        onPress={() => {
          var options = {
            description: 'Credits towards consultation',
            image: 'https://i.imgur.com/3g7nmJC.png',
            currency: 'INR',
            key: razorpay_key_id,

            amount: 175300,
            order_id: '',
            external: {
              wallets: ['paytm'],
            },
            name: 'CABEEZ',
            prefill: {
              email: 'kailas@razorpay.com',
              contact: '7888289898',
              name: 'kailas Rathod',
            },
            theme: {color: '#000055'},
          };
          RazorpayCheckout.open(options)
            .then(data => {
              signature: signature;
              // handle success
              alert(`Success: ${data.razorpay_payment_id}`);
              console.tron.log('data9898', data);
              console.tron.log('data122', signature);
              console.log('data123', data);
              console.log('data', data.data);
            })
            .catch(error => {
              // handle failure
              alert(`Error: ${error.code} | ${error.description}`);
            });
          RazorpayCheckout.onExternalWalletSelection(data => {
            alert(`External Wallet Selected: ${data.external_wallet} `);
          });
        }}
        style={{
          backgroundColor: '#000055',
          width: '50%',
          zIndex: 15,
          height: '5%',
          position: 'absolute',
          alignSelf: 'center',
          justifyContent: 'center',
          bottom: '15%',
        }}>
        <Text
          style={{
            fontSize: 20,
            fontWeight: 'bold',
            alignSelf: 'center',
            color: '#fff',
          }}>
          PAY
        </Text>
      </TouchableHighlight> */}
      {basicDetail && basicDetail.drop_latitude !== '' ? (
        <TouchableOpacity
          style={{
            width: '100%',
            alignItems: 'center',
            justifyContent: 'center',
            bottom: '7%',
          }}
          onPress={handleSend}>
          {isVerifyLoading == true ? (
            <ActivityIndicator color={theme.color.primary} size={35} />
          ) : (
            <Text
              style={{
                backgroundColor: '#000055',
                width: '95%',
                textAlign: 'center',
                fontSize: getFontSize(14),
                borderRadius: 12,
                padding: 10,
                color: '#fff',
              }}>
              Send Request
            </Text>
          )}
        </TouchableOpacity>
      ) : null}
    </View>
  );
}
