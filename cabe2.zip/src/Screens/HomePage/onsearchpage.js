import {
  View,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  SafeAreaView,
  Image,
  FlatList,
} from 'react-native';
import React, {useState} from 'react';
import {Searchbar} from 'react-native-paper';
import {useDispatch} from 'react-redux';
import {PickUpLocation, PickUpeLoc} from '../../features/location/location';
import LiveLoacation from '../Map/liveLoacation';
export default function SearchPickAddress({navigation}, props) {
  const onPress = props;
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [accessToken, setAccessToken] = useState([]);
  const [query, setQuery] = useState('');
  const [querys, setQuerys] = useState('');

  const dispatch = useDispatch();
  const handleDataUpdate = () => {
    dispatch(PickUpLocation(query));
  };

  const [isFocus, setIsFocus] = useState(false);
  const fetchAccessToken = async () => {
    const resp2 = await fetch(
      'https://outpost.mapmyindia.com/api/security/oauth/token?grant_type=client_credentials&client_id=33OkryzDZsJ5zN81E9FCF9vruFDY_8wEJySBHTVN2YroM6YVpgCRG8GjfY_w_wHLGWA24P-wObVzK2I7yH0AtQ==&client_secret=lrFxI-iSEg_7x4WFo74p0-leBomnlnqQTpyHrd7f--g-2lk3ZpOOZwBvabvkCEVBSC1yny1ymG7pZN0FkXFrzi8og6fFRBF7',
      {
        method: 'POST',
      },
    );

    const accessToken = await resp2.json();
    console.log(accessToken);
    setAccessToken(accessToken.access_token);
  };
  const showSuggestion = () => {
    fetchAccessToken();
    fetchData();
  };

  const fetchData = async () => {
    const resp = await fetch(
      `https://atlas.mapmyindia.com/api/places/search/json?access_token=${accessToken}&query=${query} || ${query}`,
    );
    const data = await resp.json();
    setData(data.suggestedLocations);

    setLoading(false);
  };

  const NewSetButton = item => {
    setQuerys(item.placeAddress);
    // console.tron.log(item.placeAddress);
    setQuery(item.placeAddress);
  };
  const renderItem = ({item, index}) => {
    return (
      <TouchableOpacity
        activeOpacity={0.7}
        onPress={() => {
          navigation.navigate('Search');
          NewSetButton(item);
          setQuerys(item.placeAddress);
          const eloc = item.eLoc;
          dispatch(PickUpeLoc(eloc));
          // console.tron.log(item.placeAddress);
          dispatch(PickUpLocation(item.placeAddress));
        }}
        style={{
          backgroundColor: '#ffff',
          width: '100%',
          padding: 10,

          alignSelf: 'center',
        }}>
        <View
          style={{
            backgroundColor: '#ffff',
            width: '100%',

            alignSelf: 'center',
          }}>
          {/* <Text style={{padding: 5, fontWeight: 700, fontSize: 15}}>
              {item.placeName}
            </Text> */}
          <Text style={{padding: 5, fontWeight: 700, fontSize: 15}}>
            {item.placeAddress}
          </Text>
        </View>
      </TouchableOpacity>
    );
  };
  const ItemSeparatorView = () => {
    return (
      <View
        style={{
          height: 0.5,
          width: '100%',
          backgroundColor: '#C8C8C8',
        }}
      />
    );
  };
  return (
    <SafeAreaView
      style={{
        position: 'relative',
        height: '100%',
        backgroundColor: '#fff',
      }}>
      <View
        style={
          {
            // position: 'absolute',
            // top: 0,
            // zIndex:
            // height: '100%',
            // backgroundColor: '#fff',
          }
        }>
        <LiveLoacation />
      </View>
      <View
        style={
          {
            // width: '100%',
            // alignSelf: 'center',
            // backgroundColor: '#fff',
            // borderRadius: 20,
            // zIndex: 1,
          }
        }>
        <View
          style={{
            // position: 'relative',
            // top: 0,

            height: '100%',
            // backgroundColor: '#fff',
          }}>
          <LiveLoacation />
        </View>

        {data ? (
          data && (
            <View
              style={{
                width: '100%',
                alignSelf: 'center',
                // height: 50,
                borderWidth: 1,
                borderColor: '#000',
                zIndex: 55,
                marginTop: '25%',
                position: 'absolute',
                width: '90%',
                alignSelf: 'center',
                backgroundColor: '#fff',
                shadowColor: '#000',
                shadowOffset: {
                  width: 0,
                  height: 8,
                },
                shadowOpacity: 0.46,
                shadowRadius: 11.14,

                elevation: 17,
              }}>
              <FlatList
                data={data}
                renderItem={renderItem}
                keyExtractor={item => item.placeAddress}
                ItemSeparatorComponent={ItemSeparatorView}
              />
            </View>
          )
        ) : (
          <View>
            <Text>data Not found</Text>
          </View>
        )}

        <Searchbar
          placeholder="Search Here"
          style={{
            height: 50,
            borderWidth: 1,
            borderColor: '#000',
            zIndex: 55,
            marginTop: '10%',
            position: 'absolute',
            width: '90%',
            alignSelf: 'center',
            backgroundColor: '#fff',
            shadowColor: '#000',
            shadowOffset: {
              width: 0,
              height: 8,
            },
            shadowOpacity: 0.46,
            shadowRadius: 11.14,

            elevation: 17,
          }}
          onChangeText={values => setQuery(values)}
          value={query}
          onChange={item => {
            showSuggestion(item);
            setIsFocus(true);
          }}
        />
      </View>
    </SafeAreaView>
  );
}
