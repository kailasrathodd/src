import React from 'react';
import {createStackNavigator} from '@react-navigation/stack';
import Splash1 from '../Screens/onboarding/Splash1';
import SplashScreen from '../Screens/onboarding/SplashScreen';
import Login from '../Screens/profile/Login';
import VerifyOtp from '../Screens/profile/VerifyOtp';
import Splash from '../Screens/onboarding/Splash';
import MainDrawer from './MainDrawer';
import {useSelector} from 'react-redux';
import RegisterEmail from '../Screens/profile/RegisterEmail';
import EnterName from '../Screens/profile/EnterName';
import {NewBoarding} from '../Screens/onboarding/newBoarding';

const Stack = createStackNavigator();

export default function Auth() {
  const {onBoarding} = useSelector(state => state.auth);
  return (
    <Stack.Navigator
      initialRouteName={onBoarding === true ? 'SplashScreen' : 'NewBoarding'}>
      <Stack.Screen
        name="Splash"
        component={Splash}
        options={{headerShown: false}}
      />

      <Stack.Screen
        name="RegisterEmail"
        component={RegisterEmail}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="EnterName"
        component={EnterName}
        options={{headerShown: false}}
      />

      <Stack.Screen
        name="Splash1"
        component={Splash1}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="NewBoarding"
        component={NewBoarding}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="SplashScreen"
        component={SplashScreen}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="Login"
        component={Login}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="VerifyOtp"
        component={VerifyOtp}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="MainDrawer"
        component={MainDrawer}
        options={{headerShown: false}}
      />
    </Stack.Navigator>
  );
}
