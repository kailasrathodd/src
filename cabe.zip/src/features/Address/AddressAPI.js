import {createAsyncThunk} from '@reduxjs/toolkit';
import API from '../../APIs/RepositoryFactory';

import * as Address from './index';
import {store} from '../../store';
export const selectedAddressAPI = createAsyncThunk(
  'selectedAddressAPI/selectedAddressAPI',
  async (payload, thunkAPI) => {
    try {
      if (store.getState().auth.onBoarding === true) {
        const response = await API.AddressRepository.selectedAddAddress(
          payload,
        );

        if (response.data.status === 200) {
          thunkAPI.dispatch(Address.selectedAddAddress(response.data));
        }
      }
      return response.data;
    } catch (error) {
      error;
    }
  },
);
export const deleteAddressAPI = createAsyncThunk(
  'deleteAddressAPI/deleteAddressAPI',
  async (payload, thunkAPI) => {
    try {
      if (store.getState().auth.onBoarding === true) {
        const response = await API.AddressRepository.deleteAddAddress(payload);

        if (response.data.status === 200) {
          thunkAPI.dispatch(Address.deleteAddAddress(response.data));
        }
      }
      return response.data;
    } catch (error) {
      error;
    }
  },
);
export const editAddAddressAPI = createAsyncThunk(
  'editAddAddressAPI/editAddAddressAPI',
  async (payload, thunkAPI) => {
    try {
      if (store.getState().auth.onBoarding === true) {
        const response = await API.AddressRepository.editAddAddress(payload);

        if (response.data.status === 200) {
          thunkAPI.dispatch(Address.editAddAddress(response.data));
        }
      }
      return response.data;
    } catch (error) {
      error;
    }
  },
);
export const addAddressAPI = createAsyncThunk(
  'addAddressAPI/addAddressAPI',
  async (payload, thunkAPI) => {
    try {
      if (store.getState().auth.onBoarding === true) {
        const response = await API.AddressRepository.addAddress(payload);

        if (response.data.status === 200) {
          thunkAPI.dispatch(Address.addAddress(response.data));
        }
      }
      return response.data;
    } catch (error) {
      error;
    }
  },
);
export const getAddressAPI = createAsyncThunk(
  'getAddressAPI/getAddressAPI',
  async (payload, thunkAPI) => {
    try {
      if (store.getState().auth.onBoarding === true) {
        const response = await API.AddressRepository.getAddress(payload);
        // console.log('response.data.status', response.data.data);
        thunkAPI.dispatch(Address.getAddress(response.data.data));
        if (response.data.status === 200) {
          thunkAPI.dispatch(Address.getAddress(response.data.data));
        }
      }
      return response.data;
    } catch (error) {
      error;
    }
  },
);
