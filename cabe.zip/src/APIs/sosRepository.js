import {M_Repository, Repository} from './Repository';

const sos = 'sos_insert_for_rider';
const reviewQuestions = 'reviewQuestions';

export default {
  sos(payload) {
    return Repository.post(transformRoute(sos), payload);
  },
  reviewQuestions(payload) {
    return Repository.post(transformRoute(reviewQuestions), payload);
  },
};

const transformRoute = route => {
  return `/api/${route}`;
};
