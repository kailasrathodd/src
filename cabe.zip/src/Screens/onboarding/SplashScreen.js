import React, {useEffect} from 'react';

import {
  Button,
  View,
  ImageBackground,
  Text,
  Image,
  Alert,
  TouchableOpacity,
  StyleSheet,
  TextInput,
} from 'react-native';

export default function SplashScreen({navigation}, props) {
  //   useEffect(() => {
  //     setTimeout(() => {
  //       navigation.navigate('Cabewallet');
  //     }, 100000);
  //   }, []);
  return (
    <ImageBackground
      source={require('../../assets/img/first_bg.png')}
      resizeMode="cover"
      style={{
        flex: 1,
        width: '100%',
        height: '100%',
        alignItems: 'center',
        justifyContent: 'space-between',
      }}>
      <View
        style={{
          justifyContent: 'center',
          alignItems: 'center',
          top: 50,
          flex: 1,
        }}>
        <Image
          source={require('../../assets/img/logo.png')}
          style={{width: 200, height: 100}}
        />
      </View>
      <View style={{justifyContent: 'center', alignItems: 'center', flex: 3}}>
        <Image
          source={require('../../assets/img/car_reg.png')}
          style={{width: 350, height: 200}}
        />
      </View>
      <View
        style={{
          position: 'absolute',
          height: '100%',
          width: '100%',
          backgroundColor: '#000',
          opacity: 0.5,
        }}></View>
      <TouchableOpacity
        style={{
          backgroundColor: '#000055',
          height: '6%',
          flexDirection: 'row',
          marginHorizontal: 20,
          marginVertical: 20,
          borderRadius: 25,
          alignItems: 'center',
          justifyContent: 'center',
        }}
        onPress={() => navigation.navigate('Login')}>
        <Text
          style={{
            width: '95%',
            textAlign: 'center',
            fontSize: 20,
            color: '#fff',
            fontWeight: 'bold',
          }}>
          SIGN IN / SIGN UP
        </Text>
      </TouchableOpacity>
    </ImageBackground>
  );
}
