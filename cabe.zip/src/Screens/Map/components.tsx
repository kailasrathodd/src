import React from 'react';
import {Image, NativeModules} from 'react-native';
import {
  ELocation,
  SuggestedSearchAtlas,
} from 'mappls-map-react-native/javascript/modules/restApi/models/AutoSuggestModel';

export interface PlaceWidgetProps {
  location?: [number, number];
  historyCount?: number;
  zoom?: number;
  saveHistory?: boolean;
  pod?: string;
  backgroundColor?: string;
  tokenizeAddress?: boolean;
  toolbarColor?: string;
  hint?: string;
  filter?: string;
  attributionVerticalAlignment?: any;
  attributionHorizontalAlignment?: any;
  logoSize?: number;
  userAddedLocationEnable?: boolean;
  enableTextSearch?: boolean;
  minCharactersForSearch?: number;
  statusBarColor?: string;
  toolbarTintColor?: string;
  showPoweredByText?: boolean;
  hyperLocal?: boolean;
  bridge?: boolean;
}

interface AutocompleteResult {
  eLocation: ELocation;
  suggestedSearch: SuggestedSearchAtlas;
}
const Components = {
  //map bottom logo
  mapLogo: () => {
    return (
      <Image
        source={require('../../assets/img/avater.jpg')}
        style={{height: 22, width: 190, left: 10}}
        resizeMode="contain"
      />
    );
  },

  openPlaceWidget: async (
    props: PlaceWidgetProps = {},
  ): Promise<AutocompleteResult> => {
    if (props.tokenizeAddress === undefined) {
      props.tokenizeAddress = true;
    }
    const response =
      await NativeModules.MapplsReactNativePlacePicker.openPlaceWidget(props);
    return JSON.parse(response);
  },
};

export default Components;
