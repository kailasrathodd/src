import * as React from 'react';
import {
  ImageBackground,
  StyleSheet,
  View,
  Alert,
  Text,
  Share,
  Linking,
  TouchableOpacity,
  FlatList,
  SafeAreaView,
} from 'react-native';
import WebView from 'react-native-webview';
import styles from './styles';
import Icon from 'react-native-vector-icons/FontAwesome5';
import MIcon from 'react-native-vector-icons/MaterialCommunityIcons';
import Header from '../../Components/HeaderComp';
import theme from '../../theme';
import {getResHeight} from '../../utility/responsive';

const backgroundimage = {
  uri: 'https://static.vecteezy.com/system/resources/thumbnails/006/469/228/small/abstract-white-background-with-halftone-texture-free-vector.jpg',
};

function showAlert2() {
  Alert.alert(
    'Alert Title',
    'My Alert Msg',
    [
      {
        text: 'Ask me later',
        // onPress: () => console.log('Ask me later pressed'),
      },
      {
        text: 'Cancel',
        // onPress: () => console.log('Cancel Pressed'),
        style: 'cancel',
      },
      {
        text: 'OK',
        // onPress: () => console.log('OK Pressed')
      },
    ],
    {cancelable: false},
  );
}

const onShare = async () => {
  try {
    const result = await Share.share({
      title: 'App link',
      message:
        'Please install this app and stay safe , AppLink :https://play.google.com/store/apps/details?id=com.cabe.driver',
      url: 'https://play.google.com/store/apps/details?id=com.cabe.driver',
    });
    if (result.action === Share.sharedAction) {
      if (result.activityType) {
        // shared with activity type of result.activityType
      } else {
        // shared
      }
    } else if (result.action === Share.dismissedAction) {
      // dismissed
    }
  } catch (error) {
    alert(error.message);
  }
};

function GetInTouch({navigation}, props) {
  const getInTouchOptions = [
    {
      id: 1,
      optionTitle: 'Call Us',
      iconName: 'phone-dial',
      onPress: () => Linking.openURL('tel:+917208878771'),
    },
    {
      id: 2,
      optionTitle: 'E-Mail',
      iconName: 'email-plus',
      onPress: () => Linking.openURL('mailto:contact@cabecars.com'),
    },
    {
      id: 3,
      optionTitle: 'Privacy Policy',
      iconName: 'file-lock',
      onPress: () => navigation.navigate('PrivayPolicy'),
    },
    {
      id: 4,
      optionTitle: 'Terms & Conditions',
      iconName: 'file-check',
      onPress: () => navigation.navigate('TermCondition'),
    },
    {
      id: 5,
      optionTitle: 'My Charging Stations',
      iconName: 'ev-station',
      onPress: () => navigation.navigate('ChargingStation'),
    },
    // {
    //   id: 6,
    //   optionTitle: 'Location Information',
    //   iconName: 'map',
    //   onPress: () => Linking.openURL('tel:+917208878771'),
    // },
    {
      id: 6,
      optionTitle: 'Tell a Friend',
      iconName: 'share-variant',
      onPress: onShare,
    },
  ];
  const renderItem = ({item}) => {
    return (
      <View style={[styles.button, {backgroundColor: theme.color.primary}]}>
        <TouchableOpacity activeOpacity={0.7} onPress={item.onPress}>
          <View style={[styles.chargingButton, {height: getResHeight(50)}]}>
            <Text>
              <MIcon
                name={item.iconName}
                size={20}
                color="#fff"
                backgroundColor="transparent"></MIcon>
            </Text>
            <Text style={styles.hubNameText}>{item.optionTitle}</Text>
          </View>
        </TouchableOpacity>
      </View>
    );
  };

  return (
    <SafeAreaView style={{flex: 1}}>
      <Header
        containerStyle={{
          alignSelf: 'center',
          backgroundColor: '#ffffff',
        }}
        title={'Get In Touch'}
        backPress={() => {
          navigation.navigate('Home');
        }}
        {...props}
      />
      <View style={styles.container} {...props}>
        <ImageBackground
          source={backgroundimage}
          resizeMode="cover"
          style={{
            flex: 1,
            width: '100%',
            height: '100%',
          }}>
          <View style={styles.buttonContainer}>
            <FlatList
              data={getInTouchOptions}
              renderItem={renderItem}
              keyExtractor={item => item.id}
            />
          </View>
        </ImageBackground>
      </View>
    </SafeAreaView>
  );
}

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//   },

//   button: {
//     display: 'flex',
//     flexDirection: 'row',
//     gap: 20,
//     alignItems: 'center',
//     padding: 15,
//     borderRadius: 15,
//     justifyContent: 'center',
//     backgroundColor: '#000052',
//   },
//   buttonText: {
//     color: '#fff',

//     fontSize: 20,
//   },
//   chargingButton: {
//     display: 'flex',
//     flexDirection: 'row',
//     gap: 20,
//     alignItems: 'center',
//     padding: 15,
//     borderRadius: 10,
//     marginBottom: 10,
//     justifyContent: 'center',
//     backgroundColor: '#fff',
//     shadowColor: '#ddd',
//     elevation: 20,
//   },
//   chargingButtonText: {
//     color: '#000',

//     fontSize: 20,
//   },
//   buttonContainer: {
//     paddingVertical: 5,
//     paddingHorizontal: 10,
//   },
// });

export default GetInTouch;
