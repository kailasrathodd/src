// import {createAsyncThunk} from '@reduxjs/toolkit';
// import API from '../../APIs/RepositoryFactory';
// import {riderUpdate} from '../basicdetails';
// export const RideUpdateAPI = createAsyncThunk(
//   'RideUpdateAPI/RideUpdateAPI',
//   async (payload, thunkAPI) => {
//     try {
//       const response = await API.authRepository.RideUpdateAPI(payload);
//       if (response) {
//         thunkAPI.dispatch(riderUpdate(response.data));
//       }
//       return response.data.data;
//     } catch (error) {
//       console.tron.log('Error: ', error);
//     }
//   },
// );
