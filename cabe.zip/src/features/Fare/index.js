import {createSlice} from '@reduxjs/toolkit';

const fare = createSlice({
  name: 'fare',
  initialState: {
    fare: null,
  },
  reducers: {
    ridefare: (state, action) => {
      state.fare = action.payload;
    },
  },
});

export const {ridefare} = fare.actions;

export default fare.reducer;
