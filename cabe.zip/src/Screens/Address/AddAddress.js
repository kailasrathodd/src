import React, {useState} from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ActivityIndicator,
  Keyboard,
} from 'react-native';
import BottomSheet from 'react-native-simple-bottom-sheet';
import {useDispatch, useSelector} from 'react-redux';
import {getAddressAPI, addAddressAPI} from '../../features/Address/AddressAPI';
import Header from '../../Components/HeaderComp';
import {getFontSize, getResHeight} from '../../utility/responsive';
import theme from '../../theme';
import LiveLoacation from '../Map/liveLoacation';
// import LiveLocation from '../Map/liveLocation';

export default function AddAddress({navigation}, props) {
  const [addressName, setAddressName] = useState('');
  const [address, setAddress] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [addressNameError, setAddressNameError] = useState('');
  const [addressError, setAddressError] = useState('');

  const dispatch = useDispatch();
  const rider_id = useSelector(state => state.auth.user?._id);

  const getAddress = async () => {
    try {
      const payload = {rider_id};
      await dispatch(getAddressAPI(payload));
      navigation.navigate('Address');
    } catch (error) {
      console.error(error);
      Alert.alert('Something went wrong. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleAddAddress = async () => {
    try {
      // Perform validation
      Keyboard.dismiss();
      if (addressName.length < 4) {
        setAddressNameError('Address Name should have at least 4 alphabets.');
        return;
      } else {
        setAddressNameError('');
      }

      if (address.length < 4) {
        setAddressError('Address Details should have at least 4 alphabets.');
        return;
      } else {
        setAddressError('');
      }

      setIsLoading(true); // Start the loader
      const payload = {
        address: addressName,
        address_details: address,
        rider_id: rider_id,
      };

      const data = await dispatch(addAddressAPI(payload));
      if (data) {
        getAddress();
      }
    } catch (error) {
      console.error(error);
      Alert.alert('Something went wrong. Please try again.');
    } finally {
      setIsLoading(false); // Hide the loader
    }
  };

  return (
    <View style={{position: 'relative', height: '100%'}}>
      <Header
        containerStyle={{
          width: '100%',
          alignSelf: 'center',
        }}
        title={'Add New Address'}
        backPress={() => {
          navigation.navigate('Address');
        }}
        {...props}
      />
      <View
        style={{
          width: '100%',
          height: '100%',
          top: 0,
          position: 'absolute',
          zIndex: -111,
        }}>
        <LiveLoacation />
      </View>
      <View
        style={{
          position: 'absolute',
          bottom: 0,
          width: '100%',
          height: getResHeight(250),
        }}>
        <BottomSheet
          isOpen
          innerContentStyle={{
            width: '100%',
            height: '100%',
          }}
          sliderMaxHeight={460}>
          <View>
            <View
              style={{
                borderBottomWidth: 1,
                borderColor: '#ddd',
                paddingBottom: 20,
                justifyContent: 'center',
              }}>
              <Text
                style={{
                  fontSize: getFontSize(getFontSize(20)),
                  textAlign: 'center',
                  color: '#000',
                  fontWeight: 'bold',
                  marginTop: '5%',
                }}>
                Add Address
              </Text>
            </View>

            <View>
              <Text
                style={{
                  paddingLeft: 10,
                  color: '#000',
                  fontWeight: '800',
                  fontSize: getFontSize(20),
                }}>
                Address
              </Text>

              <TextInput
                value={addressName}
                onChangeText={setAddressName}
                placeholder="Address Name"
                style={{
                  width: '100%',
                  fontSize: getFontSize(15),
                  fontWeight: '600',
                  backgroundColor: '#ddd',
                  borderRadius: 12,
                  marginTop: '5%',
                  textAlign: 'auto',
                  padding: 15,
                  borderColor: addressNameError ? 'red' : '#ddd',
                }}
              />
              {addressNameError ? (
                <Text style={{color: 'red', marginLeft: '3%'}}>
                  {addressNameError}
                </Text>
              ) : null}
            </View>

            <View>
              <Text
                style={{
                  marginLeft: '3%',
                  color: '#000',
                  fontWeight: '800',
                  fontSize: getFontSize(20),
                  marginTop: '5%',
                }}>
                Address Details
              </Text>

              <TextInput
                value={address}
                onChangeText={setAddress}
                placeholder="Address Details"
                style={{
                  width: '100%',
                  fontSize: getFontSize(15),
                  fontWeight: '600',
                  backgroundColor: '#ddd',
                  borderRadius: 12,
                  marginTop: '8%',
                  textAlign: 'auto',
                  padding: 15,
                  borderColor: addressError ? 'red' : '#ddd',
                }}
              />
              {addressError ? (
                <Text style={{color: 'red', marginLeft: '3%'}}>
                  {addressError}
                </Text>
              ) : null}

              {isLoading ? (
                <ActivityIndicator
                  color={theme.color.primary}
                  size={35}
                  style={{
                    justifyContent: 'center',
                    flex: 1,
                    alignSelf: 'center',
                    alignContent: 'center',
                    alignItems: 'center',
                    marginTop: '5%',
                    // position: 'absolute',
                  }}
                />
              ) : (
                <TouchableOpacity
                  style={{
                    width: '100%',
                    alignItems: 'center',
                    justifyContent: 'center',
                    marginTop: '15%',
                    padding: 10,
                  }}
                  onPress={handleAddAddress}
                  disabled={isLoading}>
                  <Text
                    style={{
                      backgroundColor: isLoading ? '#ccc' : '#000055',
                      width: '100%',
                      textAlign: 'center',
                      fontSize: getFontSize(15),
                      borderRadius: 16,
                      padding: 14,
                      color: '#fff',
                      bottom: 11,
                      position: 'relative',
                    }}>
                    Add Address
                  </Text>
                </TouchableOpacity>
              )}
            </View>
          </View>
        </BottomSheet>
      </View>
    </View>
  );
}
