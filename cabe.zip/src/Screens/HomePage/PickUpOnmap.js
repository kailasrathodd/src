import {
  View,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  SafeAreaView,
  Image,
  FlatList,
  Alert,
} from 'react-native';
import React, {useEffect, useState} from 'react';
import {Searchbar} from 'react-native-paper';
import {useDispatch, useSelector} from 'react-redux';

import {getFontSize} from '../../utility/responsive';

import {getBasicDetailsAPI} from '../../features/basicdetails/basicdetail';
import theme from '../../theme';
import {ActivityIndicator} from 'react-native';
import MapplsPlacePicker from '../Map/MapplsPlacePicker';
export default function PickUpOnmap({navigation}, props) {
  const riderUpdate = useSelector(
    state => state.basicDetail?.riderUpdate?.Rider_Data,
  );
  const rider_id = useSelector(state => state.auth.user?._id);
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [accessToken, setAccessToken] = useState([]);
  const [query, setQuery] = useState('');
  const [search, setSearch] = useState('');
  const [filteredDataSource, setFilteredDataSource] = useState([]);
  const basicDetail = useSelector(state => state.basicDetail?.basicDetail);
  const [isVerifyLoading, setIsVerifyLoading] = useState(null);
  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(
      getBasicDetailsAPI({
        rider_id: rider_id,
      }),
    );
  }, []);
  const handleSend = () => {
    setIsVerifyLoading(true);
    const payload = {
      rider_id: rider_id,
    };

    dispatch(getBasicDetailsAPI(payload))
      .then(data => {
        if (data.payload.status === 200) {
          if (basicDetail && basicDetail?.drop_latitude !== '') {
            navigation.navigate('SearchDashboard');
          } else {
            navigateToHomeScreen();
          }

          setIsVerifyLoading(false);
        }
      })
      .catch(error => {
        setIsVerifyLoading(false);
        console.error(error);
        Alert.alert('something went wrong please try again');
      });
  };
  const searchFilterFunction = text => {
    if (text) {
      const newData = data?.filter(function (item) {
        const itemData = item.placeAddress
          ? item.placeAddress.toUpperCase()
          : ''.toUpperCase();
        const textData = text.toUpperCase();
        return itemData.indexOf(textData) > -1;
      });
      setFilteredDataSource(newData);
      setQuery(text || '');
    } else {
      setFilteredDataSource(data);
      setQuery(text || '');
    }
  };
  handleSearchClear = () => searchFilterFunction('');

  const navigateToHomeScreen = () => {
    navigation.reset({
      index: 1,
      routes: [{name: 'HomePage'}],
    });
  };

  return (
    <SafeAreaView
      style={{
        position: 'relative',
        height: '100%',
      }}>
      <View
        style={{
          width: '100%',
          height: '100%',
        }}>
        <MapplsPlacePicker />
      </View>
      <View
        style={{
          width: '90%',
          alignSelf: 'center',
          //   backgroundColor: '#fff',
          marginTop: '10%',
          borderRadius: 20,
          zIndex: 545,
          position: 'absolute',
          height: '15%',
        }}>
        <Searchbar
          icon
          placeholder="Choose Pick Up Address"
          onClear={text => searchFilterFunction(text)}
          multiline
          style={{
            // height: 100,
            width: '100%',
            position: 'absolute',
            padding: 5,

            borderColor: '#009688',
            backgroundColor: '#FFFFFF',

            elevation: 20,
            shadowColor: '#e2006A',
          }}
          editable={false}
          autoFocus={false}
          value={query || riderUpdate?.pickup_address}
        />
      </View>

      <TouchableOpacity
        style={{
          width: '100%',
          alignItems: 'center',
          justifyContent: 'center',
          bottom: '7%',
          zIndex: 55,
        }}
        onPress={handleSend}>
        {isVerifyLoading == true ? (
          <ActivityIndicator color={theme.color.primary} size={35} />
        ) : (
          <Text
            style={{
              backgroundColor: '#000055',
              width: '95%',
              textAlign: 'center',
              fontSize: getFontSize(14),
              borderRadius: 12,
              padding: 10,
              color: '#fff',
            }}>
            Done
          </Text>
        )}
      </TouchableOpacity>
    </SafeAreaView>
  );
}
