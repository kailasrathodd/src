import {Repository} from './Repository';

const searchParentCategory = 'searchParentCategory';
const FareCalCordinate = 'riderGetFareDetailsForRequest';
const RiderCreateToRide = 'riderCreateToRide';
const getDriver = 'getVehicledetails_driverDetails';
const GetRideDetail = 'getRideDetail';
const rideTimeOutAPI = 'rideTimeOutAPI';
const paymentAttributes = 'paymentAttributes';
const riderJourneyHistory = 'riderJourneyHistory';
const getDriveLoc = 'getDriverLocationForRideShow';

export default {
  RiderCreateToRide(payload) {
    return Repository.post(transformRoute(RiderCreateToRide), payload);
  },
  FareCalCordinate(payload) {
    return Repository.post(transformRoute(FareCalCordinate), payload);
  },
  searchParentCategory(payload) {
    return Repository.post(transformRoute(searchParentCategory), payload);
  },
  getDriver(payload) {
    return Repository.post(transformRoute(getDriver), payload);
  },
  rideTimeOutAPI(payload) {
    return Repository.post(transformRoute(rideTimeOutAPI), payload);
  },
  getDriveLoc(payload) {
    return Repository.post(transformRoute(getDriveLoc), payload);
  },
  paymentAttributes(payload) {
    return Repository.post(transformRoute(paymentAttributes), payload);
  },
  GetRideDetail(payload) {
    return Repository.get(transformRoute(`${GetRideDetail}/${payload}`));
  },
  riderJourneyHistory(payload) {
    return Repository.post(transformRoute(riderJourneyHistory), payload);
  },
};

const transformRoute = route => {
  return `/api/${route}`;
};
