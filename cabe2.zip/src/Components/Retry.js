/* eslint-disable react-native/no-inline-styles */
import React, {useState, useEffect} from 'react';
import {View, Text, TouchableOpacity} from 'react-native';
import theme from '../theme';
import {getFontSize} from '../utility/responsive';

const Retry = () => {
  const [countdown, setCountdown] = useState(40);

  useEffect(() => {
    let interval;
    if (countdown > 0) {
      interval = setInterval(() => {
        setCountdown(prevCountdown => prevCountdown - 1);
      }, 1000);
    }
    return () => {
      clearInterval(interval);
    };
  }, [countdown]);

  const handleResendOTP = () => {
    setCountdown(40);
  };

  const countdownTextStyle = {
    color: theme.color.grey2,
    fontSize: getFontSize(16),
    fontWeight: '900',
    justifyContent: 'center',
    alignSelf: 'center',
  };

  const greenDotStyle = {
    color: theme.color.GREEN_DOT,
    fontSize: getFontSize(16),
    fontWeight: '900',
    justifyContent: 'center',
    alignSelf: 'center',
    borderRadius: 105,
    textAlign: 'center',
  };

  const retryTextStyle = {
    color: theme.color.grey2,
    fontSize: getFontSize(18),
    fontWeight: '900',
    justifyContent: 'center',
    alignSelf: 'center',
  };

  const tryAgainTextStyle = {
    color: theme.color.primary,
    fontWeight: '900',
    fontSize: getFontSize(15),
  };

  const secondsToMinutes = seconds => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return {minutes, remainingSeconds};
  };

  const {minutes, remainingSeconds} = secondsToMinutes(countdown);
  const searchDriverText = 'Searching for Driver';

  const countdownText =
    countdown > 0 ? (
      <Text style={countdownTextStyle}>
        {searchDriverText}{' '}
        <Text style={greenDotStyle}>
          {minutes.toString().padStart(2, '0')}:
          {remainingSeconds.toString().padStart(2, '0')}
        </Text>
      </Text>
    ) : (
      <Text style={retryTextStyle}>
        Not found Driver?{' '}
        <TouchableOpacity onPress={handleResendOTP}>
          <Text style={tryAgainTextStyle}>Try again</Text>
        </TouchableOpacity>
      </Text>
    );

  return <View style={{marginTop: '2%'}}>{countdownText}</View>;
};

export default React.memo(Retry);
