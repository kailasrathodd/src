import {createSlice} from '@reduxjs/toolkit';

const reviewQuestions = createSlice({
  name: 'reviewQuestions',
  initialState: {
    reviewQuestions: null,
  },
  reducers: {
    reviewQuestion: (state, action) => {
      state.reviewQuestions = action.payload;
    },
  },
});

export const {reviewQuestion} = reviewQuestions.actions;

export default reviewQuestions.reducer;
