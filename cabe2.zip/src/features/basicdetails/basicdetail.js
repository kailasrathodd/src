import {createAsyncThunk} from '@reduxjs/toolkit';
import API from '../../APIs/RepositoryFactory';
import * as basicDetail from './index';

import {
  User,
  login,
  onBoarding,
  userDetail,
  userLog,
  riderLogout,
  authApi,
} from '../auth/authAPI';
import {setSession} from '../auth';
import {setUserSession} from '../../config/session';
import {store} from '../../store';
// import { login } from '../auth';

export const razorpayOrderCreate = createAsyncThunk(
  'razorpayOrderCreate/razorpayOrderCreate',
  async (payload, thunkAPI) => {
    try {
      const response = await API.authRepository.razorpayOrderCreate(payload);
      console.log(response);
      if (response.data.status == 200) {
        thunkAPI.dispatch(basicDetail.razorpayOrderCreate(response.data.data));
        console.log('response.data.data', response.data.data);
      }
      if (response.data.status == 201) {
        thunkAPI.dispatch(basicDetail.basicDetails(response.data));
      }
      // console.log(response.data.status);
      return response.data;
    } catch (err) {
      err;
    }
  },
);
export const getBasicDetailsAPI = createAsyncThunk(
  'getBasicDetailsAPI/getBasicDetailsAPI',
  async (payload, thunkAPI) => {
    try {
      const response = await API.authRepository.getUser(payload);
      if (store.getState().auth.onBoarding == true) {
        // console.tron.log('response.data.status', response);
        if (response.data.status == 200) {
          thunkAPI.dispatch(basicDetail.basicDetails(response.data.data));
        }
      } // console.log(response.data.status);
      return response;
    } catch (err) {
      err;
    }
  },
);

export const riderCanclledToRide = createAsyncThunk(
  'riderCanclledToRide/riderCanclledToRide',
  async (payload, thunkAPI) => {
    try {
      const response = await API.authRepository.riderCanclledToRide(payload);
      console.tron.log(response.data.status);
      if (response.data.status == 200) {
        thunkAPI.dispatch(basicDetail.rideCancel(response.data.data));
      }
      return response.data;
    } catch (error) {
      error;
    }
  },
);
export const RideTimeOutWithId = createAsyncThunk(
  'RideTimeOutWithId/RideTimeOutWithId',
  async (payload, thunkAPI) => {
    try {
      const response = await API.authRepository.RideTimeOutWithId(payload);
      console.tron.log(response.data.status);
      if (response.data.status == 200) {
        thunkAPI.dispatch(basicDetail.rideCancel(response.data.data));
      }
      return response.data;
    } catch (error) {
      error;
    }
  },
);

export const riderCancelAPI = createAsyncThunk(
  'riderCancelAPI/riderCancelAPI',
  async (payload, thunkAPI) => {
    try {
      const response = await API.authRepository.RiderCancel(payload);
      console.tron.log(response.data.status);
      if (response) {
        thunkAPI.dispatch(basicDetail.rideCancel(response.data.data));
      }
      return response.data;
    } catch (error) {
      error;
    }
  },
);
export const ProfileAPI = createAsyncThunk(
  'ProfileAPI/ProfileAPI',
  async (payload, thunkAPI) => {
    try {
      const response = await API.authRepository.ProfileUpdateAPI(payload);
      if (response.data.status === 200) {
        thunkAPI.dispatch(basicDetail.Profile(response.data.data));
      }
      return response.data;
    } catch (error) {
      error;
    }
  },
);
export const ProfileUpdateAPI = createAsyncThunk(
  'ProfileUpdateAPI/ProfileUpdateAPI',
  async (payload, thunkAPI) => {
    try {
      const response = await API.authRepository.ProfileUpdate(payload);
      // console.tron.log('response to done: ', response.data.status === 200);
      if (response.data.status === 200) {
        thunkAPI.dispatch(basicDetail.Profile(response.data.data));
      }
      return response.data;
    } catch (error) {
      error;
    }
  },
);
export const getElocTotPickUpAPI = createAsyncThunk(
  'getElocTotPickUpAPI/getElocTotPickUpAPI',
  async (payload, thunkAPI) => {
    // console.tron.log('response to done: ', payload);
    try {
      const response = await API.authRepository.getElocTotPickUpAPI(payload);
      if (response) {
        thunkAPI.dispatch(basicDetail.getElocPickup(response?.data));
      }
      // return console.tron.log('response to done: ', response.data);
      return response.data;
    } catch (error) {
      error;
    }
  },
);
export const getElocTotDropAPI = createAsyncThunk(
  'getElocTotDropAPI/getElocTotDropAPI',
  async (payload, thunkAPI) => {
    // console.tron.log('response to done: ', payload);
    try {
      const response = await API.authRepository.getElocTotDropAPI(payload);
      if (response) {
        thunkAPI.dispatch(basicDetail.getElocTotDropAPI(response.data));
      }
      // return console.tron.log('response to done: ', response);
      return response;
    } catch (error) {
      error;
    }
  },
);
export const eLocPick = createAsyncThunk(
  'eLocPick/eLocPick',
  async (payload, thunkAPI) => {
    // console.tron.log('response to done: ', payload);
    try {
      const response = await API.authRepository.eloc_to_coordinate(payload);
      if (response) {
        thunkAPI.dispatch(
          basicDetail.eLocPick(response.data || response?.data.data),
        );
      }
      return response;
    } catch (error) {
      error;
    }
  },
);
export const eLocDrop = createAsyncThunk(
  'eLocDrop/eLocDrop',
  async (payload, thunkAPI) => {
    // console.tron.log('response to done: ', payload);
    try {
      const response = await API.authRepository.eloc_to_coordinate(payload);
      if (response) {
        thunkAPI.dispatch(basicDetail.eLocDrop(response.data));
      }
      return response;
    } catch (error) {
      error;
    }
  },
);

export const RideUpdateAPI = createAsyncThunk(
  'RideUpdateAPI/RideUpdateAPI',
  async (payload, thunkAPI) => {
    try {
      const response = await API.authRepository.RideUpdateAPI(payload);

      if (response.data.status === 200) {
        // console.log(response);
        thunkAPI.dispatch(basicDetail.riderUpdate(response.data));
      }
      return response;
    } catch (error) {
      error;
    }
  },
);
export const ridePaymentAPI = createAsyncThunk(
  'hub/ridePaymentAPI',
  async (payload, thunkAPI) => {
    try {
      const response = await API.authRepository.RidePayment(payload);
      if (response) {
        console.tron.log('Payment Done');
        return response;
      }
    } catch (error) {
      // console.log('Toll Amount Error', error);
    }
  },
);

export const getRiderStatus = createAsyncThunk(
  'getRiderStatus/getRiderStatus',
  async (payload, thunkAPI) => {
    try {
      const response = await API.authRepository.getRiderStatus(payload);
      if (response) {
        thunkAPI.dispatch(userDetail(await response.data.data));
      }
      return response.data.data;
    } catch (error) {
      error;
    }
  },
);
export const authAPI = createAsyncThunk(
  'authApi/authApi',
  async (payload, thunkAPI) => {
    try {
      const response = await API.authRepository.auth(payload);
      if (response) {
        thunkAPI.dispatch(authApi(await response.data?.data));
      }
      return response.data?.data;
    } catch (error) {
      error;
    }
  },
);
export const riderLogoutAPI = createAsyncThunk(
  'riderLogoutAPI/riderLogoutAPI',
  async (payload, thunkAPI) => {
    try {
      const response = await API.authRepository.riderLogout(payload);
      if (response) {
        thunkAPI.dispatch(riderLogout(await response.data.data));
      }
      return response.data;
    } catch (error) {
      error;
    }
  },
);
export const loginAPI = createAsyncThunk(
  'loginAPI/loginAPI',
  async (payload, thunkAPI) => {
    try {
      const response = await API.authRepository.Login(payload);
      if (response.status == 200) {
        thunkAPI.dispatch(userLog(await response.data.data));
      }
      return response.data;
    } catch (error) {
      return null;
    }
  },
);
// export const otpVerifyAPI = createAsyncThunk(
//   'otpVerifyAPI/otpVerifyAPI',
//   async (payload, thunkAPI) => {
//     try {
//       const response = await API.authRepository.verifyOTP(payload);
//       if (response) {
//         thunkAPI.dispatch(login(await response.data.data));
//         thunkAPI.dispatch(UserData(await response.data.data));

//         await thunkAPI.dispatch(setUserSession(true));
//         thunkAPI.dispatch(setSession(true));
//         thunkAPI.dispatch(onBoarding(true));
//       }
//       return response.data;
//     } catch (error) {
//       error
//     }
//   },
// );
export const otpVerifyAPI = createAsyncThunk(
  'otpVerifyAPI/otpVerifyAPI',
  async (payload, thunkAPI) => {
    try {
      const response = await API.authRepository.verifyOTP(payload);
      if (response) {
        thunkAPI.dispatch(login(await response.data.data));
        thunkAPI.dispatch(UserData(await response.data.data));

        await thunkAPI.dispatch(setUserSession(true));
        thunkAPI.dispatch(setSession(true));
        thunkAPI.dispatch(onBoarding(true));
      }
      return response.data;
    } catch (error) {
      error;

      // Handle invalid OTP error
      if (error.response && error.response.status === 422) {
        return response;
      }
      throw error;
    }
  },
);
