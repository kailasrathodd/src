import {
  StyleSheet,
  Text,
  View,
  Alert,
  Share,
  Button,
  Image,
  ScrollView,
  Linking,
  Dimensions,
  Modal,
  Pressable,
  TextInput,
  SafeAreaView,
} from 'react-native';
import React, {useEffect, useState} from 'react';
import BottomSheet from 'react-native-simple-bottom-sheet';
import {TouchableOpacity} from 'react-native-gesture-handler';

import {getFontSize, getResHeight} from '../../utility/responsive';
import Header from '../../Components/HeaderComp';
import LiveLoacation from '../Map/liveLoacation';
import {useDispatch, useSelector} from 'react-redux';
import LinearGradient from 'react-native-linear-gradient';

import {myDistance, myDuration} from '../../features/location/location';
import theme from '../../theme';
import GetDirection from '../../Components/GetDirection';
export default function AddAddress({navigation}, props) {
  const [fname, onChangeFname] = React.useState('');
  const [lname, onChangeLname] = React.useState('');
  const model = useSelector(state => state.rider?.onClickModel);
  const [durData, setDurData] = useState([]);
  const dispatch = useDispatch();
  const distance = durData.distance;
  const duration = durData.duration;
  useEffect(() => {
    distance, duration;

    dispatch(myDistance(durData.duration));
    dispatch(myDuration(durData.distance));
  }, [dispatch]);
  const handleData = data => {
    setDurData(data);
  };
  return (
    <View style={{position: 'relative', height: '100%'}}>
      <>
        <Header
          containerStyle={{
            width: '100%',
            alignSelf: 'center',
            marginLeft: '5%',
          }}
          backPress={() => {
            navigation.pop();
          }}
          {...this.props}
        />
        <View
          style={{
            position: 'absolute',
            bottom: 0,
            width: '100%',
            height: getResHeight(250),
          }}>
          <BottomSheet
            isOpen
            innerContentStyle={{
              width: '100%',
              height: '100%',
            }}
            sliderMaxHeight={460}>
            <View>
              <LinearGradient
                colors={['#8743FF', '#4136F1']}
                start={{x: 1, y: 0}}
                end={{x: 1, y: 1}}
                style={{
                  width: '100%',
                  alignSelf: 'center',
                  alignContent: 'center',
                  alignItems: 'center',
                  flexDirection: 'row',
                  borderBottomWidth: 1,
                  borderColor: '#ddd',
                  backgroundColor: '#ddd',
                  borderRadius: 25,
                  justifyContent: 'space-around',
                }}>
                <Image
                  style={{
                    width: 50,
                    height: 100,
                    margin: '10%',
                  }}
                  source={{uri: model[4] || ''}}
                />
                <Text
                  style={{
                    fontSize: getFontSize(getFontSize(20)),
                    textAlign: 'center',
                    color: '#FFF',
                    fontWeight: 'bold',
                  }}>
                  {model[2]}
                </Text>
              </LinearGradient>
              <View
                style={{
                  flexDirection: 'row',
                  marginTop: '5%',
                  justifyContent: 'space-between',
                  bottom: '2%',
                }}>
                <Text
                  style={{
                    paddingLeft: 10,
                    color: '#000',
                    fontWeight: '400',
                    fontFamily: theme.font.bold,
                    fontSize: getFontSize(15),
                  }}>
                  Capacity
                </Text>
                <Text
                  style={{
                    paddingLeft: 10,
                    color: '#000',
                    fontWeight: '400',
                    fontFamily: theme.font.bold,
                    fontSize: getFontSize(15),
                  }}>
                  {model[1]}
                </Text>
              </View>

              <View
                style={{
                  borderColor: '#ddd',

                  flexDirection: 'row',
                  justifyContent: 'space-between',
                }}>
                <Text
                  style={{
                    paddingLeft: 10,
                    color: '#000',
                    fontWeight: '400',
                    fontFamily: theme.font.bold,
                    fontSize: getFontSize(15),
                  }}>
                  Minimum Fare
                </Text>
                <Text
                  style={{
                    paddingLeft: 10,
                    color: '#000',
                    fontWeight: '400',
                    fontFamily: theme.font.bold,
                    fontSize: getFontSize(15),
                  }}>
                  100
                </Text>
              </View>
              <Text
                style={{
                  paddingLeft: 10,
                  color: '#000',
                  fontWeight: '400',
                  fontFamily: theme.font.regular,
                  fontSize: getFontSize(10),
                  marginTop: '5%',
                }}>
                {/* The fare will be The price presented upon booking or ,if the
                journey charges , the fare will be based on the rates provided */}
                The fare will be The price presented on booking . If the journey
                charges , the fare will be based on the rate provided
              </Text>
              <TouchableOpacity
                style={{
                  width: '100%',
                  alignItems: 'center',
                  justifyContent: 'center',
                  marginTop: '10%',
                  height: '60%',
                  // padding: 10,
                  bottom: '25%',
                }}
                onPress={() => navigation.navigate('SendRequest')}>
                <Text
                  style={{
                    backgroundColor: '#000055',
                    width: '100%',
                    textAlign: 'center',
                    fontSize: getFontSize(15),
                    // paddingVertical: 2,
                    borderRadius: 16,
                    padding: 14,
                    color: '#fff',

                    position: 'relative',
                  }}>
                  Done
                </Text>
              </TouchableOpacity>
            </View>
          </BottomSheet>
        </View>
      </>
      <View
        style={{
          width: '100%',
          height: '100%',
          top: 0,
          position: 'absolute',
          zIndex: -1,
        }}>
        <GetDirection {...props} onData={handleData} />
      </View>
    </View>
  );
}
