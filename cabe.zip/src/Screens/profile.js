import {
  StyleSheet,
  Text,
  View,
  Image,
  TextInput,
  TouchableOpacity,
} from 'react-native';
import React from 'react';
import {Avatar} from 'react-native-paper';
import {ScrollView} from 'react-native-gesture-handler';
import {useNavigation} from '@react-navigation/native';
function Profile(navigation) {
  const [fname, onChangeFname] = React.useState('Useless Text');
  const [lname, onChangeLname] = React.useState('Useless Text');
  const [mobile, onChangeMobile] = React.useState('Useless Text');
  const [email, onChangeEmail] = React.useState('Useless Text');
  return (
    <>
      <ScrollView>
        <View>
          <View style={{padding: 20}}>
            <View style={{justifyContent: 'center', alignItems: 'center'}}>
              <Avatar.Image
                source={{
                  uri: 'https://w7.pngwing.com/pngs/340/946/png-transparent-avatar-user-computer-icons-software-developer-avatar-child-face-heroes.png',
                }}
                size={150}
              />
            </View>

            <View>
              <View>
                <Text style={styles.inputlabel}>first Name</Text>
                <TextInput
                  placeholder="Jhon"
                  style={styles.input}
                  onChangeText={onChangeFname}
                  value={fname}
                />
              </View>
              <View>
                <Text style={styles.inputlabel}>Lat Name</Text>
                <TextInput
                  placeholder="Dhoe"
                  style={styles.input}
                  onChangeText={onChangeLname}
                  value={lname}
                />
              </View>
              <View>
                <Text style={styles.inputlabel}>Mobile</Text>
                <TextInput
                  placeholder="Mobile"
                  style={styles.input}
                  onChangeText={onChangeMobile}
                  value={mobile}
                />
              </View>
              <View>
                <Text style={styles.inputlabel}>Email</Text>
                <TextInput
                  placeholder="Email"
                  style={styles.input}
                  onChangeText={onChangeEmail}
                  value={email}
                />
              </View>
            </View>
          </View>
        </View>
      </ScrollView>
      <View>
        <TouchableOpacity
          style={{
            width: '100%',
            margin: 10,
            alignItems: 'center',
            justifyContent: 'center',
          }}
          onPress={() => navigation.navigate(ShowDriver)}>
          <Text
            style={{
              backgroundColor: '#000055',
              width: '80%',
              padding: 10,
              textAlign: 'center',
              fontSize: 25,
              paddingVertical: 20,
              borderRadius: 20,
              color: '#fff',
            }}>
            Edit Profile
          </Text>
        </TouchableOpacity>
      </View>
    </>
  );
}

export default Profile;

const styles = StyleSheet.create({
  inputlabel: {
    paddingLeft: 10,
    // color: '#000',
    fontWeight: '800',
    fontSize: 15,
  },
  input: {
    height: 40,
    margin: 12,
    borderWidth: 1,
    padding: 10,
  },
});
