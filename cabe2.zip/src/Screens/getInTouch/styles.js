import {StyleSheet} from 'react-native';
import {getFontSize, getResHeight, getResWidth} from '../../utility/responsive';
import theme from '../../theme';

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  hubNameText: {
    color: theme.color.WHITE,
    fontSize: getFontSize(theme.fontSizes.regular),
  },
  button: {
    width: '95%',
    borderRadius: getResWidth(10),
    marginVertical: getResHeight(8),
    backgroundColor: theme.color.WHITE,
    alignSelf: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  chargingButton: {
    flexDirection: 'row',
    gap: 20,
    alignItems: 'center',
    width: '90%',
    alignSelf: 'center',
    justifyContent: 'flex-start',
  },
  chargingButtonText: {
    color: '#000',
    fontSize: getFontSize(15),
  },
  buttonContainer: {
    flex: 1,
    backgroundColor: theme.color.WHITE,
    zIndex: 111,
  },

  // Privacy Policy and Term Condition

  contentContainer: {
    flex: 1,
    backgroundColor: '#fff',
  },
  activityIndicatorContainer: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#ffffff',
  },
});

export default styles;
