/* eslint-disable no-dupe-keys */
import {Image_Repository, Mapple_Repository, Repository} from './Repository';

const auth = 'auth-token';
const signup = 'RegisterAndOldRiderNewOtp';
const login = 'RegisterAndOldRiderNewOtp';
const accesstokenMapMyIndia = 'accesstokenMapMyIndia';
const verfiyotp = 'verifyWithOtp';
const generateotp = 'RegisterAndOldRiderNewOtp';
const getUser = 'getBasicDetails';
const profileUpdate = 'profileUpdate';
const getElocToLatLog = 'O2O/entity';
const getElocTotDropAPI = 'O2O/entity';
const updateData = 'updateDetails';
const getRiderStatus = 'getRiderStatus';

const razorpayOrderCreate = 'razorpayOrderCreate';
const riderCanclledToRide = 'riderCanclledToRide';
const RideTimeOutWithId = 'RideTimeOutWithId';
const RiderCancel = 'RiderCancel';
const riderLogout = 'riderLogout';
const RidePayment = 'PaymentDoneByCash';
const eloc_to_coordinate = 'eloc_to_coordinate';
export default {
  Login(payload) {
    return Repository.post(transformRoute(login), payload);
  },
  auth(payload) {
    return Repository.post(transformRoute(auth), payload);
  },
  Signup(payload) {
    return Repository.post(transformRoute(signup), payload);
  },
  generateotp(payload) {
    return Repository.post(transformRoute(generateotp), payload);
  },
  verifyOTP(payload) {
    return Repository.post(transformRoute(verfiyotp), payload);
  },
  getUser(payload) {
    return Repository.post(transformRoute(getUser), payload);
  },
  ProfileUpdate(payload) {
    return Image_Repository.post(transformRoute(profileUpdate), payload);
  },
  ProfileUpdateAPI(payload) {
    return Repository.post(transformRoute(profileUpdate), payload);
  },
  RideTimeOutWithId(payload) {
    return Repository.post(transformRoute(RideTimeOutWithId), payload);
  },

  riderCanclledToRide(payload) {
    return Repository.post(transformRoute(riderCanclledToRide), payload);
  },
  getElocTotPickUpAPI(payload) {
    return Mapple_Repository.get(
      transformRoute_mapple(getElocToLatLog + `/${payload}`),
    );
  },
  getElocTotDropAPI(payload) {
    return Mapple_Repository.get(
      transformRoute_mapple(getElocTotDropAPI + `/${payload}`),
    );
  },
  accesstokenMapMyIndia(payload) {
    return Repository.get(transformRoute(accesstokenMapMyIndia), payload);
  },
  RidePayment(payload) {
    return Repository.post(transformRoute(RidePayment), payload);
  },
  RideUpdateAPI(payload) {
    return Repository.post(transformRoute(updateData), payload);
  },
  getRiderStatus(payload) {
    return Repository.post(transformRoute(getRiderStatus), payload);
  },
  razorpayOrderCreate(payload) {
    return Repository.post(transformRoute(razorpayOrderCreate), payload);
  },
  RiderCancel(payload) {
    return Repository.post(transformRoute(RiderCancel), payload);
  },
  RiderCancel(payload) {
    return Repository.post(transformRoute(RiderCancel), payload);
  },
  eloc_to_coordinate(payload) {
    return Repository.get(transformRoute(eloc_to_coordinate + `/${payload}`));
  },
  riderLogout(payload) {
    return Repository.get(transformRoute(riderLogout + `/${payload}`));
  },
};
const transformRoute = route => {
  return `/api/${route}`;
};
const transformRoute_mapple = route => {
  return `/apis/${route}`;
};
