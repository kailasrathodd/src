import React, {Component} from 'react';
import {
  Alert,
  Text,
  SafeAreaView,
  View,
  Image,
  TouchableOpacity,
} from 'react-native';
import setVectorIcon from './VectorComponents';
import {getResHeight, getFontSize, getResWidth} from '../utility/responsive';

import Ionicons from 'react-native-vector-icons/dist/Ionicons';
import theme from '../theme';

class Header extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    const {percenteage, percTxtStyle} = this.props;
    const {title} = this.props;
    const {
      barLogo,
      menuPress,
      notificationPress,
      backPress,
      editPress,
      logoutPress,
      bookmarkPress,
      locationPress,
      addPress,
      filterPress,
      sharePress,
      PercentageText = '',
      isbookmarks,
    } = this.props;
    //Style
    const {
      containerStyle,
      leftContentStyle,
      centerContentStyle,
      rightContentStyle,
      menuStyle,
    } = this.props;
    return (
      <View
        style={[
          {
            width: '100%',
            opacity: 61,
            backgroundColor: 'rgba(0,0,0,0)',
            height: 50,
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'center',
            marginTop: '10%',
          },
          containerStyle,
        ]}>
        <View style={([leftContentStyle], {flexDirection: 'row'})}>
          {menuPress && (
            <TouchableOpacity onPress={menuPress}>
              {setVectorIcon({
                type: 'SimpleLineIcons',
                name: 'menu',
                size: 40,
                color: theme.color.primary,
              })}
            </TouchableOpacity>
          )}
          {this.props.backPress && (
            <TouchableOpacity
              onPress={this.props.backPress}
              style={{
                justifyContent: 'center',
                backgroundColor: theme.color.primary,
                borderRadius: 10,
                padding: 5,
                marginLeft: '5%',
              }}>
              {setVectorIcon({
                type: 'Ionicons',
                name: 'chevron-back',
                size: 25,
                color: theme.color.extraLight,
              })}
            </TouchableOpacity>
          )}
          <Text
            style={{
              color: theme.color.primary,
              fontFamily: theme.font.ExtraBold,
              fontSize: getFontSize(18),
              alignSelf: 'center',
              marginLeft: '5%',
              fontWeight: '900',
              fontStyle: 'normal',
              justifyContent: 'space-between',
              textAlign: 'center',
              // alignItems: 'center',
              // alignContent: 'center',
              // textAlignVertical: 'center',
              // marginLeft: '25%',
            }}
            adjustsFontSizeToFit
            numberOfLines={1}>
            {title}
          </Text>
        </View>
        <View
          style={
            ([centerContentStyle],
            {
              flexDirection: 'row',
              flex: 1,
              height: '100%',
            })
          }>
          {barLogo && (
            <Image
              source={require('../assets/img/logo.png')}
              style={[
                {
                  width: 120,
                  height: '70%',
                  alignSelf: 'center',
                  resizeMode: 'contain',
                },
              ]}
            />
          )}
        </View>
        <View
          style={
            ([rightContentStyle],
            {
              flexDirection: 'row',
              justifyContent: 'space-between',
              marginRight: '2%',
            })
          }>
          <View style={{}}>
            <Text
              style={{
                color: '#053C6D',
                fontFamily: theme.font.bold,
                fontSize: 16,
                marginTop: 5,
                textAlignVertical: 'center',
              }}>
              {PercentageText}
            </Text>
          </View>
          {/* Notifications */}
          {notificationPress && (
            <View
              style={{
                height: getResHeight(100),
                width: getResWidth(25),
                alignItems: 'center',
                justifyContent: 'center',
                marginLeft: '2%',
              }}>
              <TouchableOpacity onPress={notificationPress}>
                {setVectorIcon({
                  type: 'Ionicons',
                  name: 'notifications-outline',
                  size: 29,
                  color: theme.color.primary,
                })}
              </TouchableOpacity>
            </View>
          )}
          {bookmarkPress && (
            <TouchableOpacity onPress={bookmarkPress}>
              <View
                style={{
                  height: '90%',
                  width: 28,
                  alignItems: 'center',
                  justifyContent: 'center',
                }}>
                {isbookmarks ? (
                  <TouchableOpacity onPress={notificationPress}>
                    {setVectorIcon({
                      type: 'Ionicons',
                      name: 'bookmark',
                      size: 40,
                      color: theme.color.primary,
                    })}
                  </TouchableOpacity>
                ) : (
                  <Ionicons
                    name={'bookmark-outline'}
                    color={'#053C6D'}
                    size={20}
                    style={{}}
                  />
                )}
              </View>
            </TouchableOpacity>
          )}
          {editPress && (
            <TouchableOpacity onPress={editPress}>
              <View
                style={{
                  height: '90%',
                  width: 28,
                  marginTop: '10%',
                  alignItems: 'center',
                  justifyContent: 'center',

                  marginRight: '5%',
                }}>
                {setVectorIcon({
                  type: 'Entypo',
                  name: 'edit',
                  size: getFontSize(20),
                  color: theme.color.primary,
                })}
              </View>
            </TouchableOpacity>
          )}
          {logoutPress && (
            <TouchableOpacity onPress={logoutPress}>
              <View
                style={{
                  height: '100%',
                  width: 28,
                  marginTop: '10%',
                  alignItems: 'center',
                  justifyContent: 'center',
                  marginLeft: '-50%',
                }}>
                {setVectorIcon({
                  type: 'MaterialCommunityIcons',
                  name: 'logout',
                  size: getFontSize(25),
                  color: theme.color.primary,
                })}
              </View>
            </TouchableOpacity>
          )}
          {sharePress && (
            <TouchableOpacity onPress={sharePress}>
              <View
                style={{
                  height: '100%',
                  width: '100%',
                  alignItems: 'center',
                  justifyContent: 'center',
                }}>
                {setVectorIcon({
                  type: 'Entypo',
                  name: 'share',
                  size: getFontSize(25),
                  color: theme.color.primary,
                })}
              </View>
            </TouchableOpacity>
          )}
          {filterPress && (
            <TouchableOpacity onPress={filterPress}>
              <View
                style={{
                  height: '90%',
                  width: '100%',
                  alignItems: 'center',
                  justifyContent: 'center',
                }}>
                {setVectorIcon({
                  type: 'Ionicons',
                  name: 'filter-sharp',
                  size: getFontSize(25),
                  color: theme.color.primary,
                })}
              </View>
            </TouchableOpacity>
          )}

          {locationPress && (
            <TouchableOpacity
              style={
                {
                  // position:"absolute"
                }
              }
              onPress={locationPress}>
              {setVectorIcon({
                type: 'Ionicons',
                name: 'ios-location-sharp',
                size: getFontSize(30),
                color: 'red',
              })}
            </TouchableOpacity>
          )}
          {addPress && (
            <TouchableOpacity onPress={addPress}>
              <View
                style={{
                  height: '90%',
                  width: '100%',
                  alignItems: 'center',
                  justifyContent: 'center',
                }}>
                {setVectorIcon({
                  type: 'Entypo',
                  name: 'plus',
                  size: getFontSize(30),
                  color: theme.color.primary,
                })}
              </View>
            </TouchableOpacity>
          )}
        </View>
      </View>
    );
  }
}

export default Header;
