import {createAsyncThunk} from '@reduxjs/toolkit';
import API from '../../APIs/RepositoryFactory';
import * as reviewQuestions from './index';

export const reviewQuestionsAPI = createAsyncThunk(
  'reviewQuestionsAPI/reviewQuestionsAPI',
  async (payload, thunkAPI) => {
    try {
      const response = await API.reviewRepository.reviewQuestions(payload);
      //   console.tron.log(response.data.status);
      if (response.data.status == 200) {
        thunkAPI.dispatch(reviewQuestions.reviewQuestion(response.data?.data));
      }
      // if (response.data.status == 201) {
      //   thunkAPI.dispatch(reviewQuestions.reviewQuestion(response.data?.data));
      // }
      return response;
    } catch (error) {
      console.tron.log('sosAPI: ', error);
    }
  },
);
