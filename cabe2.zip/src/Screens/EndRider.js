import React, {useState} from 'react';
import {
  StyleSheet,
  Text,
  View,
  Alert,
  TouchableOpacity,
  Image,
} from 'react-native';
import {useSelector, useDispatch} from 'react-redux';
import RazorpayCheckout from 'react-native-razorpay';
import {ridePaymentAPI} from '../features/basicdetails/basicdetail';
import {GetRideDetail, CreateRide} from '../features/CreateToRide';

import CurrentLocation from '../Map/LiveLoc';
import {getFontSize} from '../utility/responsive';
import {razorpay_key_id} from '../config/constants';

export default function EndtoRider({navigation}) {
  const dispatch = useDispatch();
  const [modalVisible, setModalVisible] = useState(false);

  const rider_id = useSelector(state => state.auth.user);
  const basicDetail = useSelector(state => state?.basicDetail?.basicDetail);
  const payment = useSelector(state => state.rider?.payment);
  const rider = useSelector(state => state?.rider?.ride_id);
  const fare = useSelector(state => state.fare?.fare?.Fare_data);
  const [isPaid, setIsPaidLoading] = useState(null);
  const ride_amount = fare?.ride_amount || 550;

  const paymentUpdate = () => {
    dispatch(
      ridePaymentAPI({
        ride_id: rider,
        is_paid: 1,
      }),
    )
      .then(checkPaymentRequest => {
        if (checkPaymentRequest.payload.data.status === 200) {
          dispatch(CreateRide(null));
          dispatch(GetRideDetail(null));
          Alert.alert('Ride Payment successfully');
          navigation.navigate('RateDriver');
        } else {
          Alert.alert('Payment failed. Please try again.');
        }
      })
      .catch(error => {
        console.error(error);
        Alert.alert('Payment failed. Please try again.');
      });
  };

  return (
    <>
      <View>
        <View style={{height: '100%'}}>
          <CurrentLocation />
        </View>
        <View
          style={{
            margin: 20,
            backgroundColor: 'white',
            borderRadius: 20,
            padding: 35,
            width: '90%',
            height: 400,
            alignItems: 'center',
            shadowColor: '#000',
            shadowOffset: {
              width: 0,
              height: 1,
            },
            shadowOpacity: 0.25,
            shadowRadius: 4,
            elevation: 5,
            zIndex: 1,
            position: 'absolute',
            marginTop: '55%',
          }}>
          <Image
            style={{width: '60%', height: '60%'}}
            source={require('../../src/assets/img/marker.png')}
          />
          <Text style={styles.modalText}>
            You have Arrived at Your Destination
          </Text>

          {payment == 'Online' ? (
            <TouchableOpacity
              style={styles.button}
              onPress={() => {
                var options = {
                  description: 'Credits towards consultation',
                  image:
                    'https://cabe-bucket.s3.ap-south-1.amazonaws.com/cabe-logo.png',
                  currency: 'INR',
                  key: razorpay_key_id,

                  amount: Math.round(ride_amount) * 100,
                  order_id: '',
                  external: {
                    wallets: ['paytm'],
                  },
                  name: 'CABEEZ',
                  prefill: {
                    email: basicDetail && basicDetail.email,
                    contact: basicDetail && basicDetail.phone_number,
                    name:
                      basicDetail &&
                      basicDetail.first_name + ' ' + basicDetail.last_name,
                  },
                  theme: {color: '#000055'},
                };
                RazorpayCheckout.open(options)
                  .then(data => {
                    paymentUpdate();
                  })
                  .catch(error => {
                    Alert.alert(`Error: ${error.code} | ${error.description}`);
                  });
                RazorpayCheckout.onExternalWalletSelection(data => {
                  Alert.alert(
                    'External Wallet Selected: ${data.external_wallet}',
                  );
                });
              }}>
              <Text style={styles.textStyle}>Pay</Text>
            </TouchableOpacity>
          ) : (
            <TouchableOpacity
              style={styles.button}
              onPress={() => {
                dispatch(GetRideDetail(null));
                dispatch(CreateRide(null));
                navigation.navigate('RateDriver');
              }}>
              <Text style={styles.textStyle}>OK</Text>
            </TouchableOpacity>
          )}
        </View>
      </View>
    </>
  );
}

const styles = StyleSheet.create({
  button: {
    width: '90%',
    fontSize: getFontSize(15),
    borderRadius: 25,
    padding: 10,
    borderWidth: 1,
    borderColor: '#ececec',
    fontWeight: 'bold',
    backgroundColor: '#000055',
    alignSelf: 'center',
  },
  textStyle: {
    color: 'white',
    fontSize: 20,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  modalText: {
    fontSize: 18,
    color: '#000',
    fontWeight: '800',
    marginBottom: 15,
    textAlign: 'center',
  },
});
