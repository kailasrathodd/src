import {
  StyleSheet,
  View,
  Text,
  Button,
  Input,
  Image,
  TouchableOpacity,
  SafeAreaView,
} from 'react-native';

import React, {useState} from 'react';
import {Alert} from 'react-native/Libraries/Alert/Alert';
import {ScrollView, TextInput} from 'react-native-gesture-handler';

import {RadioButton} from 'react-native-paper';
import Header from '../../Components/HeaderComp';
import {getResHeight} from '../../utility/responsive';
import theme from '../../theme';
export default function UPI({navigation}, props) {
  const [checked, setChecked] = useState('first');

  return (
    <SafeAreaView style={{flex: 1, backgroundColor: '#fff'}}>
      <Header
        containerStyle={{
          width: '100%',
          alignSelf: 'center',
        }}
        title={'UPI'}
        backPress={() => {
          navigation.pop();
        }}
        {...this.props}
      />

      <View
        style={{
          width: '90%',
          alignSelf: 'center',

          flex: 1,
        }}>
        <Text
          style={{
            fontSize: getResHeight(14),
            fontWeight: '400',
            color: theme.color.grey0,
          }}>
          Select Payment Method you wand to use
        </Text>
        <Text style={{fontSize: 18}}>
          Pay via{' '}
          <Text
            style={{
              fontSize: getResHeight(13),
              fontWeight: '900',
              color: theme.color.primary,
            }}>
            UPI
          </Text>
        </Text>

        <TextInput
          placeholder="Enter Your UPI ID"
          style={{
            width: '100%',
            fontSize: getResHeight(13),
            fontWeight: '800',
            backgroundColor: '#ddd',
            borderRadius: 12,
            marginTop: '5%',
            textAlign: 'auto',
            padding: 15,
          }}
        />

        <View
          style={{
            flexDirection: 'row',
            width: '100%',
            backgroundColor: '#fff',
            justifyContent: 'space-between',
            marginTop: '12%',
            borderRadius: 10,
            padding: 10,
            alignContent: 'center',
            alignSelf: 'center',
            shadowColor: '#000',
            shadowOffset: {
              width: 0,
              height: 2,
            },
            shadowOpacity: 0.25,
            shadowRadius: 3.84,

            elevation: 5,
          }}>
          <Image
            source={require('../../assets/img/paymentmethods/phone-pay.png')}
            style={{
              width: 50,
              height: 10,
              padding: 25,
              resizeMode: 'contain',

              borderRadius: 100,
            }}
          />

          <Text
            style={{
              fontSize: 18,
              fontWeight: '800',
              color: '#000',
              marginRight: '30%',
              marginTop: '4%',
            }}>
            Phone Pay
          </Text>

          <RadioButton.Item
            value="first"
            status={checked === 'first' ? 'checked' : 'unchecked'}
            onPress={() => setChecked('first')}
          />
        </View>
        <View
          style={{
            flexDirection: 'row',
            width: '100%',
            backgroundColor: '#fff',
            justifyContent: 'space-between',
            marginTop: '12%',
            borderRadius: 10,
            padding: 10,
            alignContent: 'center',
            alignSelf: 'center',
            shadowColor: '#000',
            shadowOffset: {
              width: 0,
              height: 2,
            },
            shadowOpacity: 0.25,
            shadowRadius: 3.84,

            elevation: 5,
          }}>
          <Image
            source={require('../../assets/img/paymentmethods/gpay.png')}
            style={{
              width: 50,
              height: 10,
              padding: 25,
              resizeMode: 'contain',

              borderRadius: 100,
            }}
          />

          <Text
            style={{
              fontSize: 18,
              fontWeight: '800',
              color: '#000',
              marginRight: '30%',
              marginTop: '4%',
            }}>
            Google Pay
          </Text>
          <RadioButton.Item
            value="second"
            status={checked === 'second' ? 'checked' : 'unchecked'}
            onPress={() => setChecked('second')}
          />
        </View>

        <TouchableOpacity
          style={{
            width: '100%',
            alignItems: 'center',
            position: 'absolute',

            justifyContent: 'center',
            bottom: 10,
          }}
          onPress={() => navigation.navigate('TopUp')}>
          <Text
            style={{
              backgroundColor: '#000055',
              width: '100%',
              textAlign: 'center',
              fontSize: 18,
              borderRadius: 12,
              padding: 10,
              color: '#fff',
            }}>
            Continue
          </Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}
