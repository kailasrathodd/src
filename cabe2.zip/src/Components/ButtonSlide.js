import React, {useRef, useState} from 'react';
import {
  Text,
  View,
  Animated,
  PanResponder,
  StyleSheet,
  Alert,
} from 'react-native';
import {getFontSize, getResHeight, getResWidth} from '../utility/responsive';
import setVectorIcon from './VectorComponents';
import HomeScreen from '../Screens/HomePage/homeScreen';
import {useNavigation} from '@react-navigation/native';
import {useDispatch, useSelector} from 'react-redux';
import {ActivityIndicator} from 'react-native';
import {
  RideTimeOutWithId,
  riderCancelAPI,
} from '../features/basicdetails/basicdetail';
import {CreateRide, GetRideDetail, ride_id} from '../features/CreateToRide';
import Retry from './Retry';
export default function ButtonSlide(props) {
  const navigation = useNavigation();
  const pan = useRef(new Animated.ValueXY()).current;
  const [right, setRight] = React.useState(false);
  const dispatch = useDispatch();
  const _id = useSelector(state => state?.rider?.GetRideDetail?._id);
  const ride_idd = useSelector(state => state?.rider?.CreateRide?._id);
  // console.log('500000000000_id', _id, ride_id);
  const [isVerifyLoading, setIsVerifyLoading] = useState(null);
  const handleRide = () => {
    setIsVerifyLoading(true);

    const payload = {};

    dispatch(RideTimeOutWithId(payload))
      .then(data => {
        setIsVerifyLoading(false);
        if (data.payload.status === 200) {
          navigation.navigate('SearchingDriver');
        }
      })
      .catch(error => {
        setIsVerifyLoading(false);
        console.error(error);
        Alert.alert('something went wrong please try again');
      });
  };
  const panResponder = PanResponder.create({
    onStartShouldSetPanResponder: () => true,

    onPanResponderMove: Animated.event([null, {dx: pan.x}], {
      useNativeDriver: false,
    }),

    onPanResponderRelease: (e, gesture) => {
      if (gesture.dx > 60) {
        if (gesture.dx > 22) {
          setRight(true);
        }
        if (gesture.dx > 50) {
          dispatch(riderCancelAPI({ride_id: _id || ride_idd}))
            .then(data => {
              setIsVerifyLoading(false);
              if (data.payload.status === 200) {
                dispatch(GetRideDetail(null));
                dispatch(CreateRide(null));
                dispatch(ride_id(null));
                Alert.alert('Ride cancelled successfully');
                navigation.navigate(HomeScreen);
              }
            })
            .catch(error => {
              setIsVerifyLoading(false);
              console.error(error);
              Alert.alert('something went wrong please try again');
            });
        }
      } else {
        // Reset the button to its initial position
        Animated.spring(pan, {
          toValue: {x: 0, y: 0},
          useNativeDriver: false,
        }).start();
        if (gesture.dx > 24) {
          Alert.alert('Swipe left');
          setRight(false);
        }
      }
    },
  });

  return (
    <>
      {isVerifyLoading == true ? (
        <ActivityIndicator color={theme.color.extraLight} size={35} />
      ) : (
        <View
          style={{
            width: '90%',
            padding: 10,
            backgroundColor: '#fff',
            position: 'absolute',
            shadowColor: '#000',
            bottom: 15,
            borderRadius: 15,
            shadowOffset: {
              width: 0,
              height: 12,
            },
            shadowOpacity: 0.58,
            shadowRadius: 16.0,
            justifyContent: 'space-around',
            elevation: 24,
            flexDirection: 'row',
            alignSelf: 'center',
          }}>
          <Animated.View
            style={[styles.button, {transform: [{translateX: pan.x}]}]}
            {...panResponder.panHandlers}>
            {setVectorIcon({
              type: 'FontAwesome',
              name: 'times',
              color: '#fff',
              size: getFontSize(15),
            })}
          </Animated.View>

          <Text
            style={{
              fontSize: getFontSize(16),
              fontWeight: '600',
              justifyContent: 'center',
              alignSelf: 'center',
              textAlign: 'center',
              width: '80%',
              color: '#000',
              // opacity: 0.4,
            }}>
            {setVectorIcon({
              type: 'AntDesign',
              name: 'right',
              color: '#000',
              size: getFontSize(15),
            })}
            {setVectorIcon({
              type: 'AntDesign',
              name: 'right',
              color: '#000',
              size: getFontSize(15),
            })}
            {setVectorIcon({
              type: 'AntDesign',
              name: 'right',
              color: '#000',
              size: getFontSize(15),
            })}
            Cancel To Slide
          </Text>
        </View>
      )}
    </>
  );
}

const styles = StyleSheet.create({
  button: {
    borderRadius: getResHeight(100),
    width: getResHeight(30),
    height: getResHeight(30),
    backgroundColor: '#000055',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
