import React, {Component} from 'react';
import {Text, View, TouchableOpacity, StyleSheet} from 'react-native';
import MapplsGL from 'mappls-map-react-native';
import {DEFAULT_CENTER_COORDINATE} from '../utils/index';
// import // Toast from 'react-native-simple-// Toast';import {point} from '@turf/helpers';
import exampleIcon from '../assets/img/cab.png';

MapplsGL.setMapSDKKey('57ed4a46a04bb48819af047eede68cee'); //place your mapsdkKey
MapplsGL.setRestAPIKey('fa00fe4ec72020f44813576d13d6cd41'); //your restApiKey
MapplsGL.setAtlasClientId(
  '33OkryzDZsJ5zN81E9FCF9vruFDY_8wEJySBHTVN2YroM6YVpgCRG8GjfY_w_wHLGWA24P-wObVzK2I7yH0AtQ==',
); //your atlasClientId key
MapplsGL.setAtlasClientSecret(
  'lrFxI-iSEg_7x4WFo74p0-leBomnlnqQTpyHrd7f--g-2lk3ZpOOZwBvabvkCEVBSC1yny1ymG7pZN0FkXFrzi8og6fFRBF7',
); //your atlasClientSecret key
// MapplsGL.setAtlasGrantType('client_credentials');

const styles = {
  icon: {
    iconImage: exampleIcon,
    iconAllowOverlap: true,
    iconSize: 0.2,
    iconAnchor: 'bottom',
  },
};

class CustomMarkerActivity extends Component {
  render() {
    return (
      <View style={{flex: 1}}>
        <MapplsGL.MapView style={{flex: 1}}>
          <MapplsGL.Camera
            zoomLevel={12}
            centerCoordinate={DEFAULT_CENTER_COORDINATE}
          />

          <MapplsGL.ShapeSource
            id="symbolLocationSource"
            shape={point(DEFAULT_CENTER_COORDINATE)}>
            <MapplsGL.SymbolLayer
              id="symbolLocationSymbols"
              minZoomLevel={5}
              style={styles.icon}
            />
          </MapplsGL.ShapeSource>
        </MapplsGL.MapView>
      </View>
    );
  }
}

export default CustomMarkerActivity;
