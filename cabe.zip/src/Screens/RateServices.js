import React, {useState} from 'react';
import {useDispatch, useSelector} from 'react-redux';
import {
  StyleSheet,
  TouchableOpacity,
  Text,
  View,
  ScrollView,
  FlatList,
} from 'react-native';
import {Avatar} from 'react-native-paper';
import BottomSheet from 'react-native-simple-bottom-sheet';
import {Rating} from 'react-native-ratings';
import {getFontSize} from '../utility/responsive';
import LiveLoc from '../Map/LiveLoc';
import {CreateRide, GetRideDetail} from '../features/CreateToRide';

const RateServices = ({navigation}) => {
  const [selectedStars, setSelectedStars] = useState(0);

  const dispatch = useDispatch();
  const driverDetails = useSelector(state => state?.rider?.getDriver);

  function ratingCompleted(rating) {
    console.log('Rating is: ' + rating);
  }

  const fillColor = rating => {
    setSelectedStars(rating);
  };

  const renderItem = ({item}) => {
    return (
      <View style={styles.itemContainer}>
        <Text style={styles.itemLabel}>{item.label}</Text>
        <Rating
          imageSize={25}
          fractions
          jumpValue={0.5}
          onFinishRating={ratingCompleted}
          style={styles.rating}
        />
      </View>
    );
  };

  return (
    <View style={styles.container}>
      <LiveLoc />
      <View style={styles.bottomSheetContainer}>
        <BottomSheet
          isOpen // Assuming this prop controls the visibility of the BottomSheet
          innerContentStyle={{flex: 1}}
          sliderMaxHeight={960}
          height={'100%'}>
          <ScrollView>
            <View>
              <View style={styles.header}>
                <Text style={styles.headerText}>Rate Service</Text>
              </View>

              <View style={styles.flatListContainer}>
                <FlatList
                  data={[
                    {label: 'Was Your Ride Comfortable?'},
                    {label: 'Was the Car Clean and Hygienic ?'},
                    {label: 'Was the Cab Manager Courteous ?'},
                    {label: 'Did you feel safe during the Trip?'},
                    {label: 'Are Our Services a Value for Money?'},
                    {label: 'Was it easy to get a Cab?'},
                  ]}
                  keyExtractor={item => item.label}
                  renderItem={renderItem}
                />
              </View>
            </View>
            <View style={styles.buttonContainer}>
              <TouchableOpacity
                style={styles.cancelButton}
                onPress={() => navigation.navigate('HomeScreen')}>
                <Text style={styles.buttonText}>Cancel</Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={styles.submitButton}
                onPress={() => navigation.navigate('HomeScreen')}>
                <Text style={styles.buttonText}>Submit</Text>
              </TouchableOpacity>
            </View>
          </ScrollView>
        </BottomSheet>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    position: 'relative',
    height: '100%',
  },
  bottomSheetContainer: {
    height: '100%',
    flex: 1,
    zIndex: 1,
    position: 'absolute',
    width: '100%',
  },
  header: {
    borderBottomWidth: 1,
    borderColor: '#ddd',
  },
  headerText: {
    fontSize: 25,
    textAlign: 'center',
    color: '#000',
    fontWeight: 'bold',
  },
  flatListContainer: {
    width: '80%',
    marginVertical: 20,
  },
  itemContainer: {
    padding: 4,
    backgroundColor: '#fff',
  },
  itemLabel: {
    fontSize: 15,
    textAlign: 'left',
    color: '#000',
    fontWeight: 'bold',
  },
  rating: {
    alignSelf: 'flex-start',
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-evenly',
    padding: 5,
  },
  cancelButton: {
    backgroundColor: 'red',
    borderRadius: 10,
    width: '45%',
    justifyContent: 'center',
    height: 50,
  },
  submitButton: {
    backgroundColor: '#000055',
    borderRadius: 10,
    width: '45%',
    justifyContent: 'center',
    height: 50,
  },
  buttonText: {
    color: '#fff',
    textAlign: 'center',
  },
});

export default RateServices;
