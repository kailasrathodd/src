import { UPDATE_VALUE } from '../actions/common';

import { updateValue } from './reducer-function';

export default (state = {}, action) => {
  switch (action.type) {
    case UPDATE_VALUE: {
      const result = updateValue(action, state);
      return result;
    }

    default:
      return state;
  }
};
