import React, {useEffect, useState} from 'react';
import {FlatList, Text, TouchableOpacity, View} from 'react-native';
import LiveLoacation from '../Map/liveLoacation';
import HomePage from './HomePage';
import AntDesign from 'react-native-vector-icons/AntDesign';

import ClusteringActivity from '../Map/ClusteringActivity';
import DropLocation from '../Map/DropLocation';
import {Dropdown} from 'react-native-element-dropdown';
export default function PickLocation({navigation}) {
  const [vehicleModalData, setVehicleModalData] = React.useState([]);
  const [valueModal, setValueModal] = React.useState(null);

  const [dataSuccess, setDataSuccess] = React.useState([]);
  const fetchDataModal = async () => {
    const resp2 = await fetch('http://192.168.0.25:8000/api/chargingHub');
    const fetchModalData = await resp2.json();
    setDataSuccess(fetchModalData.data.success);
    setVehicleModalData(fetchModalData.data.data);
  };
  React.useEffect(() => {
    fetchDataModal();
  }, []);

  // const testVehicleModal = vehicleModalData;
  const renderItemModal = item => {
    return (
      <View
        style={{
          padding: 17,
          flexDirection: 'row',
          justifyContent: 'space-between',
          alignItems: 'center',
        }}>
        <Text
          style={{
            flex: 1,
            fontSize: 16,
          }}>
          {item.hub_name}
        </Text>
        {item._id === valueModal && (
          <AntDesign
            style={{
              padding: 17,
              flexDirection: 'row',
              justifyContent: 'space-between',
              alignItems: 'center',
            }}
            color="black"
            name="Safety"
            size={20}
          />
        )}
      </View>
    );
  };
  var its = [];
  if (dataSuccess == 201) {
    vehicleModalData.forEach(element => {
      if (element.hub_status === '1') {
        its.push(element);
      }
    });
  }

  return (
    <View
      style={
        {
          // flex: 1,
          // justifyContent: 'center',
          // alignItems: 'center',
        }
      }></View>
  );
}
