import * as React from 'react';
import {
  StyleSheet,
  Image,
  Text,
  Button,
  Linking,
  View,
  Share,
  Alert,
  TouchableOpacity,
} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import {IconButton} from 'react-native-paper';
import BottomSheet from 'react-native-simple-bottom-sheet';
import CurrentLocation from '../Map/LiveLoc';
import {Avatar} from 'react-native-paper';
import Icon2 from 'react-native-vector-icons/Ionicons';
import Icon3 from 'react-native-vector-icons/Feather';

function showAlert2() {
  Alert.alert('Ride Accepted');
}

const supportedURL = 'https://google.com';

// const OpenURLButton = ({url, children}) => {
//   const handlePress = React.useCallback(async () => {
//     // Checking if the link is supported for links with custom URL scheme.
//     const supported = await Linking.canOpenURL(url);

//     if (supported) {
//       await Linking.openURL(url);
//     } else {
//       Alert.alert(`Don't know how to open this URL: ${url}`);
//     }
//   }, [url]);

//   return (
//     <IconButton
//       icon={children}
//       iconColor="white"
//       size={20}
//       mode="contained"
//       onPress={handlePress}
//     />
//   );
// };

function RateCab({navigation}) {
  const [status, setStatus] = React.useState(false);
  // const onToggleSwitch = () => setIsSwitchOn(!isSwitchOn);
  const onToggleStatus = () => setStatus(!status);
  const refRBSheet = React.useRef();
  const refRBSheet2 = React.useRef();
  const [chevron, setChevron] = React.useState(false);
  // console.log(chevron);
  const toggleChevron = () => setChevron(!chevron);

  const [cancel, setCancel] = React.useState(false);
  const cancelToggle = () => setCancel(!cancel);

  const [arrived, setarrived] = React.useState(false);
  const arrivedToggle = () => setarrived(!arrived);
  function handleDrag() {
    console.log('Dragging...');
  }
  const [starColor, setStarColor] = React.useState(false);
  const [starColor2, setStarColor2] = React.useState(false);
  const [starColor3, setStarColor3] = React.useState(false);
  const [starColor4, setStarColor4] = React.useState(false);
  const [starColor5, setStarColor5] = React.useState(false);

  const fillColor = () => {
    setStarColor(!starColor);
    setStarColor2(false);
    setStarColor3(false);
    setStarColor4(false);
    setStarColor5(false);
  };
  const fillColor2 = () => {
    setStarColor(true);
    setStarColor2(!starColor2);
    setStarColor3(false);
    setStarColor4(false);
    setStarColor5(false);
  };
  const fillColor3 = () => {
    setStarColor(true);
    setStarColor2(true);
    setStarColor3(!starColor3);
    setStarColor4(false);
    setStarColor5(false);
  };
  const fillColor4 = () => {
    setStarColor(true);
    setStarColor2(true);
    setStarColor3(true);
    setStarColor4(!starColor4);
    setStarColor5(false);
  };
  const fillColor5 = () => {
    setStarColor(true);
    setStarColor2(true);
    setStarColor3(true);
    setStarColor4(true);
    setStarColor5(!starColor5);
  };

  const onShare = async () => {
    try {
      const result = await Share.share({
        title: 'App link',
        message:
          'Please install this app and stay safe , AppLink :https://play.google.com/store/apps/details?id=com.cabe.driver',
        url: 'https://play.google.com/store/apps/details?id=com.cabe.driver',
      });
      if (result.action === Share.sharedAction) {
        if (result.activityType) {
          // shared with activity type of result.activityType
        } else {
          // shared
        }
      } else if (result.action === Share.dismissedAction) {
        // dismissed
      }
    } catch (error) {
      alert(error.message);
    }
  };
  const panelRef = React.useRef(null);

  // const fillColor =
  return (
    <>
      <CurrentLocation />
      <BottomSheet ref={ref => (panelRef.current = ref)} wrapperStyle={{}}>
        <View style={{flex: 1, marginVertical: 20}}>
          <View
            style={{
              flex: 1,
              paddingVertical: 10,
              flexDirection: 'column',
            }}>
            <View
              style={{
                justifyContent: 'center',
                alignItems: 'center',
                marginVertical: 10,
              }}>
              <Text style={{fontSize: 20, color: '#000'}}>
                How was your rider?
              </Text>
            </View>
            <View
              style={{
                justifyContent: 'center',
                alignItems: 'center',
                marginVertical: 10,
              }}>
              <Text style={{fontSize: 28, color: '#000'}}>Rider Name</Text>
            </View>
            <View
              style={{
                flexDirection: 'row',
                justifyContent: 'center',
                alignItems: 'center',
                marginVertical: 10,
              }}>
              <TouchableOpacity onPressIn={() => fillColor()}>
                <Icon
                  name={starColor == true ? 'star' : 'star-outline'}
                  size={45}
                  color="#F5C000"
                />
              </TouchableOpacity>
              <TouchableOpacity onPressIn={() => fillColor2()}>
                <Icon
                  name={starColor2 == true ? 'star' : 'star-outline'}
                  size={45}
                  color="#F5C000"
                />
              </TouchableOpacity>
              <TouchableOpacity onPressIn={() => fillColor3()}>
                <Icon
                  name={starColor3 == true ? 'star' : 'star-outline'}
                  size={45}
                  color="#F5C000"
                />
              </TouchableOpacity>
              <TouchableOpacity onPressIn={() => fillColor4()}>
                <Icon
                  name={starColor4 == true ? 'star' : 'star-outline'}
                  size={45}
                  color="#F5C000"
                />
              </TouchableOpacity>
              <TouchableOpacity onPressIn={() => fillColor5()}>
                <Icon
                  name={starColor5 == true ? 'star' : 'star-outline'}
                  size={45}
                  color="#F5C000"
                />
              </TouchableOpacity>
            </View>

            <View style={{flex: 1, flexDirection: 'row'}}>
              {/* <ButtonComponent
                buttonText="RATE RIDER"
                textColor="#ffffff"
                textFontSize={25}
                style={styles.startButton}
                onPress={() => {
                  navigation.navigate('HomeScreen');
                }}
              /> */}
            </View>
            <View
              style={{
                flexDirection: 'row',
                justifyContent: 'center',
                alignItems: 'center',
                gap: 20,
              }}>
              <Text style={{fontSize: 15, fontWeight: 700}}>
                SHARE LINK TO GET RATING
              </Text>
              <View>
                <TouchableOpacity onPress={onShare}>
                  <IconButton
                    icon="share-variant"
                    iconColor="#ffffff"
                    size={20}
                    containerColor="#1c8adb"
                    mode="contained"
                  />
                </TouchableOpacity>
              </View>
            </View>
          </View>
        </View>
      </BottomSheet>
    </>
  );
}

export default RateCab;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  button: {
    borderColor: 'black',
    borderRadius: 50,
    borderWidth: 1,
    padding: 10,
  },
  startButton: {
    backgroundColor: '#3db24b',
    // backgroundColor: '#000052',

    width: '100%',
    alignItems: 'center',
    padding: 7,
    justifyContent: 'center',
    borderRadius: 25,
    marginVertical: 5,
  },
});
