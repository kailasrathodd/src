import {createSlice} from '@reduxjs/toolkit';

const Address = createSlice({
  name: 'Address',
  initialState: {
    getAddress: null,
    Address: null,
    deleteAddAddress: null,
    selectedAddAddress: null,
    editAddAddress: null,
    addAddress: null,
  },
  reducers: {
    getAddress: (state, action) => {
      state.getAddress = action.payload;
    },
    addAddress: (state, action) => {
      state.addAddress = action.payload;
    },

    deleteAddAddress: (state, action) => {
      state.deleteAddAddress = action.payload;
    },
    selectedAddAddress: (state, action) => {
      state.selectedAddAddress = action.payload;
    },
    editAddAddress: (state, action) => {
      state.editAddAddress = action.payload;
    },
  },
});

export const {
  getAddress,
  addAddress,
  editAddAddress,
  selectedAddAddress,
  deleteAddAddress,
} = Address.actions;

export default Address.reducer;
