import {
  StyleSheet,
  View,
  Text,
  Button,
  Input,
  Image,
  TouchableOpacity,
  SafeAreaView,
  StatusBar,
} from 'react-native';

import React, {useState} from 'react';
import {RadioButton} from 'react-native-paper';
import Header from '../../Components/HeaderComp';
import {getResHeight} from '../../utility/responsive';
export default function PaymentMethod({navigation}, props) {
  const [checked, setChecked] = useState('first');

  return (
    <SafeAreaView style={{flex: 1, backgroundColor: '#fff'}}>
      <StatusBar backgroundColor="#000055" barStyle="light-content" />
      <Header
        containerStyle={{
          width: '100%',
          alignSelf: 'center',
        }}
        title={'Payment Method'}
        backPress={() => {
          navigation.pop();
        }}
        {...this.props}
      />
      <View
        style={{
          width: '90%',
          alignSelf: 'center',

          flex: 1,
        }}>
        <Text style={{fontSize: 18, marginTop: '10%'}}>
          Select the paymentMethod you want to use
        </Text>
        <View
          style={{
            flexDirection: 'row',
            width: '100%',
            backgroundColor: '#fff',
            justifyContent: 'space-between',
            marginTop: '12%',
            borderRadius: 10,
            padding: 10,
            alignContent: 'center',
            alignSelf: 'center',
            shadowColor: '#000',
            shadowOffset: {
              width: 0,
              height: 2,
            },
            shadowOpacity: 0.25,
            shadowRadius: 3.84,

            elevation: 5,
          }}>
          <Image
            source={require('../../assets/img/paymentmethods/wallet.png')}
            style={{
              width: 40,
              height: 40,
              padding: 25,
              resizeMode: 'contain',

              borderRadius: 100,
            }}
          />

          <Text
            style={{
              fontSize: 18,
              fontWeight: '800',
              color: '#000',
              marginRight: '15%',
              marginTop: '4%',
            }}>
            Cab-E Wallet
          </Text>

          <RadioButton.Item
            value="wallet"
            status={checked === 'wallet' ? 'checked' : 'unchecked'}
            onPress={() => setChecked('wallet')}
          />
        </View>
        <View
          style={{
            flexDirection: 'row',
            width: '100%',
            backgroundColor: '#fff',
            justifyContent: 'space-between',
            marginTop: '12%',
            borderRadius: 10,
            padding: 10,
            alignContent: 'center',
            alignSelf: 'center',
            shadowColor: '#000',
            shadowOffset: {
              width: 0,
              height: 2,
            },
            shadowOpacity: 0.25,
            shadowRadius: 3.84,

            elevation: 5,
          }}>
          <Image
            source={require('../../assets/img/paymentmethods/brower.png')}
            style={{
              width: 40,
              height: 40,
              padding: 25,
              resizeMode: 'contain',

              borderRadius: 100,
            }}
          />

          <Text
            style={{
              fontSize: 18,
              fontWeight: '800',
              color: '#000',
              marginRight: '15%',
              marginTop: '4%',
            }}>
            Internet Banking
          </Text>

          <RadioButton.Item
            value="first"
            status={checked === 'first' ? 'checked' : 'unchecked'}
            onPress={() => setChecked('first')}
          />
        </View>
        <View
          style={{
            flexDirection: 'row',
            width: '100%',
            backgroundColor: '#fff',
            justifyContent: 'space-between',
            marginTop: '12%',
            borderRadius: 10,
            padding: 10,
            alignContent: 'center',
            alignSelf: 'center',
            shadowColor: '#000',
            shadowOffset: {
              width: 0,
              height: 2,
            },
            shadowOpacity: 0.25,
            shadowRadius: 3.84,

            elevation: 5,
          }}>
          <Image
            source={require('../../assets/img/paymentmethods/credit.png')}
            style={{
              width: 70,
              height: 10,
              padding: 25,
              resizeMode: 'contain',
              borderRadius: 100,
            }}
          />

          <Text
            style={{
              fontSize: 18,
              fontWeight: '800',
              color: '#000',
              marginRight: '25%',
              justifyContent: 'flex-start',
              marginTop: '4%',
            }}>
            Credit Card
          </Text>
          <RadioButton.Item
            value="second"
            status={checked === 'second' ? 'checked' : 'unchecked'}
            onPress={() => setChecked('second')}
          />
        </View>
        <View
          style={{
            flexDirection: 'row',
            width: '100%',
            backgroundColor: '#fff',
            justifyContent: 'space-between',
            marginTop: '12%',
            borderRadius: 10,
            padding: 10,
            alignContent: 'center',
            alignSelf: 'center',
            shadowColor: '#000',
            shadowOffset: {
              width: 0,
              height: 2,
            },
            shadowOpacity: 0.25,
            shadowRadius: 3.84,

            elevation: 5,
          }}>
          <Image
            source={require('../../assets/img/paymentmethods/credit.png')}
            style={{
              width: 70,
              height: 10,
              padding: 25,
              resizeMode: 'contain',
              borderRadius: 100,
            }}
          />

          <Text
            style={{
              fontSize: 18,
              fontWeight: '800',
              color: '#000',
              marginRight: '25%',
              justifyContent: 'flex-start',
              marginTop: '4%',
            }}>
            Debit Card
          </Text>
          <RadioButton.Item
            value="second"
            status={checked === 'Third' ? 'checked' : 'unchecked'}
            onPress={() => setChecked('Third')}
          />
        </View>
        <View
          style={{
            flexDirection: 'row',
            width: '100%',
            backgroundColor: '#fff',
            justifyContent: 'space-between',
            marginTop: '12%',
            borderRadius: 10,
            padding: 10,
            alignContent: 'center',
            alignSelf: 'center',
            shadowColor: '#000',
            shadowOffset: {
              width: 0,
              height: 2,
            },
            shadowOpacity: 0.25,
            shadowRadius: 3.84,

            elevation: 5,
          }}>
          <Image
            source={require('../../assets/img/paymentmethods/upi.png')}
            style={{
              width: 50,
              height: 10,
              padding: 25,
              resizeMode: 'contain',

              borderRadius: 100,
            }}
          />
          <Text
            style={{
              fontSize: 18,
              fontWeight: '800',
              color: '#000',
              marginRight: '45%',
              marginTop: '4%',
            }}>
            UPI
          </Text>
          <RadioButton.Item
            value="second"
            status={checked === 'Four' ? 'checked' : 'unchecked'}
            onPress={() => setChecked('Four')}
          />
        </View>

        <TouchableOpacity
          style={{
            width: '100%',
            alignItems: 'center',
            position: 'absolute',

            justifyContent: 'center',
            bottom: 10,
          }}
          onPress={() => navigation.navigate('UPI')}>
          <Text
            style={{
              backgroundColor: '#000055',
              width: '100%',
              textAlign: 'center',
              fontSize: getResHeight(13),
              borderRadius: 12,
              padding: 15,
              fontWeight: '700',
              color: '#fff',
            }}>
            Continue
          </Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}
