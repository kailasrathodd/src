import React, {useState, useEffect, useRef} from 'react';
import {
  Text,
  View,
  TouchableOpacity,
  FlatList,
  Image,
  ActivityIndicator,
  TextInput,
  Modal,
  Pressable,
  Alert,
} from 'react-native';
import MapplsGL from 'mappls-map-react-native';
import {point} from '@turf/helpers';
import Toast from 'react-native-simple-toast';
import {Searchbar} from 'react-native-paper';
import {
  RideUpdateAPI,
  eLocDrop,
  getBasicDetailsAPI,
  getElocTotDropAPI,
} from '../../features/basicdetails/basicdetail';
import {useDispatch, useSelector} from 'react-redux';
import theme from '../../theme';
import {getFontSize, getResWidth} from '../../utility/responsive';
// import HomePage from './HomePage';
import {resetPin} from '../../features/location/location';
import {debounce} from 'lodash';

const styles = {
  icon: {
    // iconImage: exampleIcon,
    iconAllowOverlap: true,
    iconSize: 0.2,
    iconAnchor: 'bottom',
  },
};

export default function DropSchedule({navigation}, props) {
  const timeoutRef = useRef(0);
  const cameraRef = useRef(null);
  const [query, setQuery] = useState('');
  const [placesList, setPlacesList] = useState([]);
  const [selectedPlace, setSelectedPlace] = useState([]);
  const [progressBar, setProgressBar] = useState(false);
  const [mapFlex, setMapFlex] = useState(1);
  const [mounted, setMounted] = useState(false);
  const rider_id = useSelector(state => state.auth.user?._id);
  const [modalVisible, setModalVisible] = React.useState('');
  const dispatch = useDispatch();
  const [isVerifyLoading, setIsVerifyLoading] = useState(null);
  const [eloc, setEloc] = useState(null);
  const [Address, setAddress] = useState(null);
  const coordinate = useSelector(state => state.basicDetail.eLocDrop);
  const [isLoading, setLoading] = useState(null);
  const Longitude = coordinate && coordinate?.longitude;
  const Latitude = coordinate && coordinate?.latitude;

  useEffect(() => {
    setMounted(true);
    callAutoSuggest('Mapmy');

    return () => {
      setMounted(false);
      clearTimeout(timeoutRef.current);
    };
  }, []);

  const debouncedCallAutoSuggest = debounce(text => {
    console.log('calling');
    callAutoSuggest(text.trim());
  }, 1000);

  const onTextChange = text => {
    setQuery(text);
    setProgressBar(true);

    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
    }

    timeoutRef.current = setTimeout(() => {
      debouncedCallAutoSuggest(text);
    }, 2000);
  };

  const RideUpdate = (Latitude, Longitude) => {
    setLoading(true);
    dispatch(
      RideUpdateAPI({
        drop_latitude: Latitude,
        drop_longitude: Longitude,
        rider_id: rider_id,
      }),
    )
      .then(data => {
        if (data.payload.status === 200) {
          dispatch(
            getBasicDetailsAPI({
              rider_id: rider_id,
            }),
          );

          setLoading(false);
          navigation.navigate('DirectionSchedule');
        }
      })
      .catch(error => {
        setLoading(false);
        console.error(error);
      });
  };

  const callAutoSuggest = text => {
    if (text.length > 2) {
      const arr = [];
      MapplsGL.RestApi.autoSuggest({
        query: text,
      })
        .then(data => {
          console.tron.log('Data', data);
          if (mounted) {
            console.log(data.suggestedLocations[0]);
            if (
              data.suggestedLocations !== undefined &&
              data.suggestedLocations.length > 0
            ) {
              for (let i = 0; i < data.suggestedLocations.length; i++) {
                arr.push([
                  data.suggestedLocations[i].placeName,
                  [
                    parseFloat(data.suggestedLocations[i].longitude),
                    parseFloat(data.suggestedLocations[i].latitude),
                  ],
                  data.suggestedLocations[i].placeAddress,
                  data.suggestedLocations[i].mapplsPin,
                  data.suggestedLocations[i],
                ]);
              }
              setPlacesList(arr);
              setProgressBar(false);
              setMapFlex(0);
            } else {
              Toast.show('No suggestions found', Toast.SHORT);
              setProgressBar(false);
            }
          }
        })
        .catch(error => {
          console.log(error.code, error.message);
          setProgressBar(false);
          Toast.show(error.message, Toast.SHORT);
        });
    } else if (text.length <= 2) {
      setPlacesList([]);
      setProgressBar(false);
      setMapFlex(1);
    }
  };

  const onPress = location => {
    cameraRef.current.setCamera({
      centerCoordinate: location,
      zoomLevel: 11,
      animationDuration: 500,
    });
    console.log([location[0], location[1]]);
    setSelectedPlace([location[0], location[1]]);
    setPlacesList([]);
    setMapFlex(1);
  };

  const renderSeparator = () => {
    return (
      <View
        style={{
          height: 1,
          backgroundColor: '#CED0CE',
          marginLeft: 25,
        }}
      />
    );
  };

  const renderItem =
    placesList.length > 0 ? (
      <>
        {isLoading == true ? (
          <ActivityIndicator
            color={theme.color.primary}
            size={35}
            style={{
              justifyContent: 'center',
              flex: 1,
              alignSelf: 'center',
              alignContent: 'center',
              alignItems: 'center',
              position: 'absolute',
            }}
          />
        ) : (
          <View
            style={{
              flex: 1,
              position: 'absolute',
              top: 70,
              left: 0,
              right: 0,
              backgroundColor: 'white',
              zIndex: 40,
              marginTop: '20%',
            }}>
            <FlatList
              data={placesList}
              ItemSeparatorComponent={renderSeparator}
              keyExtractor={(item, index) => item[0] + index}
              renderItem={({item}) => (
                <TouchableOpacity
                  style={{paddingLeft: 10, paddingBottom: 10, paddingRight: 5}}
                  onPress={async () => {
                    setLoading(true);
                    const eloc = item[3];
                    setEloc(eloc);
                    const drop_placeName = item[0];
                    const drop_placeAddress = item[2];
                    const newAddress = drop_placeName + drop_placeAddress;
                    setAddress(newAddress);

                    await dispatch(
                      RideUpdateAPI({
                        drop_address: drop_placeName + drop_placeAddress,
                        rider_id: await rider_id,
                        drop_details: item[4],
                      }),
                    )
                      .then(data => {
                        if (data.payload.status === 200) {
                          dispatch(eLocDrop(eloc))
                            .then(data => {
                              console.tron.log(
                                ' data.payload.data.latitude data.payload.data.longitude',
                                data.payload.data.latitude,
                                data.payload.data.longitude,
                              );
                              if (data.payload.status === 200) {
                                RideUpdate(
                                  data.payload.data.latitude,
                                  data.payload.data.longitude,
                                );
                              }
                            })
                            .catch(error => {
                              setLoading(false);
                              console.error(error);
                            });
                        }
                      })
                      .catch(error => {
                        setLoading(false);
                        console.error(error);
                      });
                  }}>
                  <View style={{flexDirection: 'row', alignItems: 'center'}}>
                    <View
                      style={{
                        flexDirection: 'column',
                        paddingStart: 10,
                        paddingEnd: 5,
                      }}>
                      <Text
                        style={{
                          fontSize: getFontSize(15),
                          fontWeight: theme.WEIGHT.FONT_WEIGHT_BOLD,
                        }}>
                        {item[0]}
                      </Text>
                      <Text
                        style={{
                          fontSize: getFontSize(11),
                          fontWeight: theme.WEIGHT.FONT_WEIGHT_MEDIUM,
                          marginTop: '2%',
                        }}>
                        {item[2]}
                      </Text>
                    </View>
                  </View>
                </TouchableOpacity>
              )}
            />
          </View>
        )}
      </>
    ) : null;

  return (
    <View style={{flex: 1, justifyContent: 'center'}}>
      <View
        style={{
          flexDirection: 'row',
          paddingLeft: 5,
          paddingRight: 5,
          justifyContent: 'center',
          alignContent: 'center',
          marginTop: '10%',
          flex: 1,
        }}>
        <Searchbar
          placeholder="Search Here Drop "
          onClear={text => searchFilterFunction(text)}
          style={{
            height: 50,

            borderColor: '#009688',
            backgroundColor: '#FFFFFF',
            width: '92%',
            elevation: 20,
            shadowColor: '#e200',
            zIndex: 55,
          }}
          autoFocus={true}
          onChangeText={text => onTextChange(text)}
          value={query || ''}
        />
      </View>
      <ActivityIndicator
        animating={progressBar}
        hidesWhenStopped={true}
        color="blue"
        style={{
          alignSelf: 'flex-end',

          borderRadius: 100,
          padding: 2,
          alignItems: 'flex-end',

          position: 'absolute',
          top: 51,
          right: 65,
          zIndex: 111,
          justifyContent: 'flex-end',
        }}
      />
      <TouchableOpacity
        style={{
          width: '30%',
          alignSelf: 'flex-start',
          marginLeft: '5%',
          borderRadius: 10,
          padding: 2,

          backgroundColor: '#000055',

          position: 'absolute',
          top: 100,
          zIndex: 111,
        }}
        onPress={() => {
          dispatch(resetPin(true));
          navigation.navigate('DropAddressPinonMap');
        }}>
        <Text
          style={{
            padding: 5,
            fontWeight: 700,
            fontSize: 12,
            color: '#fff',
            alignSelf: 'center',
          }}>
          choose on Map
        </Text>
      </TouchableOpacity>

      <Modal
        animationType="slide"
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => {
          setModalVisible(!modalVisible);
        }}>
        <View
          style={{
            flex: 1,
            backgroundColor: theme.color.BACKGROUND,
            justifyContent: 'center',
            alignItems: 'center',
          }}>
          <View
            style={{
              width: '85%',

              borderRadius: 10,
              flex: 1,
              maxHeight: 200,
            }}>
            <View
              style={{
                margin: 10,
                backgroundColor: 'white',
                borderRadius: getResWidth(20),
                padding: 35,
                alignItems: 'center',
                shadowColor: '#000',
                shadowOffset: {
                  width: 0,
                  height: 2,
                },
                shadowOpacity: 0.25,
                shadowRadius: 4,
                elevation: 5,
              }}>
              <Text
                style={{
                  marginVertical: 15,
                  textAlign: 'justify',
                  lineHeight: 22,
                  fontSize: getFontSize(20),
                  fontWeight: 'bold',
                  color: '#000',
                }}>
                Address
              </Text>
              <Text
                style={{
                  marginVertical: 15,
                  textAlign: 'justify',
                  lineHeight: 22,
                  fontSize: getFontSize(15),
                  fontWeight: 'bold',
                  color: '#000',
                }}>
                {/* {Address} */}
                {Address?.length > 80
                  ? Address.substring(0, 80) + '...'
                  : Address}
              </Text>
              {isVerifyLoading == true ? (
                <ActivityIndicator color={theme.color.primary} size={35} />
              ) : (
                <Pressable
                  style={{
                    backgroundColor: '#008000',
                    justifyContent: 'center',
                    alignItems: 'center',
                    borderRadius: getResWidth(20),
                    height: 40,
                    width: 270,
                    marginTop: '10%',
                  }}
                  onPress={async () => {
                    setIsVerifyLoading(true);
                    dispatch(
                      RideUpdateAPI({
                        drop_latitude: Latitude,
                        drop_longitude: Longitude,
                        rider_id: rider_id,
                      }),
                    )
                      .then(data => {
                        if (data.payload.status === 200) {
                          dispatch(
                            getBasicDetailsAPI({
                              rider_id: rider_id,
                            }),
                          );

                          setIsVerifyLoading(false);
                          navigation.navigate('DirectionSchedule');
                        }
                      })
                      .catch(error => {
                        setIsVerifyLoading(false);
                        console.error(error);
                      });
                  }}>
                  <Text
                    style={{
                      color: 'white',
                      fontWeight: 'bold',
                      textAlign: 'center',
                    }}>
                    OK
                  </Text>
                </Pressable>
              )}
            </View>
          </View>
        </View>
      </Modal>
      {renderItem}
    </View>
  );
}
