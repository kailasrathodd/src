import React, {useEffect} from 'react';
import {
  View,
  Text,
  SafeAreaView,
  ImageBackground,
  TouchableOpacity,
} from 'react-native';
import {Image} from 'react-native-elements';

const Splash = ({navigation}) => {
  // console.log('Navigation', navigation);
  // useEffect(() => {
  //   setTimeout(() => {
  //     navigation.navigate('Splash1');
  //   }, 1000);
  // }, []);
  return (
    <TouchableOpacity
      style={{
        flex: 1,
        backgroundColor: 'white',
      }}
      onPress={() => navigation.navigate('Splash1')}>
      <ImageBackground
        source={require('../../assets/img/backgraound.png')}
        resizeMode="cover"
        style={{
          flex: 1,
          width: '100%',
          height: '100%',
          alignItems: 'center',
          justifyContent: 'space-between',
        }}>
        <View
          style={{
            justifyContent: 'center',
            alignItems: 'center',
            top: 50,
            flex: 1,
          }}>
          <Image
            source={require('../../assets/img/logo.png')}
            style={{width: 200, height: 100}}
          />
        </View>
        <View style={{justifyContent: 'center', alignItems: 'center', flex: 3}}>
          <Image
            source={require('../../assets/img/car_reg.png')}
            style={{width: 450, height: 200}}
          />
        </View>
      </ImageBackground>
    </TouchableOpacity>
  );
};

export default Splash;
