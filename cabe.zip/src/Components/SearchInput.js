import React, {useState} from 'react';
import {TextInput, View} from 'react-native';

const SearchInput = ({onSearch}) => {
  const [query, setQuery] = useState('');

  const handleSearch = () => {
    onSearch(query);
  };

  return (
    <View>
      <TextInput
        placeholder="Search"
        value={query}
        onChangeText={setQuery}
        onSubmitEditing={handleSearch}
      />
    </View>
  );
};

export default SearchInput;
