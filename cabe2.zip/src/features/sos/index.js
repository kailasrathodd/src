import {createSlice} from '@reduxjs/toolkit';

const sos = createSlice({
  name: 'sos',
  initialState: {
    sos: null,
  },
  reducers: {
    sosNumber: (state, action) => {
      state.sos = action.payload;
    },
  },
});

export const {sosNumber} = sos.actions;

export default sos.reducer;
