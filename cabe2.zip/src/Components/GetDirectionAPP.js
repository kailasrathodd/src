import React, {useEffect, useState} from 'react';
import {View, StyleSheet, ActivityIndicator} from 'react-native';
import MapplsGL from 'mappls-map-react-native';
import Polyline from 'mappls-polyline';
import {Platform} from 'react-native';
import {point} from '@turf/helpers';
import exampleIcon from '../assets/img/Pin.png';
import circle from '../assets/img/circle.png';
import {connect, useSelector} from 'react-redux';
import MyContext from '../utility/MyContext';
import {myDistance, myDuration} from '../features/location/location';

const styles = {
  icon: {
    iconImage: exampleIcon,
    iconAllowOverlap: true,
    iconSize: 0.25,
    iconAnchor: 'bottom',
  },
  circle: {
    iconImage: circle,
    iconAllowOverlap: true,
    iconSize: 0.3,
    iconAnchor: 'bottom',
  },
};

const layerStyles = {
  route: {
    lineColor: 'red',
    lineCap: 'round',
    lineJoin: 'round',
    lineWidth: 3,
    lineGradient: [
      'interpolate',
      ['linear'],
      ['line-progress'],
      0,
      ' #000',
      1,
      ' #000',
    ],
  },
};

const GetDirectionAPP = ({basicDetail}) => {
  const [distance, setDistance] = useState('');
  const [duration, setDuration] = useState('');
  const [route, setRoute] = useState('');
  const [center, setCenter] = useState([72.8482, 19.203767]);

  const [markerSourceCoordinates, setMarkerSourceCoordinates] = useState([
    basicDetail.pickup_longitude,
    basicDetail.pickup_latitude,
  ]);
  const [markerDestCoordinates, setMarkerDestCoordinates] = useState([
    basicDetail.drop_longitude,
    basicDetail.drop_latitude,
  ]);

  useEffect(() => {
    const sourceCoordinates = `${basicDetail.pickup_longitude},${basicDetail.pickup_latitude}`;
    const destinationCoordinates = `${basicDetail.drop_longitude},${basicDetail.drop_latitude}`;
    const callApi = async setProfile => {
      try {
        const data = await MapplsGL.RestApi.direction({
          origin: sourceCoordinates,
          destination: destinationCoordinates,
          profile: setProfile,
          overview: MapplsGL.RestApi.DirectionsCriteria.OVERVIEW_FULL,
          geometries: 'polyline6',
          alternatives: true,
          steps: true,
          traffic: true,
        });

        const routeGeoJSON = Polyline.toGeoJSON(data.routes[0].geometry, 6);
        setDistance(getFormattedDistance(data.routes[0].distance));
        setDuration(getFormattedDuration(data.routes[0].duration));
        setRoute(routeGeoJSON);
        setCenter(routeGeoJSON.coordinates[0]);
      } catch (error) {
        console.tron.log(error);
        // Toast.show(error.message, Toast.SHORT);
      }
    };

    callApi('driving');
    setMarkerSourceCoordinates([
      basicDetail.pickup_longitude,
      basicDetail.pickup_latitude,
    ]);
    setMarkerDestCoordinates([
      basicDetail.drop_longitude,
      basicDetail.drop_latitude,
    ]);
  }, [basicDetail]);

  const getFormattedDistance = distance => {
    if (distance / 1000 < 1) {
      return distance + 'M.';
    }
    const dis = (distance / 1000).toFixed(2);
    return dis + 'Km.';
  };

  const getFormattedDuration = duration => {
    const min = parseInt(duration / 60);
    return min;
  };

  const destMarker =
    basicDetail?.drop_address !== '' &&
    basicDetail?.pickup_address !== '' &&
    route ? (
      <MapplsGL.ShapeSource
        id="symbolLocationSource"
        shape={point(markerDestCoordinates)}>
        <MapplsGL.SymbolLayer
          id="symbolLocationSymbols"
          minZoomLevel={1}
          style={styles.icon}
        />
      </MapplsGL.ShapeSource>
    ) : null;

  const routeMaker =
    basicDetail?.drop_address !== '' &&
    basicDetail?.pickup_address !== '' &&
    route ? (
      <MapplsGL.ShapeSource id="routeSource" shape={route}>
        <MapplsGL.LineLayer id="routeFill" style={layerStyles.route} />
      </MapplsGL.ShapeSource>
    ) : null;

  const sourceMarker =
    basicDetail?.drop_address !== '' &&
    basicDetail?.pickup_address !== '' &&
    route ? (
      <MapplsGL.ShapeSource
        id="symbolLocationSource2"
        shape={point(markerSourceCoordinates)}>
        <MapplsGL.SymbolLayer
          id="symbolLocationSymbols2"
          minZoomLevel={1}
          style={styles.circle}
        />
      </MapplsGL.ShapeSource>
    ) : null;

  if (route === '') {
    return (
      <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
        <ActivityIndicator animating={true} />
      </View>
    );
  }

  return (
    <MyContext.Provider value={{distance, duration}}>
      <View style={{flex: 1}}>
        <MapplsGL.MapView style={{flex: 1}}>
          <MapplsGL.Camera zoomLevel={12} centerCoordinate={center} />

          {sourceMarker}
          {routeMaker}
          {destMarker}
        </MapplsGL.MapView>
      </View>
    </MyContext.Provider>
  );
};

const style = StyleSheet.create({
  buttons: {justifyContent: 'center', alignItems: 'center', flex: 1},
  text: {fontWeight: 'bold'},
});

const mapDispatchToProps = dispatch => {
  return {
    myDistance: payload => dispatch(myDistance(payload)),
    myDuration: payload => dispatch(myDuration(payload)),
  };
};

const mapStateToProps = (state, props) => ({
  pickUpLocation: state.location.pickUpLocation,
  dropLocation: state.location.dropLocation,
  drop: state.location.AddressPinDrop,
  pickUp: state.location.AddressPinPickUP,
  basicDetail: state.basicDetail.basicDetail,
});

export default connect(mapStateToProps, mapDispatchToProps)(GetDirectionAPP);
