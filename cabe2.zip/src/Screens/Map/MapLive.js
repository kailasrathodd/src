import React, {useEffect, useState, useMemo} from 'react';
import {View, PermissionsAndroid, Platform} from 'react-native';
import MapplsGL from 'mappls-map-react-native';
import {useSelector, useDispatch} from 'react-redux';
import {
  RideUpdateAPI,
  getBasicDetailsAPI,
} from '../../features/basicdetails/basicdetail';
import {
  AddressPin,
  AddressPinPickUP,
  updateLocation,
} from '../../features/location/location';
import RNAndroidLocationEnabler from 'react-native-android-location-enabler';
import {Button, Icon} from 'react-native-elements';
import * as Permissions from 'react-native-permissions';

const MapLive = () => {
  const [latitude, setLatitude] = useState(null);
  const [longitude, setLongitude] = useState(null);
  const [gpsState, setGpsState] = useState(true);
  const [label, setLabel] = useState('');
  const [markerLat, setMarkerLat] = useState(19.20425071);
  const [markerLng, setMarkerLng] = useState(72.8484724);

  const dispatch = useDispatch();
  const location = useSelector(state => state.location);
  const pickUp = useSelector(state => state.location.AddressPinPickUP);
  const basicDetail = useSelector(state => state.basicDetail.basicDetail);
  const ridr_id = useSelector(state => state.auth.user?._id);

  const [polygon, setPolygon] = useState({
    type: 'FeatureCollection',
    features: [
      {
        type: 'Feature',
        geometry: {
          type: 'Polygon',
          coordinates: [],
        },
      },
    ],
  });

  useEffect(() => {
    const liveLocationCoordinates = [longitude, latitude];
    const circleCoordinates = calculateCircleCoordinates(
      liveLocationCoordinates,
      2000,
    );
    setPolygon({
      type: 'FeatureCollection',
      features: [
        {
          type: 'Feature',
          geometry: {
            type: 'Polygon',
            coordinates: [circleCoordinates],
          },
        },
      ],
    });
  }, [latitude, longitude]);

  useEffect(() => {
    MapplsGL.locationManager.start();
    dispatch(AddressPin(label));
    onFloatingButtonClick();
    dispatch(getBasicDetailsAPI({rider_id: ridr_id}));

    const interval = setInterval(() => {
      onPressLocationButton();
    }, 50000);

    return () => {
      MapplsGL.locationManager.stop();
      onFloatingButtonClick();
      clearInterval(interval);
      dispatch(getBasicDetailsAPI({rider_id: ridr_id}));
    };
  }, []);

  useEffect(() => {
    dispatch(getBasicDetailsAPI({rider_id: ridr_id}));
    if (latitude !== null && longitude !== null) {
      revGeoCodeApi(latitude, longitude);
      setMarkerLat(parseFloat(latitude));
      setMarkerLng(parseFloat(longitude));
    }
  }, [latitude, longitude]);

  const calculateCircleCoordinates = (centerCoordinates, radius) => {
    const latitude = centerCoordinates[1];
    const longitude = centerCoordinates[0];
    const earthRadius = 124278.1;

    const coordinates = [];
    const slices = 64;

    for (let i = 0; i <= slices; i++) {
      const angle = (Math.PI / 180) * (i / slices) * 360;
      const circleLatitude =
        latitude + (radius / earthRadius) * Math.cos(angle);
      const circleLongitude =
        longitude +
        ((radius / earthRadius) * Math.sin(angle)) /
          Math.cos(circleLatitude * (Math.PI / 180));

      coordinates.push([circleLongitude, circleLatitude]);
    }

    coordinates.push(coordinates[0]);

    return coordinates;
  };

  const revGeoCodeApi = (lat, lng) => {
    MapplsGL.RestApi.reverseGeocode({latitude: lat, longitude: lng})
      .then(data => {
        dispatch(AddressPinPickUP(data.results[0]));

        dispatch(
          RideUpdateAPI({
            rider_id: ridr_id,
            pickup_address: data.results[0].formatted_address,
            pickup_latitude: data.results[0].lat,
            pickup_longitude: data.results[0].lng,
            pickup_details: data.results[0],
          }),
        );
        setLabel(data.results[0].formatted_address);
        dispatch(getBasicDetailsAPI({rider_id: ridr_id}));
      })
      .catch(error => {
        console.log('fail: ' + error.message);
        // Toast.show(error.message);
      });
  };

  const requestLocationPermission = async () => {
    if (Platform.OS === 'ios') {
      const {status} = await Permissions.request(
        Permissions.PERMISSIONS.IOS.LOCATION_WHEN_IN_USE,
      );
      return status;
    } else {
      const granted = await PermissionsAndroid.request(
        PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
        {
          title: 'Location Permission',
          message: 'CabeApp needs access to your location.',
          buttonNeutral: 'Ask Me Later',
          buttonNegative: 'Cancel',
          buttonPositive: 'OK',
        },
      );
      if (granted === PermissionsAndroid.RESULTS.GRANTED) {
        return 'granted';
      } else {
        return 'denied';
      }
    }
  };

  const onUpdate = location => {
    const {latitude, longitude, accuracy} = location.coords;
    setLatitude(latitude);
    setLongitude(longitude);
    dispatch(updateLocation({latitude, longitude}));

    dispatch(
      RideUpdateAPI({
        rider_id: ridr_id,
        current_loc: {latitude, longitude},
      }),
    );
  };

  const onPressLocationButton = () => {
    requestLocationPermission().then(status => {
      camera.zoomTo(15, 1000);
      camera.flyTo([longitude, latitude]);
      if (status === 'granted') {
        navigator.geolocation.getCurrentPosition(
          position => {
            const {latitude, longitude} = position.coords;
            setLatitude(latitude);
            setLongitude(longitude);
            revGeoCodeApi(latitude, longitude);
            setMarkerLat(parseFloat(latitude));
            setMarkerLng(parseFloat(longitude));
          },
          error => {
            console.log('Error getting location:', error);
          },
          {enableHighAccuracy: true, timeout: 15000, maximumAge: 10000},
        );
      }
    });
  };

  const onFloatingButtonClick = () => {
    if (Platform.OS === 'android') {
      RNAndroidLocationEnabler.promptForEnableLocationIfNeeded({
        interval: 1000,
        fastInterval: 5000,
      })
        .then(data => {
          setGpsState(true);
        })
        .catch(err => {
          // Toast.show('Please enable gps.');
        });
    } else {
      setGpsState(true);
    }
  };

  const locationComponent = gpsState ? (
    <MapplsGL.UserLocation animated={true} visible={true} onUpdate={onUpdate} />
  ) : null;

  const marker =
    markerLat !== null && markerLng !== null ? (
      <MapplsGL.PointAnnotation
        id="markerId"
        title="Marker"
        coordinate={[location.longitude || markerLat, location.latitude]}>
        <MapplsGL.Callout title={label} />
      </MapplsGL.PointAnnotation>
    ) : null;

  return useMemo(
    () => (
      <View style={{flex: 1}}>
        <MapplsGL.MapView style={{flex: 1}}>
          <MapplsGL.Camera
            zoomLevel={13}
            // animationMode="flyTo"
            maxZoomLevel={22}
            ref={c => (camera = c)}
            centerCoordinate={[location.longitude, location.latitude]}
          />

          {marker}
          <MapplsGL.ShapeSource id="routeSource" shape={polygon}>
            <MapplsGL.FillLayer
              id="routeFill"
              style={{
                fillColor: 'skyblue',
                fillOpacity: 0.3,
                fillAntialias: true,
              }}
            />
          </MapplsGL.ShapeSource>
          {locationComponent}
        </MapplsGL.MapView>
        {/* <Image source={this.state.image} style={styles.centerMaker} /> */}
        <View
          style={{
            width: 50,
            height: 50,
            backgroundColor: 'transparent',
            position: 'absolute',
            top: '80%',
            left: '80%',
            zIndex: 10,
          }}>
          <Button
            icon={<Icon name="my-location" size={35} color="white" />}
            onPress={onPressLocationButton}
          />
        </View>
      </View>
    ),
    [
      latitude,
      longitude,
      gpsState,
      markerLat,
      markerLng,
      location.longitude,
      location.latitude,
      label,
      polygon,
    ],
  );
};

export default React.memo(MapLive);
