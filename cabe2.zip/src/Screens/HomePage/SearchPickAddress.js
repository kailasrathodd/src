import {
  View,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  SafeAreaView,
  Image,
  FlatList,
} from 'react-native';
import React, {useState, useEffect} from 'react';
import {Searchbar} from 'react-native-paper';
import {useDispatch, useSelector} from 'react-redux';
import {PickUpLocation, PickUpeLoc} from '../../features/location/location';
import {
  RideUpdateAPI,
  getBasicDetailsAPI,
  getElocTotPickUpAPI,
  eLocPick,
} from '../../features/basicdetails/basicdetail';
import SearchMap from './SearchMap';
export default function SearchPickAddress({navigation}, props) {
  const coordinate = useSelector(state => state.basicDetail.getElocPickup);
  const basicDetail = useSelector(state => state.basicDetail.basicDetail);
  const rider_id = useSelector(state => state.auth.user?._id);
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [accessToken, setAccessToken] = useState([]);
  const [query, setQuery] = useState('');
  const [search, setSearch] = useState('');
  const Longitude = coordinate?.longitude;
  const Latitude = coordinate?.latitude;
  const [filteredDataSource, setFilteredDataSource] = useState([]);
  const dispatch = useDispatch();
  useEffect(() => {
    console.log('coordinate123e', Longitude !== basicDetail.pickup_longitude);
    if (coordinate?.longitude !== basicDetail.pickup_longitude) {
      dispatch(
        RideUpdateAPI({
          pickup_latitude: Latitude,
          pickup_longitude: Longitude,
          rider_id: rider_id,
        }),
      );
    }
    coordinate;
  }, [coordinate, dispatch]);
  if (coordinate?.longitude !== basicDetail.pickup_longitude) {
    dispatch(
      RideUpdateAPI({
        pickup_latitude: Latitude,
        pickup_longitude: Longitude,
        rider_id: rider_id,
      }),
    );
  }
  const searchFilterFunction = text => {
    if (text) {
      const newData = data?.filter(function (item) {
        // const itemData = item.placeAddress
        //   ? item.placeAddress.toUpperCase()
        //   : ''.toUpperCase();
        const itemData = `${item.placeAddress.toUpperCase()}`;

        const textData = text.toUpperCase();
        return itemData.indexOf(textData) - 1;
      });
      setFilteredDataSource(newData);
      setQuery(text);
    } else {
      setFilteredDataSource('');
      setQuery('');
    }
  };
  handleSearchClear = () => searchFilterFunction('');
  const filteredData = data?.filter(item =>
    item.placeAddress.toLowerCase().includes(query.toLowerCase()),
  );
  const [isFocus, setIsFocus] = useState(false);
  const fetchAccessToken = async () => {
    const resp2 = await fetch(
      'https://outpost.mapmyindia.com/api/security/oauth/token?grant_type=client_credentials&client_id=33OkryzDZsJ5zN81E9FCF9vruFDY_8wEJySBHTVN2YroM6YVpgCRG8GjfY_w_wHLGWA24P-wObVzK2I7yH0AtQ==&client_secret=lrFxI-iSEg_7x4WFo74p0-leBomnlnqQTpyHrd7f--g-2lk3ZpOOZwBvabvkCEVBSC1yny1ymG7pZN0FkXFrzi8og6fFRBF7',
      {
        method: 'POST',
      },
    );

    const accessToken = await resp2.json();
    setAccessToken(accessToken.access_token);
  };
  const showSuggestion = () => {
    fetchAccessToken();
    fetchData();
  };

  const fetchData = async () => {
    const resp = await fetch(
      `https://atlas.mapmyindia.com/api/places/search/json?access_token=${accessToken}&query=${query} || ${query}`,
    );
    const data = await resp.json();
    setData(data.suggestedLocations);

    setLoading(false);
  };

  const NewSetButton = item => {
    setQuery(item.placeAddress);
  };
  const renderItem = ({item, index}) => {
    return (
      <TouchableOpacity
        activeOpacity={0.7}
        onPress={async () => {
          NewSetButton(item);
          setQuery(await item.placeAddress);
          const eloc = await item.eLoc;
          dispatch(PickUpeLoc(eloc));
          dispatch(getElocTotPickUpAPI(eloc));
          dispatch(eLocPick(eloc));

          dispatch(
            RideUpdateAPI({
              pickup_address: item.placeAddress,
              rider_id: await rider_id,
              pickup_details: await item,
              pickup_Eloc: await eloc,
            }),
          );

          dispatch(PickUpLocation(await item.placeAddress));
          dispatch(
            getBasicDetailsAPI({
              rider_id: rider_id,
            }),
          );
          await navigation.navigate('HomePage');
        }}
        style={{
          backgroundColor: '#ffff',
          width: '100%',
          padding: 10,

          alignSelf: 'center',
        }}>
        <View
          style={{
            backgroundColor: '#ffff',
            width: '100%',

            alignSelf: 'center',
          }}>
          <Text style={{padding: 5, fontWeight: 700, fontSize: 15}}>
            {item.placeName}
          </Text>
          <Text style={{padding: 5, fontWeight: 700, fontSize: 10}}>
            {item.placeAddress}
          </Text>
        </View>
      </TouchableOpacity>
    );
  };
  const ItemSeparatorView = () => {
    return (
      <View
        style={{
          height: 0.5,
          width: '100%',
          backgroundColor: '#C8C8C8',
        }}
      />
    );
  };
  return (
    <SafeAreaView style={{flex: 1}}>
      <View
        style={{
          width: '90%',
          alignSelf: 'center',
          backgroundColor: '#fff',
          marginTop: '10%',
          borderRadius: 20,
        }}>
        <SearchMap />
        <Searchbar
          placeholder="Search Here"
          onClear={text => searchFilterFunction(text)}
          style={{
            height: 50,

            paddingLeft: 10,
            margin: 10,
            borderColor: '#009688',
            backgroundColor: '#FFFFFF',

            elevation: 20,
            shadowColor: '#e2006A',
          }}
          autoFocus={true}
          onChangeText={values => {
            setQuery(values);
            searchFilterFunction(values);
          }}
          value={query || ''}
          onChange={item => {
            showSuggestion(item);
            setIsFocus(true);
          }}
        />

        {/* <TextInput
          name="Searchpickup"
          style={[(borderColor = 'red'), isFocus && {borderColor: 'blue'}]}
          value={query}
          search
          onChangeText={values => setQuery(values)}
          onFocus={() => setIsFocus(true)}
          onBlur={() => setIsFocus(false)}
          onChange={item => {
            showSuggestion(item);
            setIsFocus(true);
          }}
          multiline
          placeholder="Kandivali East, Mumbai, Maharashtra 400101"
        /> */}
      </View>
      <View
        style={{
          width: '100%',
          alignSelf: 'center',
          marginTop: '5%',
        }}>
        {filteredDataSource && (
          <FlatList
            data={filteredDataSource}
            renderItem={renderItem}
            keyExtractor={item => item.placeAddress}
            ItemSeparatorComponent={ItemSeparatorView}
          />
        )}
      </View>
      <TouchableOpacity
        style={{
          width: '30%',
          alignSelf: 'flex-start',
          marginLeft: '5%',
          backgroundColor: '#000055',
          borderRadius: 10,
          padding: 2,
          // alignItems: 'center',
          marginTop: '5%',
        }}
        onPress={() => navigation.navigate('PickUpOnmap')}>
        <Text
          style={{
            padding: 5,
            fontWeight: 700,
            fontSize: 12,
            color: '#fff',
            alignSelf: 'center',
          }}>
          choose on Map
        </Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
}
